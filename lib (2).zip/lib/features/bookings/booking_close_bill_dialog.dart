import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class BookingCloseBillDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingCloseBillDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingCloseBillDialog> createState() => _BookingCloseBillDialogState();
}

class _BookingCloseBillDialogState extends State<BookingCloseBillDialog> {
  bool _loading = true;
  num _ordersTotal = 0;
  num _sessionTotal = 0;
  num _grandTotal = 0;
  int _playedMinutes = 0;
  List<Map<String, dynamic>> _orders = [];
  List<Map<String, dynamic>> _segments = [];

  @override
  void initState() {
    super.initState();
    _loadBill();
  }

  Future<void> _loadBill() async {
    final sessionData = widget.data;
    final branchId = widget.branchId;
    final startTime = (sessionData['startTime'] as Timestamp?)?.toDate();
    final currentSeatId = sessionData['seatId'] as String?;

    // 1. orders
    final ordersSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('orders')
        .get();
    num ordersTotal = 0;
    final ordersList = <Map<String, dynamic>>[];
    for (final doc in ordersSnap.docs) {
      final d = doc.data();
      ordersTotal += (d['total'] ?? 0) as num;
      ordersList.add(d);
    }

    // 2. seat change segments
    // expected path: branches/{branchId}/sessions/{sessionId}/seat_changes
    final seatChangesSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('seat_changes')
        .orderBy('changedAt')
        .get();

    final now = DateTime.now();
    final segments = <Map<String, dynamic>>[];

    if (startTime != null) {
      DateTime lastFrom = startTime;
      String? lastSeat = currentSeatId;

      if (seatChangesSnap.docs.isEmpty) {
        // single segment from start to now with current seat
        segments.add({
          'seatId': currentSeatId,
          'from': startTime,
          'to': now,
        });
      } else {
        // build segments from changes
        for (final sc in seatChangesSnap.docs) {
          final data = sc.data();
          final changedAt = (data['changedAt'] as Timestamp?)?.toDate();
          final toSeatId = data['toSeatId'] as String?;
          // segment from lastFrom..changedAt with lastSeat
          if (changedAt != null) {
            segments.add({
              'seatId': lastSeat,
              'from': lastFrom,
              'to': changedAt,
            });
            lastFrom = changedAt;
            lastSeat = toSeatId;
          }
        }
        // last open segment until now
        segments.add({
          'seatId': lastSeat,
          'from': lastFrom,
          'to': now,
        });
      }
    }

    // 3. compute session total from segments
    num sessionTotal = 0;
    int totalPlayed = 0;
    final computedSegments = <Map<String, dynamic>>[];

    for (final seg in segments) {
      final seatId = seg['seatId'] as String?;
      final from = seg['from'] as DateTime;
      final to = seg['to'] as DateTime;
      final mins = to.difference(from).inMinutes.clamp(0, 9999);
      totalPlayed += mins;

      num ratePerHour = 0;
      if (seatId != null) {
        final seatSnap = await FirebaseFirestore.instance
            .collection('branches')
            .doc(branchId)
            .collection('seats')
            .doc(seatId)
            .get();
        ratePerHour = (seatSnap.data()?['ratePerHour'] ?? 0) as num;
      }

      final segTotal = ratePerHour * (mins / 60);
      sessionTotal += segTotal;
      computedSegments.add({
        'seatId': seatId,
        'minutes': mins,
        'ratePerHour': ratePerHour,
        'total': segTotal,
      });
    }

    setState(() {
      _ordersTotal = ordersTotal;
      _sessionTotal = sessionTotal;
      _grandTotal = ordersTotal + sessionTotal;
      _orders = ordersList;
      _playedMinutes = totalPlayed;
      _segments = computedSegments;
      _loading = false;
    });
  }

  Future<void> _closeSession() async {
    final invoiceNumber = 'INV-${DateTime.now().millisecondsSinceEpoch}';
    await FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .update({
      'status': 'completed',
      'closedAt': FieldValue.serverTimestamp(),
      'billAmount': _grandTotal,
      'playedMinutes': _playedMinutes,
      'invoiceNumber': invoiceNumber,
    });
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 440,
        padding: const EdgeInsets.all(18),
        child: _loading
            ? const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              )
            : SingleChildScrollView(
                child: DefaultTextStyle(
                  style: const TextStyle(color: Colors.white),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Close & Bill',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text('Played: $_playedMinutes minutes'),
                      const SizedBox(height: 8),
                      const Text('Session segments:'),
                      if (_segments.isEmpty)
                        const Text('• Single seat session'),
                      ..._segments.map((s) {
                        final seatId = s['seatId'] ?? 'Seat';
                        final mins = s['minutes'];
                        final rate = s['ratePerHour'];
                        final total = (s['total'] as num).toStringAsFixed(2);
                        return Text(
                            '• $seatId : $mins mins × ₹$rate/hr = ₹$total');
                      }),
                      const SizedBox(height: 8),
                      Text(
                        'Session total: ₹${_sessionTotal.toStringAsFixed(2)}',
                      ),
                      const SizedBox(height: 8),
                      const Text('Orders:'),
                      if (_orders.isEmpty)
                        const Text('• No orders added'),
                      if (_orders.isNotEmpty)
                        ..._orders.map((o) {
                          final name = o['itemName'] ?? '';
                          final qty = o['qty'] ?? 0;
                          final total = o['total'] ?? 0;
                          return Text('• $name x$qty → ₹$total');
                        }),
                      const SizedBox(height: 8),
                      Text('Orders total: ₹${_ordersTotal.toStringAsFixed(2)}'),
                      const Divider(color: Colors.white30),
                      Text(
                        'Grand total: ₹${_grandTotal.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _closeSession,
                          child: const Text('Close session'),
                        ),
                      ),
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Cancel'),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
