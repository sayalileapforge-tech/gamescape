import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class BookingTimelineView extends StatelessWidget {
  final List<QueryDocumentSnapshot> bookings;
  const BookingTimelineView({super.key, required this.bookings});

  @override
  Widget build(BuildContext context) {
    // group by seat
    final Map<String, List<Map<String, dynamic>>> bySeat = {};
    for (final doc in bookings) {
      final data = doc.data() as Map<String, dynamic>;
      final seat = data['seatLabel'] ?? 'Unknown';
      bySeat.putIfAbsent(seat, () => []);
      bySeat[seat]!.add(data);
    }

    return ListView(
      children: bySeat.entries.map((entry) {
        final seat = entry.key;
        final list = entry.value;

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                seat,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: list.map((b) {
                    final DateTime? start =
                        (b['startTime'] as Timestamp?)?.toDate();
                    final int dur = (b['durationMinutes'] ?? 0) as int;
                    final end = start != null
                        ? start.add(Duration(minutes: dur))
                        : null;
                    final now = DateTime.now();
                    final remaining = end != null ? end.difference(now) : null;
                    final isExpired = remaining != null && remaining.isNegative;
                    final remainingText = remaining == null
                        ? ''
                        : isExpired
                            ? 'Expired'
                            : '${remaining.inMinutes}m left';

                    return Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      width: 190,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(b['customerName'] ?? ''),
                          if (start != null)
                            Text(
                              '${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')} (${dur}m)',
                              style: TextStyle(
                                color: Colors.grey.shade600,
                                fontSize: 12,
                              ),
                            ),
                          const SizedBox(height: 4),
                          if (remainingText.isNotEmpty)
                            Text(
                              remainingText,
                              style: TextStyle(
                                fontSize: 12,
                                color: isExpired ? Colors.red : Colors.green,
                              ),
                            ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
