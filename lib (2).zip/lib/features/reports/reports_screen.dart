import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int _activeCount = 0;
  int _completedCount = 0;

  @override
  Widget build(BuildContext context) {
    final activeQ = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'active');
    final completedQ = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'completed');

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Reports',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: activeQ.snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      _activeCount = snapshot.data!.docs.length;
                    }
                    return _reportCard(
                      'Active Sessions',
                      _activeCount.toString(),
                      Colors.blueAccent,
                    );
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: completedQ.snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      _completedCount = snapshot.data!.docs.length;
                    }
                    return _reportCard(
                      'Completed Sessions',
                      _completedCount.toString(),
                      Colors.greenAccent,
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _reportCard(String title, String value, Color accent) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 26,
              color: accent,
            ),
          ),
        ],
      ),
    );
  }
}
