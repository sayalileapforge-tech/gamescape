// lib/services/invoice_pdf_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class InvoicePdfService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> generateAndPrint({
    required String branchId,
    required String sessionId,
  }) async {
    // 1. load session
    final sessionRef = _db
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(sessionId);
    final sessionSnap = await sessionRef.get();
    final sessionData = sessionSnap.data() ?? {};

    // 2. load orders
    final ordersSnap = await sessionRef.collection('orders').get();

    // 3. build PDF
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build: (ctx) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'GameScape Invoice',
                style: pw.TextStyle(
                  fontSize: 20,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 6),
              pw.Text('Invoice: ${sessionData['invoiceNumber'] ?? '-'}'),
              pw.Text('Customer: ${sessionData['customerName'] ?? 'Walk-in'}'),
              pw.Text('Branch: ${sessionData['branchName'] ?? branchId}'),
              pw.Text('Seat: ${sessionData['seatLabel'] ?? ''}'),
              pw.SizedBox(height: 14),
              pw.Text(
                'Orders',
                style:
                    pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
              ),
              if (ordersSnap.docs.isEmpty) pw.Text('No orders'),
              ...ordersSnap.docs.map((o) {
                final od = o.data();
                return pw.Text(
                    '- ${od['itemName']} x${od['qty']} = ₹${od['total']}');
              }),
              pw.SizedBox(height: 12),
              pw.Text(
                  'Played minutes: ${sessionData['playedMinutes'] ?? 0} mins'),
              pw.SizedBox(height: 6),
              pw.Text('Discount: ₹${sessionData['discount'] ?? 0}'),
              pw.Text('Tax: ${sessionData['taxPercent'] ?? 0}%'),
              pw.SizedBox(height: 6),
              pw.Text(
                'Total: ₹${sessionData['billAmount'] ?? 0}',
                style: pw.TextStyle(
                  fontSize: 16,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 12),
              pw.Text(
                'Payments:',
                style:
                    pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
              ),
              ...((sessionData['payments'] as List<dynamic>?) ?? [])
                  .map((p) => pw.Text(
                      '- ${p['mode']} : ₹${p['amount'] ?? 0}'))
                  .toList(),
            ],
          );
        },
      ),
    );

    // 4. print/share
    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
    );
  }
}
