import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AddBookingDialog extends StatefulWidget {
  final List<String>? allowedBranchIds;
  final String? initialBranchId;

  // Prefill from Customers → Bookings flow
  final String? prefillName;
  final String? prefillPhone;

  const AddBookingDialog({
    super.key,
    this.allowedBranchIds,
    this.initialBranchId,
    this.prefillName,
    this.prefillPhone,
  });

  @override
  State<AddBookingDialog> createState() => _AddBookingDialogState();
}

class _AddBookingDialogState extends State<AddBookingDialog> {
  String? _selectedBranchId;
  String? _selectedBranchName;

  String? _selectedSeatType; // NEW: filter
  String? _selectedSeatId;
  String? _selectedSeatLabel;
  String? _selectedSeatTypeDisplay; // show selected seat type

  final _customerNameCtrl = TextEditingController();
  final _customerPhoneCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  final _paxCtrl = TextEditingController();
  final _gamePrefCtrl = TextEditingController();
  String _paymentType = 'postpaid';

  final List<int> _durationOptions =
      const [30, 60, 90, 120, 150, 180, 240, 300];
  int _selectedDuration = 60;

  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _selectedBranchId = widget.initialBranchId;

    if (widget.prefillName != null && widget.prefillName!.isNotEmpty) {
      _customerNameCtrl.text = widget.prefillName!;
    }
    if (widget.prefillPhone != null && widget.prefillPhone!.isNotEmpty) {
      _customerPhoneCtrl.text = widget.prefillPhone!;
    }
  }

  @override
  Widget build(BuildContext context) {
    final branchesCol = FirebaseFirestore.instance.collection('branches');

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(18),
        child: SingleChildScrollView(
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Create Booking',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                ),
                const SizedBox(height: 14),

                // Branch
                StreamBuilder<QuerySnapshot>(
                  stream: branchesCol.snapshots(),
                  builder: (context, snapshot) {
                    final all = snapshot.hasData ? snapshot.data!.docs : <QueryDocumentSnapshot>[];
                    final items = (widget.allowedBranchIds == null || widget.allowedBranchIds!.isEmpty)
                        ? all
                        : all.where((d) => widget.allowedBranchIds!.contains(d.id)).toList();

                    if (_selectedBranchId == null && items.isNotEmpty) {
                      _selectedBranchId = items.first.id;
                      _selectedBranchName =
                          (items.first.data() as Map<String, dynamic>? ?? {})['name']?.toString();
                    }

                    return DropdownButtonFormField<String>(
                      value: _selectedBranchId,
                      dropdownColor: const Color(0xFF111827),
                      style: const TextStyle(color: Colors.white),
                      decoration: _darkInput('Select branch'),
                      items: items.map((d) {
                        return DropdownMenuItem(
                          value: d.id,
                          child: Text(d['name'] ?? 'Branch'),
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          _selectedBranchId = v;
                          if (v != null) {
                            final doc = items.firstWhere(
                              (e) => e.id == v,
                              orElse: () => items.first,
                            );
                            _selectedBranchName = doc['name'] ?? '';
                          } else {
                            _selectedBranchName = null;
                          }
                          _selectedSeatId = null;
                          _selectedSeatLabel = null;
                          _selectedSeatType = null;
                          _selectedSeatTypeDisplay = null;
                        });
                      },
                    );
                  },
                ),

                const SizedBox(height: 10),

                // Seat type quick filter (client-side)
                if (_selectedBranchId != null)
                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('branches')
                        .doc(_selectedBranchId)
                        .collection('seats')
                        .where('active', isEqualTo: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      final seatDocs =
                          snapshot.hasData ? snapshot.data!.docs : <QueryDocumentSnapshot>[];

                      // Unique seat types from docs
                      final types = <String>{};
                      for (final d in seatDocs) {
                        final t = (d['type'] ?? '').toString();
                        if (t.isNotEmpty) types.add(t);
                      }
                      final typeList = ['All', ...types];

                      // Seats filtered by type (in-memory)
                      final filtered = (_selectedSeatType == null ||
                              _selectedSeatType == 'All')
                          ? seatDocs
                          : seatDocs.where((d) => (d['type'] ?? '') == _selectedSeatType).toList();

                      return Column(
                        children: [
                          DropdownButtonFormField<String>(
                            value: _selectedSeatType ?? 'All',
                            dropdownColor: const Color(0xFF111827),
                            style: const TextStyle(color: Colors.white),
                            decoration: _darkInput('Seat type'),
                            items: typeList
                                .map((t) =>
                                    DropdownMenuItem(value: t, child: Text(t)))
                                .toList(),
                            onChanged: (v) {
                              setState(() {
                                _selectedSeatType = v;
                                _selectedSeatId = null;
                                _selectedSeatLabel = null;
                                _selectedSeatTypeDisplay = null;
                              });
                            },
                          ),
                          const SizedBox(height: 10),
                          DropdownButtonFormField<String>(
                            value: _selectedSeatId,
                            dropdownColor: const Color(0xFF111827),
                            style: const TextStyle(color: Colors.white),
                            decoration: _darkInput('Select seat'),
                            items: filtered.map((d) {
                              final t = (d['type'] ?? '').toString();
                              final rate = (d['ratePerHour'] ?? 0).toString();
                              return DropdownMenuItem(
                                value: d.id,
                                child: Text('${d['label']} • $t • ₹$rate/hr'),
                              );
                            }).toList(),
                            onChanged: (v) {
                              setState(() {
                                _selectedSeatId = v;
                                final doc = filtered.firstWhere(
                                  (e) => e.id == v,
                                  orElse: () => filtered.first,
                                );
                                _selectedSeatLabel = doc['label'] ?? '';
                                _selectedSeatTypeDisplay =
                                    (doc['type'] ?? '').toString();
                              });
                            },
                          ),
                          if (_selectedSeatTypeDisplay != null) ...[
                            const SizedBox(height: 10),
                            InputDecorator(
                              decoration: _darkInput('Selected seat type'),
                              child: Text(_selectedSeatTypeDisplay!),
                            ),
                          ],
                        ],
                      );
                    },
                  ),

                const SizedBox(height: 10),

                // Customer phone (fetch removed as requested)
                TextField(
                  controller: _customerPhoneCtrl,
                  decoration: _darkTextField('Customer phone (optional)'),
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.phone,
                ),

                const SizedBox(height: 10),
                TextField(
                  controller: _customerNameCtrl,
                  decoration: _darkTextField('Customer name'),
                  style: const TextStyle(color: Colors.white),
                ),

                const SizedBox(height: 10),
                TextField(
                  controller: _paxCtrl,
                  decoration: _darkTextField('Pax (optional)'),
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.number,
                ),

                const SizedBox(height: 10),
                TextField(
                  controller: _gamePrefCtrl,
                  decoration: _darkTextField('Game preference (optional)'),
                  style: const TextStyle(color: Colors.white),
                ),

                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: _paymentType,
                  dropdownColor: const Color(0xFF111827),
                  style: const TextStyle(color: Colors.white),
                  decoration: _darkInput('Payment type'),
                  items: const [
                    DropdownMenuItem(value: 'prepaid', child: Text('Prepaid')),
                    DropdownMenuItem(value: 'postpaid', child: Text('Postpaid')),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _paymentType = v);
                  },
                ),

                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: _pickDate,
                        child: InputDecorator(
                          decoration: _darkInput('Date'),
                          child: Text(
                            '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: InkWell(
                        onTap: _pickTime,
                        child: InputDecorator(
                          decoration: _darkInput('Time'),
                          child: Text(_selectedTime.format(context)),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),
                DropdownButtonFormField<int>(
                  value: _selectedDuration,
                  dropdownColor: const Color(0xFF111827),
                  style: const TextStyle(color: Colors.white),
                  decoration: _darkInput('Duration'),
                  items: _durationOptions
                      .map((m) => DropdownMenuItem(value: m, child: Text('$m minutes')))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _selectedDuration = v);
                  },
                ),

                const SizedBox(height: 10),
                TextField(
                  controller: _notesCtrl,
                  decoration: _darkTextField('Notes'),
                  style: const TextStyle(color: Colors.white),
                  maxLines: 2,
                ),

                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 42,
                        child: ElevatedButton(
                          onPressed: _saving ? null : _save,
                          child:
                              _saving ? const CircularProgressIndicator() : const Text('Create'),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _darkInput(String label) {
    return const InputDecoration(
      labelText: null, // we’ll put labelText via wrapper to keep style consistent
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white24),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
    ).copyWith(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
    );
  }

  InputDecoration _darkTextField(String label) => _darkInput(label);

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 30)),
      initialDate: _selectedDate,
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  Future<void> _save() async {
    if (_selectedBranchId == null || _selectedSeatId == null) return;
    if (_customerNameCtrl.text.trim().isEmpty) return;

    setState(() => _saving = true);

    final start = DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      _selectedTime.hour,
      _selectedTime.minute,
    );
    final end = start.add(Duration(minutes: _selectedDuration));

    final sessionsCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(_selectedBranchId)
        .collection('sessions');

    // overlap check (active + reserved on same seat)
    final existingSnap = await sessionsCol
        .where('seatId', isEqualTo: _selectedSeatId)
        .where('status', whereIn: ['active', 'reserved'])
        .get();

    bool hasOverlap = false;
    for (final doc in existingSnap.docs) {
      final data = doc.data();
      final otherStart = (data['startTime'] as Timestamp?)?.toDate();
      final otherDuration = (data['durationMinutes'] ?? 0) as int;
      if (otherStart == null) continue;
      final otherEnd = otherStart.add(Duration(minutes: otherDuration));
      if (otherStart.isBefore(end) && otherEnd.isAfter(start)) {
        hasOverlap = true;
        break;
      }
    }
    if (hasOverlap) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Seat already booked in that time slot')),
        );
      }
      return;
    }

    final now = DateTime.now();
    final isFuture = start.isAfter(now);

    final currentUser = FirebaseAuth.instance.currentUser;
    String? createdByName;
    if (currentUser != null) {
      final userDoc =
          await FirebaseFirestore.instance.collection('users').doc(currentUser.uid).get();
      if (userDoc.exists) {
        createdByName =
            (userDoc.data() as Map<String, dynamic>?)?['name']?.toString();
      }
    }

    await sessionsCol.add({
      'customerName': _customerNameCtrl.text.trim(),
      'customerPhone': _customerPhoneCtrl.text.trim(),
      'branchId': _selectedBranchId,
      'branchName': _selectedBranchName,
      'seatId': _selectedSeatId,
      'seatLabel': _selectedSeatLabel,
      'startTime': Timestamp.fromDate(start),
      'durationMinutes': _selectedDuration,
      'pax': _paxCtrl.text.trim().isEmpty ? null : int.tryParse(_paxCtrl.text.trim()),
      'gamePreference': _gamePrefCtrl.text.trim(),
      'paymentType': _paymentType,
      'status': isFuture ? 'reserved' : 'active',
      'notes': _notesCtrl.text.trim(),
      if (currentUser != null) 'createdBy': currentUser.uid,
      if (createdByName != null) 'createdByName': createdByName,
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) Navigator.of(context).pop();
  }
}
