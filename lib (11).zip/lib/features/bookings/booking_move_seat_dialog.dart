import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class BookingMoveSeatDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final String currentSeatId;

  const BookingMoveSeatDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.currentSeatId,
  });

  @override
  State<BookingMoveSeatDialog> createState() => _BookingMoveSeatDialogState();
}

class _BookingMoveSeatDialogState extends State<BookingMoveSeatDialog> {
  String? _newSeatId;
  String? _newSeatLabel;

  /// what to bill for the segment that is ending now
  /// values: 'actual', '30', '60'
  String _billCurrentAs = 'actual';

  @override
  Widget build(BuildContext context) {
    final seatsQuery = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('seats')
        .where('active', isEqualTo: true);

    return Dialog(
      child: Container(
        width: 400,
        padding: const EdgeInsets.all(16),
        child: StreamBuilder<QuerySnapshot>(
          stream: seatsQuery.snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              );
            }
            final docs = snapshot.data!.docs;

            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Move to another seat',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'Select new seat',
                    border: OutlineInputBorder(),
                  ),
                  items: docs.map((d) {
                    return DropdownMenuItem(
                      value: d.id,
                      child: Text(d['label'] ?? 'Seat'),
                    );
                  }).toList(),
                  onChanged: (v) {
                    setState(() {
                      _newSeatId = v;
                      final doc = docs.firstWhere((e) => e.id == v);
                      _newSeatLabel = doc['label'] ?? '';
                    });
                  },
                ),
                const SizedBox(height: 14),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Bill time spent on current seat as:',
                    style: TextStyle(color: Colors.grey.shade700),
                  ),
                ),
                const SizedBox(height: 6),
                RadioListTile<String>(
                  value: 'actual',
                  groupValue: _billCurrentAs,
                  onChanged: (v) => setState(() => _billCurrentAs = v!),
                  title: const Text('Actual minutes (auto)', style: TextStyle(fontSize: 13)),
                  dense: true,
                ),
                RadioListTile<String>(
                  value: '30',
                  groupValue: _billCurrentAs,
                  onChanged: (v) => setState(() => _billCurrentAs = v!),
                  title: const Text('30 minutes', style: TextStyle(fontSize: 13)),
                  dense: true,
                ),
                RadioListTile<String>(
                  value: '60',
                  groupValue: _billCurrentAs,
                  onChanged: (v) => setState(() => _billCurrentAs = v!),
                  title: const Text('1 hour', style: TextStyle(fontSize: 13)),
                  dense: true,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _newSeatId == null ? null : _move,
                    child: const Text('Move'),
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                )
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> _move() async {
    if (_newSeatId == null) return;

    final now = DateTime.now();
    final currentUser = FirebaseAuth.instance.currentUser;

    // 1) update session seat
    await FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .update({
      'seatId': _newSeatId,
      'seatLabel': _newSeatLabel,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // 2) log seat change + how to bill that segment
    await FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('seat_changes')
        .add({
      'fromSeatId': widget.currentSeatId,
      'toSeatId': _newSeatId,
      'toSeatLabel': _newSeatLabel,
      'changedAt': Timestamp.fromDate(now),
      'billSegmentAs': _billCurrentAs, // 'actual' | '30' | '60'
      if (currentUser != null) 'changedBy': currentUser.uid,
    });

    if (mounted) Navigator.of(context).pop();
  }
}
