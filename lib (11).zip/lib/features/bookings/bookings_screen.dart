import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/app_shell.dart';
import 'add_booking_dialog.dart';
import 'booking_actions_dialog.dart';
import 'booking_timeline_view.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  String? _selectedBranchId;
  String? _selectedBranchName;

  // ui state
  bool _showTimeline = false;
  String _statusFilter = 'all';
  bool _hideOverdue = false;
  int _upcomingWindowMins = 0;

  // timeline date (defaults to today)
  DateTime _timelineDate = DateTime.now();

  // prefill from /bookings?prefillName=&prefillPhone=
  String? _initialPrefillName;
  String? _initialPrefillPhone;
  bool _prefillDialogOpened = false;

  @override
  Widget build(BuildContext context) {
    final branchesCol = FirebaseFirestore.instance.collection('branches');

    // Capture query params once (for customer → bookings flow)
    final uri = GoRouterState.of(context).uri;
    _initialPrefillName ??= uri.queryParameters['prefillName'];
    _initialPrefillPhone ??= uri.queryParameters['prefillPhone'];

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Bookings',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
              ),
              Row(
                children: [
                  DropdownButton<String>(
                    value: _statusFilter,
                    dropdownColor: const Color(0xFF111827),
                    style: const TextStyle(color: Colors.white),
                    items: const [
                      DropdownMenuItem(value: 'all', child: Text('All')),
                      DropdownMenuItem(value: 'active', child: Text('Active')),
                      DropdownMenuItem(
                          value: 'completed', child: Text('Completed')),
                      DropdownMenuItem(
                          value: 'cancelled', child: Text('Cancelled')),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() => _statusFilter = v);
                    },
                  ),
                  const SizedBox(width: 12),
                  // table <-> timeline toggle
                  Container(
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F172A),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: Row(
                      children: [
                        _segBtn(
                          selected: !_showTimeline,
                          icon: Icons.table_chart,
                          label: 'Table',
                          onTap: () => setState(() => _showTimeline = false),
                        ),
                        _segBtn(
                          selected: _showTimeline,
                          icon: Icons.timeline,
                          label: 'Timeline',
                          onTap: () => setState(() => _showTimeline = true),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),

          // branch + new booking + hide overdue
          Row(
            children: [
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: branchesCol.snapshots(),
                  builder: (context, snapshot) {
                    final items = snapshot.data?.docs ?? [];

                    // AUTO-SELECT FIRST BRANCH SAFELY (fixes "Select a branch" bug)
                    if (_selectedBranchId == null && items.isNotEmpty) {
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (!mounted) return;
                        setState(() {
                          _selectedBranchId = items.first.id;
                          _selectedBranchName =
                              (items.first.data() as Map<String, dynamic>? ??
                                      {})['name']
                                  ?.toString();
                        });
                      });
                    }

                    // If we came from Customers with prefill → open dialog once
                    if (!_prefillDialogOpened &&
                        _selectedBranchId != null &&
                        ((_initialPrefillName?.isNotEmpty ?? false) ||
                            (_initialPrefillPhone?.isNotEmpty ?? false))) {
                      _prefillDialogOpened = true;
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (!mounted) return;
                        showDialog(
                          context: context,
                          builder: (_) => AddBookingDialog(
                            initialBranchId: _selectedBranchId,
                            allowedBranchIds: null,
                            prefillName: _initialPrefillName,
                            prefillPhone: _initialPrefillPhone,
                          ),
                        );
                      });
                    }

                    return DropdownButtonFormField<String>(
                      value: _selectedBranchId,
                      dropdownColor: const Color(0xFF111827),
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        labelText: 'Select branch',
                        labelStyle: TextStyle(color: Colors.white54),
                        border: OutlineInputBorder(),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      items: items
                          .map(
                            (d) => DropdownMenuItem(
                              value: d.id,
                              child: Text(
                                (d['name'] ?? 'Branch').toString(),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        setState(() {
                          _selectedBranchId = v;
                          if (v != null) {
                            final doc = items.firstWhere((e) => e.id == v);
                            _selectedBranchName =
                                (doc['name'] ?? '').toString();
                          } else {
                            _selectedBranchName = null;
                          }
                        });
                      },
                    );
                  },
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: _selectedBranchId == null
                    ? null
                    : () {
                        showDialog(
                          context: context,
                          builder: (_) => AddBookingDialog(
                            initialBranchId: _selectedBranchId,
                            allowedBranchIds: null,
                          ),
                        );
                      },
                icon: const Icon(Icons.add),
                label: const Text('New Booking'),
              ),
              const SizedBox(width: 12),
              Row(
                children: [
                  const Text('Hide overdue',
                      style: TextStyle(color: Colors.white70)),
                  Switch(
                    value: _hideOverdue,
                    onChanged: (v) => setState(() => _hideOverdue = v),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),

          // upcoming chips
          Row(
            children: [
              const Text('Upcoming:', style: TextStyle(color: Colors.white70)),
              const SizedBox(width: 8),
              _upcomingChip('Off', 0),
              _upcomingChip('Next 60m', 60),
              _upcomingChip('Next 120m', 120),
              _upcomingChip('Next 180m', 180),
            ],
          ),
          const SizedBox(height: 16),

          // main
          Expanded(
            child: _selectedBranchId == null
                ? const Center(
                    child: Text(
                      'Select a branch to view bookings',
                      style: TextStyle(color: Colors.white38),
                    ),
                  )
                : StreamBuilder<QuerySnapshot>(
                    // stream everything for that branch once, then filter in memory
                    stream: FirebaseFirestore.instance
                        .collection('branches')
                        .doc(_selectedBranchId)
                        .collection('sessions')
                        .orderBy('startTime')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Center(
                            child: CircularProgressIndicator());
                      }
                      if (!snapshot.hasData ||
                          snapshot.data!.docs.isEmpty) {
                        return const Center(
                          child: Text(
                            'No bookings found',
                            style: TextStyle(color: Colors.white38),
                          ),
                        );
                      }

                      final allDocs = snapshot.data!.docs.toList();
                      final now = DateTime.now();

                      // 1) status filter
                      List<QueryDocumentSnapshot> filteredDocs =
                          allDocs.where((d) {
                        final data = d.data() as Map<String, dynamic>;
                        final status =
                            (data['status'] ?? 'active').toString();
                        if (_statusFilter == 'all') return true;
                        return status == _statusFilter;
                      }).toList();

                      // 2) upcoming filter (client side)
                      filteredDocs = filteredDocs.where((d) {
                        if (_upcomingWindowMins == 0) return true;
                        final data = d.data() as Map<String, dynamic>;
                        final status =
                            (data['status'] ?? 'active').toString();
                        // upcoming only makes sense for reserved
                        if (status != 'reserved') return true;
                        final ts = data['startTime'] as Timestamp?;
                        if (ts == null) return false;
                        final start = ts.toDate();
                        final limit =
                            now.add(Duration(minutes: _upcomingWindowMins));
                        return start.isAfter(now) && start.isBefore(limit);
                      }).toList();

                      if (_showTimeline) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  '${_selectedBranchName ?? ''} – Timeline',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600),
                                ),
                                const SizedBox(width: 10),
                                IconButton(
                                  onPressed: () async {
                                    final picked = await showDatePicker(
                                      context: context,
                                      initialDate: _timelineDate,
                                      firstDate: DateTime(2020),
                                      lastDate: DateTime(2100),
                                    );
                                    if (picked != null) {
                                      setState(() {
                                        _timelineDate = picked;
                                      });
                                    }
                                  },
                                  icon: const Icon(Icons.calendar_today,
                                      color: Colors.white70, size: 18),
                                ),
                                Text(
                                  '${_timelineDate.day.toString().padLeft(2, '0')} '
                                  '${_monthShort(_timelineDate.month)}',
                                  style:
                                      const TextStyle(color: Colors.white70),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Expanded(
                              child: BookingTimelineView(
                                bookings: filteredDocs,
                                date: _timelineDate,
                              ),
                            ),
                          ],
                        );
                      }

                      // TABLE VIEW
                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: 1100,
                          child: ListView(
                            shrinkWrap: true,
                            children: [
                              _tableHeader(),
                              const SizedBox(height: 6),
                              for (int i = 0; i < filteredDocs.length; i++)
                                _buildRow(filteredDocs[i], i),
                              const SizedBox(height: 40),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // row ----------------------------------------------------------------
  Widget _buildRow(QueryDocumentSnapshot d, int index) {
    final data = d.data() as Map<String, dynamic>? ?? {};
    final seatLabel = (data['seatLabel'] ?? '').toString();
    final cust = (data['customerName'] ?? '').toString();
    final status = (data['status'] ?? 'active').toString();
    final paymentType = (data['paymentType'] ?? 'postpaid').toString();
    final startTs = data['startTime'] as Timestamp?;
    final start = startTs?.toDate();
    final durationMins = (data['durationMinutes'] ?? 0) as int;

    String dateStr = '—';
    String timeStr = '—';
    if (start != null) {
      dateStr =
          '${start.day.toString().padLeft(2, '0')} ${_monthShort(start.month)}';
      timeStr =
          '${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')}';
    }

    bool isOverdue = false;
    if (status == 'active' && start != null) {
      final end = start.add(Duration(minutes: durationMins));
      isOverdue = DateTime.now().isAfter(end);
    }
    if (_hideOverdue && isOverdue) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          _cell(40, Text('#${index + 1}',
              style: const TextStyle(color: Colors.white))),
          _cell(
            160,
            Text(cust, style: const TextStyle(color: Colors.white)),
          ),
          _cell(
            120,
            Text(seatLabel, style: const TextStyle(color: Colors.white)),
          ),
          _cell(
            110,
            Text(dateStr, style: const TextStyle(color: Colors.white70)),
          ),
          _cell(
            90,
            Text(timeStr, style: const TextStyle(color: Colors.white70)),
          ),
          _cell(
            160,
            Builder(builder: (context) {
              if (status == 'reserved') {
                return const Text(
                  'Yet to start',
                  style: TextStyle(color: Colors.orangeAccent),
                );
              }
              if (status == 'active' && start != null) {
                return BookingCountdown(
                  endTime: start.add(Duration(minutes: durationMins)),
                );
              }
              if (status == 'cancelled' || status == 'canceled') {
                return const Text(
                  'cancelled',
                  style: TextStyle(color: Colors.redAccent),
                );
              }
              return Text(
                status,
                style: const TextStyle(color: Colors.white70),
              );
            }),
          ),
          _cell(110, _PaymentChip(paymentType: paymentType)),
          _cell(110, _StatusChip(status: status)),
          _cell(
            180,
            Builder(builder: (context) {
              // completed / cancelled → view details
              if (status == 'completed' ||
                  status == 'cancelled' ||
                  status == 'canceled') {
                return Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () {
                          if (_selectedBranchId == null) return;
                          showDialog(
                            context: context,
                            builder: (_) => BookingActionsDialog(
                              branchId: _selectedBranchId!,
                              sessionId: d.id,
                              data: data,
                            ),
                          );
                        },
                        child: const Text(
                          'View details',
                          style: TextStyle(color: Colors.white70),
                        ),
                      ),
                    ),
                  ],
                );
              }

              // RESERVED
              if (status == 'reserved') {
                return Row(
                  children: [
                    IconButton(
                      tooltip: 'Start now',
                      onPressed: () async {
                        if (_selectedBranchId == null) return;
                        await FirebaseFirestore.instance
                            .collection('branches')
                            .doc(_selectedBranchId!)
                            .collection('sessions')
                            .doc(d.id)
                            .update({
                          'status': 'active',
                          'startTime': Timestamp.fromDate(DateTime.now()),
                        });
                      },
                      icon: const Icon(Icons.play_arrow,
                          color: Colors.greenAccent),
                    ),
                    IconButton(
                      tooltip: 'Cancel booking',
                      onPressed: () async {
                        if (_selectedBranchId == null) return;
                        await FirebaseFirestore.instance
                            .collection('branches')
                            .doc(_selectedBranchId!)
                            .collection('sessions')
                            .doc(d.id)
                            .update({
                          'status': 'cancelled',
                        });
                      },
                      icon:
                          const Icon(Icons.close, color: Colors.redAccent),
                    ),
                    IconButton(
                      tooltip: 'Details',
                      onPressed: () {
                        if (_selectedBranchId == null) return;
                        showDialog(
                          context: context,
                          builder: (_) => BookingActionsDialog(
                            branchId: _selectedBranchId!,
                            sessionId: d.id,
                            data: data,
                          ),
                        );
                      },
                      icon: const Icon(Icons.info_outline,
                          color: Colors.white70),
                    ),
                  ],
                );
              }

              // ACTIVE → full actions
              return Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (_) => BookingActionsDialog(
                            branchId: _selectedBranchId!,
                            sessionId: d.id,
                            data: data,
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black87,
                      ),
                      child: const Text('Actions'),
                    ),
                  ),
                ],
              );
            }),
          ),
        ],
      ),
    );
  }

  // helpers ------------------------------------------------------------
  Widget _cell(double width, Widget child) {
    return SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: child,
      ),
    );
  }

  Widget _tableHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        children: const [
          _HeaderCell(width: 40, label: '#'),
          _HeaderCell(width: 160, label: 'Customer'),
          _HeaderCell(width: 120, label: 'Seat'),
          _HeaderCell(width: 110, label: 'Date'),
          _HeaderCell(width: 90, label: 'Start'),
          _HeaderCell(width: 160, label: 'Time / Status'),
          _HeaderCell(width: 110, label: 'Payment'),
          _HeaderCell(width: 110, label: 'Status'),
          _HeaderCell(width: 180, label: 'Actions'),
        ],
      ),
    );
  }

  Widget _upcomingChip(String label, int minutes) {
    final selected = _upcomingWindowMins == minutes;
    return Padding(
      padding: const EdgeInsets.only(right: 6.0),
      child: InkWell(
        onTap: () => setState(() => _upcomingWindowMins = minutes),
        borderRadius: BorderRadius.circular(999),
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            border: Border.all(color: Colors.white24),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.black : Colors.white,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }

  Widget _segBtn({
    required bool selected,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        height: 34,
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: selected ? Colors.black : Colors.white70,
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: selected ? Colors.black : Colors.white70,
                fontWeight:
                    selected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _monthShort(int m) {
    const arr = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return arr[m];
  }
}

// header cell ----------------------------------------------------------
class _HeaderCell extends StatelessWidget {
  final double width;
  final String label;
  const _HeaderCell({required this.width, required this.label});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white38,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}

// payment chip --------------------------------------------------------
class _PaymentChip extends StatelessWidget {
  final String paymentType;
  const _PaymentChip({required this.paymentType});

  @override
  Widget build(BuildContext context) {
    final isPrepaid = paymentType == 'prepaid';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: (isPrepaid ? Colors.blue : Colors.green).withOpacity(0.2),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        isPrepaid ? 'Prepaid' : 'Postpaid',
        style: const TextStyle(color: Colors.white, fontSize: 11),
      ),
    );
  }
}

// status chip ---------------------------------------------------------
class _StatusChip extends StatelessWidget {
  final String status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color c = Colors.white12;
    String label = status;

    if (status == 'cancelled' || status == 'canceled') {
      c = Colors.red.withOpacity(0.25);
      label = 'Cancelled';
    } else if (status == 'completed') {
      c = Colors.grey.withOpacity(0.25);
      label = 'Completed';
    } else if (status == 'reserved') {
      c = Colors.orange.withOpacity(0.25);
      label = 'Reserved';
    } else if (status == 'active') {
      c = Colors.blue.withOpacity(0.25);
      label = 'Active';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, fontSize: 11),
      ),
    );
  }
}

// countdown ------------------------------------------------------------
class BookingCountdown extends StatefulWidget {
  final DateTime endTime;
  const BookingCountdown({super.key, required this.endTime});

  @override
  State<BookingCountdown> createState() => _BookingCountdownState();
}

class _BookingCountdownState extends State<BookingCountdown> {
  late Timer _timer;
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _remaining = widget.endTime.difference(DateTime.now());
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      final diff = widget.endTime.difference(DateTime.now());
      if (!mounted) return;
      setState(() {
        _remaining = diff;
      });
      if (diff.isNegative) {
        t.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _fmt(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final d = _remaining.isNegative ? Duration.zero : _remaining;
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);

    return Text(
      'Time left: ${_fmt(h)}:${_fmt(m)}:${_fmt(s)}',
      style: TextStyle(
        color: d.inMinutes <= 1 ? Colors.redAccent : Colors.greenAccent,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}
