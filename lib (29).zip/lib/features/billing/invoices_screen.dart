// FULL FILE: lib/features/billing/invoices_screen.dart
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/widgets/app_shell.dart';
import '../../services/invoice_pdf_service.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  int _tabIndex = 0; // 0 = pending, 1 = paid
  bool _useFallback = false; // toggled by button only

  // Optional customer filter from query params
  String? _filterPhone;
  String? _filterName;

  @override
  void initState() {
    super.initState();
    final qp = Uri.base.queryParameters;
    final phone = qp['customerPhone']?.trim();
    final name = qp['customerName']?.trim();
    if (phone != null && phone.isNotEmpty) _filterPhone = phone;
    if (name != null && name.isNotEmpty) _filterName = name;
  }

  void _clearFilter() {
    setState(() {
      _filterPhone = null;
      _filterName = null;
    });
    // Also clean the URL so refresh doesn't reapply filter
    if (GoRouter.of(context).canPop()) {
      context.go('/invoices');
    } else {
      GoRouter.of(context).go('/invoices');
    }
  }

  Future<void> _openQuickShop() async {
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _QuickShopDialog(),
    );
    if (ok == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Quick Shop saved')),
      );
      setState(() {}); // refresh list
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasFilter = (_filterPhone?.isNotEmpty ?? false) ||
        (_filterName?.isNotEmpty ?? false);

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Invoices',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 12),

          if (hasFilter)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white24),
              ),
              child: Row(
                children: [
                  const Icon(Icons.filter_alt, color: Colors.white70, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Filtered: '
                      '${_filterName ?? ''}'
                      '${(((_filterName ?? '').isNotEmpty) && ((_filterPhone ?? '').isNotEmpty)) ? " • " : ""}'
                      '${_filterPhone ?? ""}',
                      style: const TextStyle(color: Colors.white70),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton.icon(
                    onPressed: _clearFilter,
                    icon: const Icon(Icons.clear, color: Colors.white70, size: 18),
                    label: const Text('Clear', style: TextStyle(color: Colors.white70)),
                  ),
                ],
              ),
            ),

          Row(
            children: [
              _TabChip(
                label: 'Pending',
                selected: _tabIndex == 0,
                onTap: () => setState(() => _tabIndex = 0),
              ),
              const SizedBox(width: 8),
              _TabChip(
                label: 'Paid',
                selected: _tabIndex == 1,
                onTap: () => setState(() => _tabIndex = 1),
              ),
              const Spacer(),
              // Quick Shop lives here (Invoices screen)
              ElevatedButton.icon(
                onPressed: _openQuickShop,
                icon: const Icon(Icons.store_mall_directory_outlined),
                label: const Text('Quick Shop'),
                style: ElevatedButton.styleFrom(),
              ),
              const SizedBox(width: 8),
              TextButton.icon(
                onPressed: () => setState(() {}),
                icon: const Icon(Icons.refresh, color: Colors.white70, size: 18),
                label: const Text(
                  'Refresh',
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _useFallback
                ? _FallbackInvoices(
                    tabIndex: _tabIndex,
                    filterPhone: _filterPhone,
                    filterName: _filterName,
                  )
                : _LiveInvoices(
                    tabIndex: _tabIndex,
                    onSwitchToFallback: () => setState(() => _useFallback = true),
                    filterPhone: _filterPhone,
                    filterName: _filterName,
                  ),
          ),
        ],
      ),
    );
  }
}

class _LiveInvoices extends StatelessWidget {
  final int tabIndex;
  final VoidCallback onSwitchToFallback;

  final String? filterPhone;
  final String? filterName;

  const _LiveInvoices({
    required this.tabIndex,
    required this.onSwitchToFallback,
    this.filterPhone,
    this.filterName,
  });

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      return _ErrorState(message: 'Not signed in.', onRetry: () {});
    }

    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
      builder: (context, userSnap) {
        if (userSnap.hasError) {
          return _ErrorState(
            message: _safeErr('Failed to read user: ${userSnap.error}'),
            onRetry: () {},
          );
        }
        if (userSnap.connectionState == ConnectionState.waiting &&
            !userSnap.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.white));
        }

        final u = userSnap.data?.data() ?? const <String, dynamic>{};
        final role = (u['role'] as String?)?.toLowerCase() ?? '';
        final isSuper = role == 'superadmin';
        final branchIds = ((u['branchIds'] as List?) ?? const <dynamic>[])
            .whereType<String>()
            .toList(growable: false);

        if (!isSuper && branchIds.length > 10) {
          return _GuidanceState(
            title: 'Too many branches to filter in one query',
            message:
                'Your account has ${branchIds.length} branches. whereIn supports up to 10. '
                'Use the fallback loader or reduce assignments.',
            actions: [
              _GuidanceButton(
                icon: Icons.swap_horiz,
                label: 'Use branch-by-branch fallback',
                onPressed: onSwitchToFallback,
              ),
            ],
          );
        }

        Query<Map<String, dynamic>> q = FirebaseFirestore.instance
            .collectionGroup('sessions')
            .where('status', isEqualTo: 'completed');

        if (!isSuper && branchIds.isNotEmpty && branchIds.length <= 10) {
          q = q.where('branchId', whereIn: branchIds);
        }

        // ---- Customer filter (if present) ----
        if (filterPhone != null && filterPhone!.isNotEmpty) {
          q = q.where('customerPhone', isEqualTo: filterPhone);
        } else if (filterName != null && filterName!.isNotEmpty) {
          q = q.where('customerName', isEqualTo: filterName);
        }

        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: q.snapshots(),
          builder: (context, snap) {
            if (snap.hasError) {
              final msg = _safeErr(snap.error);
              if (msg.contains('failed-precondition') &&
                  msg.contains('create_exemption=')) {
                final url = _extractIndexUrl(msg);
                return _GuidanceState(
                  title: 'Firestore index required',
                  message:
                      'This collection-group query needs an index. '
                      'Create it using the link below, or use the fallback loader.',
                  actions: [
                    if (url != null)
                      _GuidanceButton(
                        icon: Icons.open_in_new,
                        label: 'Open Create Index link',
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Copy & open this URL:\n$url'),
                            ),
                          );
                        },
                      ),
                    _GuidanceButton(
                      icon: Icons.swap_horiz,
                      label: 'Use branch-by-branch fallback',
                      onPressed: onSwitchToFallback,
                    ),
                  ],
                );
              }
              return _ErrorState(
                message: 'Failed to load invoices.\n$msg',
                onRetry: () {},
              );
            }

            if (snap.connectionState == ConnectionState.waiting &&
                !snap.hasData) {
              return const Center(
                  child: CircularProgressIndicator(color: Colors.white));
            }

            final docs = snap.data?.docs ??
                const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
            final entries = _normalizeAndFilter(docs, tabIndex);
            if (entries.isEmpty) {
              return Center(
                child: Text(
                  tabIndex == 0
                      ? 'No pending invoices.'
                      : 'No paid invoices.',
                  style: const TextStyle(color: Colors.white70),
                ),
              );
            }
            return _InvoiceList(entries: entries, tabIndex: tabIndex);
          },
        );
      },
    );
  }
}

class _FallbackInvoices extends StatelessWidget {
  final int tabIndex;
  final String? filterPhone;
  final String? filterName;

  const _FallbackInvoices({
    required this.tabIndex,
    this.filterPhone,
    this.filterName,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<
        List<QueryDocumentSnapshot<Map<String, dynamic>>>>(
      future: _loadAllBranchInvoices(
        filterPhone: filterPhone,
        filterName: filterName,
      ),
      builder: (context, snap) {
        if (snap.hasError) {
          return _ErrorState(
            message:
                _safeErr('Failed to load (fallback): ${snap.error}'),
            onRetry: () {},
          );
        }
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.white));
        }
        final docs = snap.data ??
            const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
        final entries = _normalizeAndFilter(docs, tabIndex);
        if (entries.isEmpty) {
          return Center(
            child: Text(
              tabIndex == 0
                  ? 'No pending invoices.'
                  : 'No paid invoices.',
              style: const TextStyle(color: Colors.white70),
            ),
          );
        }
        return _InvoiceList(entries: entries, tabIndex: tabIndex);
      },
    );
  }

  static Future<List<QueryDocumentSnapshot<Map<String, dynamic>>>>
      _loadAllBranchInvoices({
    String? filterPhone,
    String? filterName,
  }) async {
    final bSnap =
        await FirebaseFirestore.instance.collection('branches').get();
    final branchIds = bSnap.docs.map((d) => d.id).toList();

    final futures = <Future<QuerySnapshot<Map<String, dynamic>>>>[];
    for (final bid in branchIds) {
      futures.add(
        FirebaseFirestore.instance
            .collection('branches')
            .doc(bid)
            .collection('sessions')
            .where('status', isEqualTo: 'completed')
            .get(),
      );
    }

    final results = await Future.wait(futures);
    final all = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
    for (final rs in results) {
      for (final d in rs.docs) {
        // Apply customer filter in-memory for fallback
        final m = d.data();
        final phone = (m['customerPhone'] ?? '').toString();
        final name = (m['customerName'] ?? '').toString();
        final phoneOk = (filterPhone == null || filterPhone!.isEmpty)
            ? true
            : phone == filterPhone;
        final nameOk = (filterName == null || filterName!.isEmpty)
            ? true
            : name == filterName;
        if (phoneOk && nameOk) {
          all.add(d);
        }
      }
    }
    return all;
  }
}

// ---------- Shared list rendering ----------

class _InvoiceList extends StatelessWidget {
  final List<
          MapEntry<QueryDocumentSnapshot<Map<String, dynamic>>,
              Map<String, dynamic>>>
      entries;
  final int tabIndex;

  const _InvoiceList({required this.entries, required this.tabIndex});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: entries.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final entry = entries[index];
        final doc = entry.key;
        final data = entry.value;

        final customerName =
            (data['customerName'] as String?)?.trim();
        final cust = (customerName == null || customerName.isEmpty)
            ? 'Guest'
            : customerName;

        final amount = (data['billAmount'] as double?) ?? 0.0;
        final closedAt = data['closedAt'] as DateTime?;
        final playedMinutes = (data['playedMinutes'] is num)
            ? (data['playedMinutes'] as num).toInt()
            : null;
        final invoiceNumber = data['invoiceNumber'];
        final branchId = (data['branchId'] as String?) ?? '';
        final payments =
            (data['payments'] as List<Map<String, dynamic>>?) ?? const [];
        final totalPaid = payments.fold<double>(0, (prev, e) {
          final amt = (e['amount'] is num)
              ? (e['amount'] as num).toDouble()
              : 0.0;
          return prev + amt;
        });
        final remaining = (amount - totalPaid);
        final remainingClamped = remaining < 0 ? 0.0 : remaining;

        final itemsOnly = data['itemsOnly'] == true;

        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF1F2937),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white12),
          ),
          child: Row(
            children: [
              const Icon(Icons.receipt_long_outlined, color: Colors.white70),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          cust,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (itemsOnly)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.2),
                              border: Border.all(color: Colors.white24),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: const Text(
                              'Items-only',
                              style: TextStyle(color: Colors.white70, fontSize: 11),
                            ),
                          ),
                      ],
                    ),
                    if (invoiceNumber != null)
                      Text(
                        invoiceNumber.toString(),
                        style: TextStyle(color: Colors.grey.shade400),
                      ),
                    Text(
                      closedAt != null ? closedAt.toLocal().toString() : '',
                      style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
                    ),
                    if (playedMinutes != null)
                      Text(
                        'Played: $playedMinutes minutes',
                        style: TextStyle(color: Colors.grey.shade400),
                      ),
                    if (payments.isNotEmpty)
                      Text(
                        'Paid: ₹${totalPaid.toStringAsFixed(2)} • Remaining: ₹${remainingClamped.toStringAsFixed(2)}',
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                  ],
                ),
              ),
              Text(
                '₹${amount.toStringAsFixed(0)}',
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton.icon(
                onPressed: branchId.isEmpty
                    ? null
                    : () async {
                        await InvoicePdfService().generateAndPrint(
                          branchId: branchId,
                          sessionId: doc.id,
                        );
                      },
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('PDF'),
              ),
              const SizedBox(width: 8),
              if (tabIndex == 0)
                OutlinedButton(
                  onPressed: () => _showRecordPaymentDialog(context, doc, amount),
                  child: const Text('Record Payment'),
                ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _showRecordPaymentDialog(
    BuildContext context,
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
    num billAmount,
  ) async {
    final data = doc.data();
    final existingPayments =
        (data['payments'] as List<dynamic>?) ?? <dynamic>[];
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _RecordPaymentDialog(
        sessionDoc: doc,
        sessionData: data,
        billAmount: billAmount.toDouble(),
        existingPayments: existingPayments
            .whereType<Map<String, dynamic>>()
            .toList(growable: false),
      ),
    );
  }
}

// ---------- Small UI helpers ----------

class _TabChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TabChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.white24),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final safe = _safeErr(message);
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              safe,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.redAccent),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh, color: Colors.white70, size: 18),
              label: const Text('Retry', style: TextStyle(color: Colors.white70)),
            ),
          ],
        ),
      ),
    );
  }
}

class _GuidanceState extends StatelessWidget {
  final String title;
  final String message;
  final List<Widget> actions;

  const _GuidanceState({
    required this.title,
    required this.message,
    required this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 680),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: actions,
            ),
          ],
        ),
      ),
    );
  }
}

class _GuidanceButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  const _GuidanceButton({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18, color: Colors.white),
      label: Text(label),
    );
  }
}

// ---------------------------------------------------------------------------
// RECORD PAYMENT DIALOG (unchanged schema; fixed UI state for rows)
// ---------------------------------------------------------------------------

class _RecordPaymentDialog extends StatefulWidget {
  final QueryDocumentSnapshot<Map<String, dynamic>> sessionDoc;
  final Map<String, dynamic> sessionData;
  final double billAmount;
  final List<Map<String, dynamic>> existingPayments;

  const _RecordPaymentDialog({
    required this.sessionDoc,
    required this.sessionData,
    required this.billAmount,
    required this.existingPayments,
  });

  @override
  State<_RecordPaymentDialog> createState() => _RecordPaymentDialogState();
}

class _PaymentRow {
  String mode;
  final TextEditingController amountCtrl;
  _PaymentRow({required this.mode, required this.amountCtrl});
}

class _RecordPaymentDialogState extends State<_RecordPaymentDialog> {
  final List<_PaymentRow> _rows = [];
  bool _saving = false;
  String? _error;

  double get _existingTotal =>
      widget.existingPayments.fold<double>(0, (prev, e) {
        final v = (e['amount'] as num?) ?? 0;
        return prev + v.toDouble();
      });

  double get _remaining => widget.billAmount - _existingTotal;

  @override
  void initState() {
    super.initState();
    final initialAmount = _remaining > 0 ? _remaining : 0;
    _rows.add(
      _PaymentRow(
        mode: 'cash',
        amountCtrl: TextEditingController(
          text: initialAmount.toStringAsFixed(0),
        ),
      ),
    );
  }

  @override
  void dispose() {
    for (final r in _rows) {
      r.amountCtrl.dispose();
    }
    super.dispose();
  }

  double _sumNewPayments() {
    double total = 0;
    for (final r in _rows) {
      final amt = double.tryParse(r.amountCtrl.text.trim()) ?? 0;
      total += amt;
    }
    return total;
  }

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final newPayments = <Map<String, dynamic>>[];
      for (final r in _rows) {
        final amt = double.tryParse(r.amountCtrl.text.trim()) ?? 0;
        if (amt <= 0) continue;
        newPayments.add({'mode': r.mode, 'amount': amt});
      }

      if (_remaining <= 0 && newPayments.isEmpty) {
        await widget.sessionDoc.reference.update({'paymentStatus': 'paid'});
        if (!mounted) return;
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invoice marked as paid')),
        );
        return;
      }

      if (newPayments.isEmpty) {
        setState(() {
          _error = 'Enter at least one valid payment amount.';
          _saving = false;
        });
        return;
      }

      final finalTotal = _existingTotal + _sumNewPayments();
      if ((finalTotal - widget.billAmount).abs() > 0.05) {
        setState(() {
          _error = 'Payment split must equal ₹${widget.billAmount.toStringAsFixed(2)}.\n'
              'Currently: ₹${finalTotal.toStringAsFixed(2)}.';
          _saving = false;
        });
        return;
      }

      final allPayments = [...widget.existingPayments, ...newPayments];
      await widget.sessionDoc.reference.update({
        'payments': allPayments,
        'paymentStatus': 'paid',
      });

      if (!mounted) return;
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invoice marked as paid')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = _safeErr('Failed to record payment: $e');
        _saving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.sessionData;
    final customerName = d['customerName']?.toString() ?? 'Guest';
    final customerPhone = d['customerPhone']?.toString() ?? '';
    final branchName = d['branchName']?.toString() ?? '';
    final seatLabel = d['seatLabel']?.toString() ?? '';
    final startTime = d['startTime'] as Timestamp?;
    final closedAt = d['closedAt'] as Timestamp?;
    final playedMinutes = (d['playedMinutes'] as num?)?.toInt();
    final subtotal = (d['subtotal'] as num?)?.toDouble() ?? widget.billAmount;
    final discount = (d['discount'] as num?)?.toDouble() ?? 0;
    final taxPercent = (d['taxPercent'] as num?)?.toDouble() ?? 0;
    final taxAmount = (d['taxAmount'] as num?)?.toDouble() ?? 0;

    final itemsOnly = d['itemsOnly'] == true;
    final rootOrders = (d['orders'] is List)
        ? (d['orders'] as List).whereType<Map<String, dynamic>>().toList(growable: false)
        : const <Map<String, dynamic>>[];

    return AlertDialog(
      backgroundColor: const Color(0xFF1F2937),
      contentPadding: const EdgeInsets.all(16),
      title: const Text('Invoice & Payment', style: TextStyle(color: Colors.white)),
      content: SizedBox(
        width: 720,
        child: SingleChildScrollView(
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Customer & Session',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                _KeyValueRow(
                  label: 'Customer',
                  value: customerPhone.isNotEmpty ? '$customerName • $customerPhone' : customerName,
                ),
                _KeyValueRow(
                  label: 'Branch & Seat',
                  value: [
                    if (branchName.isNotEmpty) branchName,
                    if (seatLabel.isNotEmpty) 'Seat $seatLabel',
                  ].join(' • '),
                ),
                _KeyValueRow(
                  label: 'Timing',
                  value: [
                    if (startTime != null) 'Start: ${startTime.toDate().toLocal()}',
                    if (closedAt != null) 'End: ${closedAt.toDate().toLocal()}',
                  ].join('\n'),
                ),
                if (playedMinutes != null)
                  _KeyValueRow(
                    label: 'Played',
                    value: '$playedMinutes minutes',
                  ),
                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 12),

                const Text(
                  'F&B / Orders',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),

                // subcollection first; fallback to root array if items-only
                FutureBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  future: widget.sessionDoc.reference
                      .collection('orders')
                      .orderBy('createdAt', descending: false)
                      .get(),
                  builder: (context, snap) {
                    if (snap.hasError) {
                      if (itemsOnly && rootOrders.isNotEmpty) {
                        return _renderRootOrders(rootOrders);
                      }
                      return Text(
                        'Failed to load F&B items: ${_safeErr(snap.error)}',
                        style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                      );
                    }
                    final docs = snap.data?.docs ?? [];
                    if (docs.isEmpty) {
                      if (itemsOnly && rootOrders.isNotEmpty) {
                        return _renderRootOrders(rootOrders);
                      }
                      return const Text('No F&B items added.', style: TextStyle(color: Colors.white70));
                    }
                    return Column(
                      children: docs.map((o) {
                        final od = o.data();
                        final itemName = od['itemName']?.toString() ?? 'Item';
                        final qty = (od['qty'] as num?)?.toInt() ?? 1;
                        final price = (od['price'] as num?)?.toDouble() ?? 0;
                        final total = (od['total'] as num?)?.toDouble() ?? (price * qty);
                        return Row(
                          children: [
                            Expanded(
                              child: Text('$itemName x$qty', style: const TextStyle(color: Colors.white)),
                            ),
                            Text('₹${total.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white)),
                          ],
                        );
                      }).toList(),
                    );
                  },
                ),

                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 12),

                const Text(
                  'Billing Breakdown',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                _KeyValueRow(label: 'Subtotal', value: '₹${subtotal.toStringAsFixed(2)}'),
                _KeyValueRow(
                  label: 'Discount',
                  value: discount == 0 ? '₹0.00' : '- ₹${discount.toStringAsFixed(2)}',
                ),
                _KeyValueRow(
                  label: 'Tax',
                  value: '${taxPercent.toStringAsFixed(1)}% • ₹${taxAmount.toStringAsFixed(2)}',
                ),
                const SizedBox(height: 4),
                _KeyValueRow(
                  label: 'Total Payable',
                  value: '₹${widget.billAmount.toStringAsFixed(2)}',
                  highlight: true,
                ),

                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 12),

                if (widget.existingPayments.isNotEmpty) ...[
                  const Text(
                    'Existing Payments',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Column(
                    children: widget.existingPayments.map((p) {
                      final mode = p['mode']?.toString().toUpperCase() ?? 'N/A';
                      final amount = (p['amount'] as num?)?.toDouble() ?? 0;
                      return Row(
                        children: [
                          Expanded(child: Text(mode, style: const TextStyle(color: Colors.white70))),
                          Text('₹${amount.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white70)),
                        ],
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 4),
                  _KeyValueRow(label: 'Total Already Paid', value: '₹${_existingTotal.toStringAsFixed(2)}'),
                  _KeyValueRow(
                    label: 'Remaining to Collect',
                    value: '₹${_remaining <= 0 ? '0.00' : _remaining.toStringAsFixed(2)}',
                    highlight: true,
                  ),
                  const SizedBox(height: 16),
                ],

                const Text(
                  'Record Payment (split by mode)',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Column(
                  children: [
                    for (int i = 0; i < _rows.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: DropdownButtonFormField<String>(
                                value: _rows[i].mode,
                                dropdownColor: const Color(0xFF111827),
                                decoration: const InputDecoration(
                                  labelText: 'Mode',
                                  labelStyle: TextStyle(color: Colors.white70),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white24),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.white),
                                items: const [
                                  DropdownMenuItem(value: 'cash', child: Text('Cash')),
                                  DropdownMenuItem(value: 'card', child: Text('Card')),
                                  DropdownMenuItem(value: 'upi', child: Text('UPI')),
                                  DropdownMenuItem(value: 'other', child: Text('Other')),
                                ],
                                onChanged: (v) => _rows[i].mode = v ?? 'cash',
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 2,
                              child: TextField(
                                controller: _rows[i].amountCtrl,
                                style: const TextStyle(color: Colors.white),
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Amount',
                                  labelStyle: TextStyle(color: Colors.white70),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white24),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                  ),
                                ),
                                onChanged: (_) => setState(() {}),
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (_rows.length > 1)
                              IconButton(
                                tooltip: 'Remove row',
                                onPressed: () {
                                  setState(() {
                                    final r = _rows.removeAt(i);
                                    r.amountCtrl.dispose();
                                  });
                                },
                                icon: const Icon(Icons.remove_circle_outline, color: Colors.redAccent),
                              ),
                          ],
                        ),
                      ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _rows.add(
                              _PaymentRow(
                                mode: 'cash',
                                amountCtrl: TextEditingController(),
                              ),
                            );
                          });
                        },
                        icon: const Icon(Icons.add, color: Colors.white, size: 18),
                        label: const Text('Add another payment', style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _KeyValueRow(
                  label: 'New Payments Total',
                  value: '₹${_sumNewPayments().toStringAsFixed(2)}',
                ),
                _KeyValueRow(
                  label: 'Final Total (existing + new)',
                  value: '₹${(_existingTotal + _sumNewPayments()).toStringAsFixed(2)}',
                  highlight: true,
                ),

                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _error!,
                    style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          child: _saving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Mark as Paid'),
        ),
      ],
    );
  }

  Widget _renderRootOrders(List<Map<String, dynamic>> orders) {
    if (orders.isEmpty) {
      return const Text('No F&B items added.', style: TextStyle(color: Colors.white70));
    }
    return Column(
      children: orders.map((od) {
        final itemName = od['name']?.toString() ?? 'Item';
        final qty = (od['qty'] as num?)?.toInt() ?? 1;
        final price = (od['price'] as num?)?.toDouble() ?? 0.0;
        final total = (od['total'] as num?)?.toDouble() ?? (price * qty);
        return Row(
          children: [
            Expanded(
              child: Text('$itemName x$qty', style: const TextStyle(color: Colors.white)),
            ),
            Text('₹${total.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white)),
          ],
        );
      }).toList(),
    );
  }
}

class _KeyValueRow extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;

  const _KeyValueRow({
    required this.label,
    required this.value,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              label,
              style: TextStyle(
                color: Colors.grey.shade300,
                fontWeight: highlight ? FontWeight.w600 : FontWeight.w500,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: highlight ? Colors.white : Colors.white70,
                fontWeight: highlight ? FontWeight.w600 : FontWeight.w400,
                fontSize: highlight ? 13 : 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------- Shared helpers (defined ONCE) ----------

List<
    MapEntry<QueryDocumentSnapshot<Map<String, dynamic>>,
        Map<String, dynamic>>> _normalizeAndFilter(
  List<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
  int tabIndex,
) {
  final normalized = <MapEntry<QueryDocumentSnapshot<Map<String, dynamic>>, Map<String, dynamic>>>[];

  for (final d in docs) {
    try {
      final m = d.data();
      if (m['status'] != 'completed') continue;

      final paymentStatus = (m['paymentStatus'] as String?)?.trim().toLowerCase();
      final safeStatus = (paymentStatus == 'paid' || paymentStatus == 'pending') ? paymentStatus! : 'pending';

      final closedAtTs = m['closedAt'];
      final closedAt = (closedAtTs is Timestamp) ? closedAtTs.toDate() : null;

      final billAmount = (m['billAmount'] is num) ? (m['billAmount'] as num).toDouble() : 0.0;

      final rawPayments = m['payments'];
      final payments = <Map<String, dynamic>>[];
      if (rawPayments is List) {
        for (final p in rawPayments) {
          if (p is Map<String, dynamic>) {
            final mode = (p['mode'] as String?) ?? 'other';
            final amt = (p['amount'] is num) ? (p['amount'] as num).toDouble() : 0.0;
            payments.add({'mode': mode, 'amount': amt});
          }
        }
      }

      final entry = MapEntry<QueryDocumentSnapshot<Map<String, dynamic>>, Map<String, dynamic>>(
        d,
        {
          ...m,
          'paymentStatus': safeStatus,
          'closedAt': closedAt,
          'billAmount': billAmount,
          'payments': payments,
        },
      );
      normalized.add(entry);
    } catch (_) {}
  }

  final filtered = normalized.where((e) {
    final ps = (e.value['paymentStatus'] as String?) ?? 'pending';
    return tabIndex == 0 ? ps == 'pending' : ps == 'paid';
  }).toList()
    ..sort((a, b) {
      final aDt = a.value['closedAt'] as DateTime?;
      final bDt = b.value['closedAt'] as DateTime?;
      if (aDt == null && bDt == null) return 0;
      if (aDt == null) return 1;
      if (bDt == null) return -1;
      return bDt.compareTo(aDt);
    });

  return filtered;
}

String _safeErr(Object? e) {
  try {
    return e?.toString() ?? 'Unknown error';
  } catch (_) {
    return 'Unknown error';
  }
}

String? _extractIndexUrl(String msg) {
  final start = msg.indexOf('https://console.firebase.google.com');
  if (start == -1) return null;
  final space = msg.indexOf(' ', start);
  final end = space == -1 ? msg.length : space;
  return msg.substring(start, end).trim();
}

Future<void> _showLongErrorDialog(BuildContext context, String title, Object error, [StackTrace? st]) async {
  // ignore: avoid_print
  print('[$title] $error');
  if (st != null) {
    // ignore: avoid_print
    print(st);
  }

  final msg = _safeErr(error);

  return showDialog(
    context: context,
    barrierDismissible: true,
    builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF1F2937),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      content: SizedBox(
        width: 700,
        child: SingleChildScrollView(
          child: SelectableText(
            msg,
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------
// Quick Shop Dialog (two modes: Bill Only | Blank Session)
// Bill Only now uses Inventory picker + qty stepper + stock checks + stock deduction.
// ---------------------------------------------------------------------------

class _QuickShopDialog extends StatefulWidget {
  const _QuickShopDialog();

  @override
  State<_QuickShopDialog> createState() => _QuickShopDialogState();
}

class _QuickShopDialogState extends State<_QuickShopDialog> {
  // Mode: 'billOnly' (instant invoice) | 'blankSession' (reserved)
  String _mode = 'billOnly';

  // Branch
  String? _branchId;
  String? _branchName;

  // Customer
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  // Items (for billOnly) — inventory bound
  final List<_QSInvItem> _items = [ _QSInvItem.initial() ];

  // Money
  double _taxPercent = 0;
  double _discount = 0;
  String _paymentStatus = 'paid'; // 'paid'|'pending' (for billOnly)

  bool _saving = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  String _normalizePhone(String raw) {
    var s = raw.replaceAll(RegExp(r'\D'), '');
    if (s.startsWith('91') && s.length == 12) s = s.substring(2);
    if (s.startsWith('0') && s.length == 11) s = s.substring(1);
    return s;
  }

  double get _ordersSubtotal {
    double s = 0;
    for (final it in _items) {
      if (!it.isValid) continue;
      s += it.qty * it.price;
    }
    return s;
  }

  double get _taxAmount {
    final base = (_ordersSubtotal - _discount);
    final safe = base < 0 ? 0.0 : base;
    return safe * (_taxPercent / 100.0);
  }

  double get _billAmount => (_ordersSubtotal - _discount).clamp(0, double.infinity) + _taxAmount;

  bool get _canSubmit {
    if (_branchId == null || _branchId!.isEmpty) return false;
    if (_mode == 'blankSession') return true;
    // billOnly requires at least one valid item
    return _items.any((it) => it.isValid);
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    return AlertDialog(
      backgroundColor: const Color(0xFF1F2937),
      title: const Text('Quick Shop', style: TextStyle(color: Colors.white)),
      content: SizedBox(
        width: 720,
        child: DefaultTextStyle(
          style: const TextStyle(color: Colors.white),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Branch picker (role-scoped)
              FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                future: uid == null
                    ? null
                    : FirebaseFirestore.instance.collection('users').doc(uid).get(),
                builder: (context, userSnap) {
                  final u = userSnap.data?.data();
                  final role = (u?['role'] as String?)?.toLowerCase() ?? 'staff';
                  final allowed = ((u?['branchIds'] as List?) ?? const []).whereType<String>().toSet();

                  return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: FirebaseFirestore.instance.collection('branches').snapshots(),
                    builder: (context, snap) {
                      final all = snap.data?.docs ?? const [];
                      final scoped = (role == 'superadmin' || allowed.isEmpty)
                          ? all
                          : all.where((d) => allowed.contains(d.id)).toList();

                      return DropdownButtonFormField<String>(
                        value: _branchId,
                        dropdownColor: const Color(0xFF111827),
                        decoration: const InputDecoration(
                          labelText: 'Branch',
                          labelStyle: TextStyle(color: Colors.white70),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white24),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        items: scoped
                            .map((d) => DropdownMenuItem(
                                  value: d.id,
                                  child: Text(d['name'] ?? 'Branch'),
                                ))
                            .toList(),
                        onChanged: (v) {
                          setState(() {
                            _branchId = v;
                            if (v != null) {
                              final doc = scoped.firstWhere((e) => e.id == v);
                              _branchName = (doc['name'] ?? '').toString();
                              // reset items (branch scoped)
                              for (final it in _items) {
                                it.clearSelection();
                              }
                            } else {
                              _branchName = null;
                            }
                          });
                        },
                      );
                    },
                  );
                },
              ),

              const SizedBox(height: 12),

              // Mode selector
              Align(
                alignment: Alignment.centerLeft,
                child: Wrap(
                  spacing: 16,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Radio<String>(
                          value: 'billOnly',
                          groupValue: _mode,
                          onChanged: (v) => setState(() => _mode = v ?? 'billOnly'),
                          fillColor: MaterialStateProperty.all(Colors.white),
                        ),
                        const Text('Bill Only (no seat / instant invoice)', style: TextStyle(color: Colors.white70)),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Radio<String>(
                          value: 'blankSession',
                          groupValue: _mode,
                          onChanged: (v) => setState(() => _mode = v ?? 'blankSession'),
                          fillColor: MaterialStateProperty.all(Colors.white),
                        ),
                        const Text('Blank Session (reserved, manage later)', style: TextStyle(color: Colors.white70)),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // Customer
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _nameCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        labelText: 'Customer name (optional)',
                        labelStyle: TextStyle(color: Colors.white70),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _phoneCtrl,
                      style: const TextStyle(color: Colors.white),
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        labelText: 'Customer phone (optional)',
                        labelStyle: TextStyle(color: Colors.white70),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              // Items + money controls (only when billOnly)
              if (_mode == 'billOnly') ...[
                _itemsHeader(),
                const SizedBox(height: 8),

                Flexible(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        for (int i = 0; i < _items.length; i++) _itemRow(i),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: TextButton.icon(
                            onPressed: () => setState(() => _items.add(_QSInvItem.initial())),
                            icon: const Icon(Icons.add, color: Colors.white),
                            label: const Text('Add item', style: TextStyle(color: Colors.white)),
                          ),
                        ),

                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: _numField(
                                label: 'Discount (₹)',
                                value: _discount,
                                onChanged: (v) => setState(() => _discount = (double.tryParse(v) ?? 0).clamp(0, 1e12)),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _numField(
                                label: 'Tax (%)',
                                value: _taxPercent,
                                onChanged: (v) => setState(() => _taxPercent = (double.tryParse(v) ?? 0).clamp(0, 100)),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF111827),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.white24),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _sumLine('Items Subtotal', _ordersSubtotal),
                                    _sumLine('Discount', -_discount),
                                    _sumLine('Tax', _taxAmount),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  const Text('Total', style: TextStyle(color: Colors.white60)),
                                  Text('₹ ${_billAmount.toStringAsFixed(2)}',
                                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Text('Payment:', style: TextStyle(color: Colors.white70)),
                            const SizedBox(width: 8),
                            DropdownButton<String>(
                              value: _paymentStatus,
                              dropdownColor: const Color(0xFF111827),
                              style: const TextStyle(color: Colors.white),
                              items: const [
                                DropdownMenuItem(value: 'paid', child: Text('Paid')),
                                DropdownMenuItem(value: 'pending', child: Text('Pending')),
                              ],
                              onChanged: (v) => setState(() => _paymentStatus = v ?? 'paid'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ] else
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'This will create a reserved, seatless session (no items). Staff can manage it later from Bookings → Actions.',
                    style: TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(false),
          child: const Text('Cancel'),
        ),
        ElevatedButton.icon(
          onPressed: _saving || !_canSubmit ? null : _submit,
          icon: _saving
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.check),
          label: Text(_mode == 'billOnly' ? 'Generate Bill' : 'Create Blank Session'),
        ),
      ],
    );
  }

  InputDecoration _dec(String label) => const InputDecoration(
        labelText: '',
        labelStyle: TextStyle(color: Colors.white70),
        enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
        focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
      );

  Widget _itemsHeader() {
    return Row(
      children: const [
        Expanded(flex: 7, child: Text('Item', style: TextStyle(color: Colors.white54))),
        Expanded(flex: 3, child: Text('Qty', style: TextStyle(color: Colors.white54))),
        Expanded(flex: 3, child: Text('Price', style: TextStyle(color: Colors.white54))),
        SizedBox(width: 40),
      ],
    );
  }

  Widget _itemRow(int i) {
    final it = _items[i];
    final disabled = _branchId == null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          // Item picker (readOnly field opens selector)
          Expanded(
            flex: 7,
            child: InkWell(
              onTap: disabled ? null : () => _openInventoryPicker(i),
              child: InputDecorator(
                decoration: const InputDecoration(
                  hintText: 'Select item from inventory',
                  hintStyle: TextStyle(color: Colors.white38),
                  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                ),
                child: Text(
                  it.name.isEmpty ? 'Tap to select' : it.name,
                  style: TextStyle(color: it.name.isEmpty ? Colors.white38 : Colors.white),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),

          // Qty stepper
          Expanded(
            flex: 3,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white24),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: disabled || it.qty <= 1
                        ? null
                        : () => setState(() => it.qty -= 1),
                    icon: const Icon(Icons.remove, color: Colors.white70),
                    splashRadius: 18,
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        it.qty.toString(),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: disabled
                        ? null
                        : () => setState(() => it.qty += 1),
                    icon: const Icon(Icons.add, color: Colors.white70),
                    splashRadius: 18,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),

          // Price (read only)
          Expanded(
            flex: 3,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white24),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                it.price <= 0 ? '₹ 0.00' : '₹ ${it.price.toStringAsFixed(2)}',
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ),
          const SizedBox(width: 8),

          IconButton(
            onPressed: _items.length == 1 ? null : () => setState(() => _items.removeAt(i)),
            icon: const Icon(Icons.delete_outline, color: Colors.white54),
          ),
        ],
      ),
    );
  }

  Widget _numField({required String label, required double value, required ValueChanged<String> onChanged}) {
    return TextField(
      onChanged: onChanged,
      style: const TextStyle(color: Colors.white),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        enabledBorder: const OutlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
        focusedBorder: const OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
      ),
    );
  }

  Widget _sumLine(String label, double amt) {
    final sign = amt < 0 ? '-' : '+';
    final abs = amt.abs();
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white60))),
          Text('$sign ₹ ${abs.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white)),
        ],
      ),
    );
  }

  Future<void> _openInventoryPicker(int index) async {
    if (_branchId == null) return;

    final selected = await showDialog<InventoryItemModel>(
      context: context,
      builder: (_) => _InventoryPickerDialog(branchId: _branchId!),
    );

    if (selected != null) {
      setState(() {
        _items[index]
          ..itemId = selected.id
          ..name = selected.name
          ..price = (selected.price as num).toDouble()
          ..maxStock = (selected.stockQty as num).toInt()
          ..qty = 1; // reset to 1 on change
      });
    }
  }

  Future<void> _submit() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final fs = FirebaseFirestore.instance;
      final now = DateTime.now();

      // current user audit
      final currentUser = FirebaseAuth.instance.currentUser;
      String? createdByName;
      if (currentUser != null) {
        final userDoc = await fs.collection('users').doc(currentUser.uid).get();
        if (userDoc.exists) {
          createdByName = (userDoc.data()?['name'] as String?) ?? currentUser.email;
        }
      }

      final sessionsCol = fs.collection('branches').doc(_branchId).collection('sessions');

      if (_mode == 'blankSession') {
        await sessionsCol.add({
          'status': 'reserved',
          'paymentStatus': 'pending',
          'branchId': _branchId,
          'branchName': _branchName,
          'seatId': null,
          'seatLabel': '—',
          'pax': 1,
          'startTime': Timestamp.fromDate(now),
          'durationMinutes': 60,
          // money defaults
          'ordersSubtotal': 0.0,
          'subtotal': 0.0,
          'discount': 0.0,
          'taxPercent': 0.0,
          'taxAmount': 0.0,
          'billAmount': 0.0,
          'playedMinutes': 0,
          // customer
          if (_nameCtrl.text.trim().isNotEmpty) 'customerName': _nameCtrl.text.trim(),
          if (_phoneCtrl.text.trim().isNotEmpty) 'customerPhone': _normalizePhone(_phoneCtrl.text),
          // audit
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
          if (currentUser != null) 'createdBy': currentUser.uid,
          if (createdByName != null) 'createdByName': createdByName,
          'quickShop': true,
          'quickShopMode': 'blankSession',
        });
      } else {
        // --- compute money safely first ---
        final rawSubtotal = (_ordersSubtotal - _discount);
        final safeSubtotal = rawSubtotal < 0 ? 0.0 : rawSubtotal;
        final taxAmt = safeSubtotal * (_taxPercent / 100.0);
        final totalPayable = safeSubtotal + taxAmt;

        // --- items array (inventory-bound) ---
        final items = _items.where((e) => e.isValid).map((e) => {
          'itemId': e.itemId,
          'name': e.name,
          'qty': e.qty,
          'price': e.price,
          'total': e.qty * e.price,
        }).toList();

        // --- payments array based on status ---
        final List<Map<String, dynamic>> payments =
            (_paymentStatus == 'paid') ? [{'mode': 'cash', 'amount': totalPayable}] : const [];

        final docRef = sessionsCol.doc();
        final invoiceNo = _genInvoiceNumber(docRef.id, now);

        // Transaction: validate stock & deduct stock for ALL items
        await fs.runTransaction((tx) async {
          // 1) Validate & stage inventory updates
          final stagedUpdates = <DocumentReference<Map<String, dynamic>>, num>{};

          for (final it in _items.where((e) => e.isValid)) {
            final invRef = fs
                .collection('branches')
                .doc(_branchId)
                .collection('inventory')
                .doc(it.itemId);

            final snap = await tx.get(invRef);
            if (!snap.exists) {
              throw Exception('Inventory item not found: ${it.name}');
            }
            final data = snap.data()!;
            final stock = InventoryItemModel._numOrZero(data['stockQty']);
            if (it.qty > stock) {
              throw Exception('Not enough stock for "${it.name}". Available: $stock, asked: ${it.qty}.');
            }
            stagedUpdates[invRef] = stock - it.qty;
          }

          // 2) Write the session doc first (Close & Bill invariant compatible)
          tx.set(docRef, {
            'status': 'completed',
            'paymentStatus': _paymentStatus,  // 'paid' | 'pending'
            'payments': payments,             // ALWAYS present (possibly empty)
            'itemsOnly': true,
            'hiddenFromBookings': true,
            'quickShop': true,
            'quickShopMode': 'billOnly',

            'branchId': _branchId,
            'branchName': _branchName,

            'seatId': null,
            'seatLabel': '—',
            'pax': 1,

            'startTime': Timestamp.fromDate(now),
            'closedAt': Timestamp.fromDate(now),
            'playedMinutes': 0,

            // Money (same invariant as Close & Bill writes money)
            'ordersSubtotal': _ordersSubtotal,
            'subtotal': safeSubtotal,
            'discount': _discount,
            'taxPercent': _taxPercent,
            'taxAmount': taxAmt,
            'billAmount': totalPayable,

            // Invoice/meta
            'invoiceNumber': invoiceNo,

            // Customer (optional)
            if (_nameCtrl.text.trim().isNotEmpty) 'customerName': _nameCtrl.text.trim(),
            if (_phoneCtrl.text.trim().isNotEmpty) 'customerPhone': _normalizePhone(_phoneCtrl.text),

            // Orders array (for PDF/dialog fallback)
            'orders': items,

            // Audit
            'createdAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
            if (currentUser != null) 'createdBy': currentUser.uid,
            if (createdByName != null) 'createdByName': createdByName,
            if (currentUser != null) 'closedBy': currentUser.uid,
            if (createdByName != null) 'closedByName': createdByName,
          });

          // 3) Apply inventory decrements
          stagedUpdates.forEach((ref, newStock) {
            tx.update(ref, {'stockQty': newStock});
          });
        });
      }

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e, st) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: ${_safeErr(e)}')),
      );
      await _showLongErrorDialog(context, 'Quick Shop failed', e, st);
    }
  }

  String _genInvoiceNumber(String docId, DateTime now) {
    final y = now.year.toString();
    final m = now.month.toString().padLeft(2, '0');
    final d = now.day.toString().padLeft(2, '0');
    final h = now.hour.toString().padLeft(2, '0');
    final min = now.minute.toString().padLeft(2, '0');
    final s = now.second.toString().padLeft(2, '0');
    return 'INV-$y$m$d-$h$min$s';
  }
}

// ==== Inventory Picker dialog ====
// Simple list with a search box; filters active items, shows stock.
class _InventoryPickerDialog extends StatefulWidget {
  final String branchId;
  const _InventoryPickerDialog({required this.branchId});

  @override
  State<_InventoryPickerDialog> createState() => _InventoryPickerDialogState();
}

class _InventoryPickerDialogState extends State<_InventoryPickerDialog> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF1F2937),
      title: const Text('Select item', style: TextStyle(color: Colors.white)),
      content: SizedBox(
        width: 560,
        height: 460,
        child: Column(
          children: [
            TextField(
              onChanged: (v) => setState(() => _q = v.trim().toLowerCase()),
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Search',
                labelStyle: TextStyle(color: Colors.white70),
                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
                focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: FirebaseFirestore.instance
                    .collection('branches')
                    .doc(widget.branchId)
                    .collection('inventory')
                    .where('active', isEqualTo: true)
                    .snapshots(),
                builder: (context, snap) {
                  if (snap.hasError) {
                    return Center(
                      child: Text('Failed to load inventory: ${_safeErr(snap.error)}',
                          style: const TextStyle(color: Colors.redAccent)),
                    );
                  }
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator(color: Colors.white));
                  }
                  final all = snap.data!.docs
                      .map((d) => InventoryItemModel.fromMap(d.id, d.data()))
                      .toList();
                  final filtered = _q.isEmpty
                      ? all
                      : all.where((i) => i.name.toLowerCase().contains(_q)).toList();
                  if (filtered.isEmpty) {
                    return const Center(child: Text('No items', style: TextStyle(color: Colors.white70)));
                  }
                  return ListView.separated(
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const Divider(color: Colors.white10, height: 1),
                    itemBuilder: (_, i) {
                      final it = filtered[i];
                      final stock = (it.stockQty as num).toInt();
                      final price = (it.price as num).toDouble();
                      return ListTile(
                        onTap: () => Navigator.of(context).pop(it),
                        title: Text(it.name, style: const TextStyle(color: Colors.white)),
                        subtitle: Text('₹ ${price.toStringAsFixed(2)} • Stock: $stock',
                            style: const TextStyle(color: Colors.white70, fontSize: 12)),
                        trailing: const Icon(Icons.chevron_right, color: Colors.white54),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
      ],
    );
  }
}

// ==== QS Inventory item model used by dialog state ====
class _QSInvItem {
  String itemId;
  String name;
  int qty;
  double price;
  int maxStock;

  _QSInvItem({
    required this.itemId,
    required this.name,
    required this.qty,
    required this.price,
    required this.maxStock,
  });

  factory _QSInvItem.initial() => _QSInvItem(
        itemId: '',
        name: '',
        qty: 1,
        price: 0,
        maxStock: 0,
      );

  bool get isValid => itemId.isNotEmpty && name.isNotEmpty && qty > 0 && price >= 0;

  void clearSelection() {
    itemId = '';
    name = '';
    qty = 1;
    price = 0;
    maxStock = 0;
  }
}

// ---------------------------------------------------------------------------
// InventoryItemModel (as you provided; kept here for self-contained file)
// ---------------------------------------------------------------------------

class InventoryItemModel {
  final String id;
  final String name;
  final num price;
  final num stockQty;
  final String? sku;
  final bool active;

  /// When stockQty <= reorderThreshold → item is treated as "Low stock"
  final num reorderThreshold;

  InventoryItemModel({
    required this.id,
    required this.name,
    required this.price,
    required this.stockQty,
    this.sku,
    required this.active,
    this.reorderThreshold = 0,
  });

  static num _numOrZero(dynamic v) {
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  factory InventoryItemModel.fromMap(String id, Map<String, dynamic> data) {
    return InventoryItemModel(
      id: id,
      name: data['name'] ?? '',
      price: _numOrZero(data['price']),
      stockQty: _numOrZero(data['stockQty']),
      sku: data['sku'],
      active: data['active'] ?? true,
      reorderThreshold: _numOrZero(data['reorderThreshold']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'price': price,
      'stockQty': stockQty,
      'sku': sku,
      'active': active,
      'reorderThreshold': reorderThreshold,
    };
  }
}
