import 'package:flutter/foundation.dart';

class SideNavController extends ChangeNotifier {
  bool _isExpanded = false;

  bool get isExpanded => _isExpanded;

  void toggle() {
    _isExpanded = !_isExpanded;
    notifyListeners();
  }

  void setExpanded(bool v) {
    _isExpanded = v;
    notifyListeners();
  }
}

// global singleton
final sideNavController = SideNavController();
