import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'add_order_dialog.dart';
import 'booking_move_seat_dialog.dart';
import 'booking_close_bill_dialog.dart';

enum SessionState {
  activeLive,
  activeOverdue,
  reservedFuture,
  reservedPast,
  completed,
  cancelled,
}

DateTime _tsUtc(dynamic ts) =>
    (ts is Timestamp ? ts.toDate() : (ts as DateTime?))?.toUtc() ??
    DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);

SessionState _stateOf(Map<String, dynamic> s) {
  final now = DateTime.now().toUtc();
  final status = (s['status'] as String?) ?? 'reserved';
  final start = _tsUtc(s['startTime']);
  final durationMins = (s['durationMinutes'] as num?)?.toInt() ?? 0;
  final endAt = start.add(Duration(minutes: durationMins));

  if (status == 'completed') return SessionState.completed;
  if (status == 'cancelled') return SessionState.cancelled;

  if (status == 'active') {
    return now.isBefore(endAt)
        ? SessionState.activeLive
        : SessionState.activeOverdue;
  }

  if (status == 'reserved') {
    return start.isAfter(now)
        ? SessionState.reservedFuture
        : SessionState.reservedPast;
  }

  return SessionState.cancelled;
}

class BookingActionsDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingActionsDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingActionsDialog> createState() => _BookingActionsDialogState();
}

class _BookingActionsDialogState extends State<BookingActionsDialog> {
  bool _busy = false;

  Future<void> _extendBy(int minutes) async {
    setState(() => _busy = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      final current = (snap.data() ?? {}) as Map<String, dynamic>;
      final currentDuration = (current['durationMinutes'] as num?)?.toInt() ?? 0;
      tx.update(docRef, {
        'durationMinutes': currentDuration + minutes,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });

    if (mounted) {
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Extended by $minutes minutes')),
      );
    }
  }

  Future<void> _startNow() async {
    setState(() => _busy = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await docRef.update({
      'status': 'active',
      'startTime': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      setState(() => _busy = false);
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Session started')));
    }
  }

  Future<void> _cancelReservation() async {
    setState(() => _busy = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await docRef.update({
      'status': 'cancelled',
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      setState(() => _busy = false);
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Reservation cancelled')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cust = widget.data['customerName'] ?? '';
    final seatId = widget.data['seatId'] ?? '';
    final seat = widget.data['seatLabel'] ?? '';
    final duration = (widget.data['durationMinutes'] as num?)?.toInt() ?? 0;
    final state = _stateOf(widget.data);

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      insetPadding: const EdgeInsets.all(20),
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Booking Actions',
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: Colors.white),
            ),
            const SizedBox(height: 10),
            Text('Customer: $cust', style: const TextStyle(color: Colors.white)),
            Text('Seat: $seat', style: const TextStyle(color: Colors.white70)),
            Text('Duration: $duration mins',
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),

            // State-aware actions
            if (state == SessionState.activeLive) ...[
              _actionBtn(
                icon: Icons.add_alarm,
                label: _busy ? 'Extending...' : 'Extend by 30 mins',
                onTap: _busy ? null : () => _extendBy(30),
              ),
              const SizedBox(height: 10),
              _actionBtn(
                icon: Icons.add_shopping_cart_outlined,
                label: 'Add Order',
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => AddOrderDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _actionBtn(
                icon: Icons.chair_outlined,
                label: 'Move Seat',
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => BookingMoveSeatDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    currentSeatId: seatId.toString(),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _actionBtn(
                icon: Icons.payments_outlined,
                label: 'Close & Bill',
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    data: widget.data,
                  ),
                ),
              ),
            ] else if (state == SessionState.activeOverdue) ...[
              _actionBtn(
                icon: Icons.add_alarm,
                label: _busy ? 'Extending...' : 'Extend by 30 mins',
                onTap: _busy ? null : () => _extendBy(30),
              ),
              const SizedBox(height: 10),
              _actionBtn(
                icon: Icons.payments_outlined,
                label: 'Close (Overdue)',
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    data: widget.data,
                  ),
                ),
              ),
            ] else if (state == SessionState.reservedFuture) ...[
              _actionBtn(
                icon: Icons.play_circle_outline,
                label: _busy ? 'Starting...' : 'Start Now',
                onTap: _busy ? null : _startNow,
              ),
              const SizedBox(height: 10),
              _actionBtn(
                icon: Icons.cancel_outlined,
                label: _busy ? 'Cancelling...' : 'Cancel Reservation',
                onTap: _busy ? null : _cancelReservation,
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white10,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white12),
                ),
                child: const Text(
                  'No actions available for this session state.',
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            ],

            const SizedBox(height: 12),
            const Text(
              'Now supports split payment, discount and tax.',
              style: TextStyle(fontSize: 11, color: Colors.white38),
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 42,
      child: ElevatedButton.icon(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF111827),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
          elevation: 0,
        ),
        icon: Icon(icon, size: 18),
        label: Text(label),
      ),
    );
  }
}
