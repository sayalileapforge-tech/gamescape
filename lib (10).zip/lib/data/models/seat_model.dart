class SeatModel {
  final String id;
  final String label;
  final String type; // e.g. "PC", "VIP", "Console"
  final num ratePerHour;
  final bool active;

  SeatModel({
    required this.id,
    required this.label,
    required this.type,
    required this.ratePerHour,
    required this.active,
  });

  factory SeatModel.fromMap(String id, Map<String, dynamic> data) {
    return SeatModel(
      id: id,
      label: data['label'] ?? '',
      type: data['type'] ?? 'Standard',
      ratePerHour: data['ratePerHour'] ?? 0,
      active: data['active'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'label': label,
      'type': type,
      'ratePerHour': ratePerHour,
      'active': active,
    };
  }
}
