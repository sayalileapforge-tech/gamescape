import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../core/widgets/app_shell.dart';

class UserManagementScreen extends StatelessWidget {
  const UserManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'User Management',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 6),
          const _RoleHelpNote(),
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () async {
                final created = await showDialog<bool>(
                  context: context,
                  builder: (_) => const _CreateUserDialog(),
                );
                if (created == true && context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('User created')),
                  );
                }
              },
              icon: const Icon(Icons.person_add, color: Colors.white),
              label: const Text(
                'Create User',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .orderBy('name')
                  .snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snap.data!.docs;
                return ListView.separated(
                  itemCount: docs.length,
                  separatorBuilder: (_, __) =>
                      const Divider(color: Colors.white12),
                  itemBuilder: (context, index) {
                    final d = docs[index];
                    final data =
                        d.data() as Map<String, dynamic>? ?? {};
                    final name =
                        data['name']?.toString() ?? 'User';
                    final email = data['email']?.toString() ?? '';
                    final role =
                        data['role']?.toString() ?? 'staff';
                    final branches =
                        (data['branchIds'] as List?)?.cast<String>() ??
                            [];
                    final mustChange =
                        data['mustChangePassword'] == true;

                    // Do NOT show raw IDs / passwords – just a friendly
                    // summary so nothing that looks like a password leaks.
                    String branchLabel = '';
                    if (branches.isNotEmpty) {
                      if (role == 'staff') {
                        branchLabel =
                            'Branch: ${branches.length}';
                      } else {
                        branchLabel =
                            'Branches: ${branches.length}';
                      }
                    }

                    final subtitleParts = <String>[
                      email,
                      role,
                      if (branchLabel.isNotEmpty) branchLabel,
                      if (mustChange) 'must change password',
                    ];

                    return ListTile(
                      title: Text(
                        name,
                        style:
                            const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        subtitleParts.join(' • '),
                        style: TextStyle(
                            color: Colors.grey.shade400),
                      ),
                      trailing: (currentUser != null &&
                              d.id == currentUser.uid)
                          ? const Text(
                              'You',
                              style: TextStyle(
                                  color: Colors.white54),
                            )
                          : null,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _RoleHelpNote extends StatelessWidget {
  const _RoleHelpNote();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Default roles',
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 6),
          Text(
            '• Manager – access to bookings, live sessions, inventory (adjust/import), reports export, invoices, multi-branch.',
            style: TextStyle(color: Colors.white70),
          ),
          SizedBox(height: 4),
          Text(
            '• Staff – access to bookings & live sessions (edit), inventory usage (no adjust/import), view reports/invoices, single branch.',
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    );
  }
}

class _CreateUserDialog extends StatefulWidget {
  const _CreateUserDialog();

  @override
  State<_CreateUserDialog> createState() =>
      _CreateUserDialogState();
}

class _CreateUserDialogState extends State<_CreateUserDialog> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  String _role = 'staff';
  final List<String> _selectedBranches = [];
  bool _saving = false;
  String? _error;

  bool _isSuperadmin = false;

  @override
  void initState() {
    super.initState();
    _loadCurrentUserRole();
  }

  Future<void> _loadCurrentUserRole() async {
    try {
      final uid =
          FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;
      final snap = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      final data = snap.data();
      final role = data?['role']?.toString();
      if (role == 'superadmin') {
        setState(() {
          _isSuperadmin = true;
        });
      }
    } catch (_) {
      // fail-silent – dialog still works, just without password field
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Create Console User',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _nameCtrl,
                decoration: _darkInput('Name'),
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _emailCtrl,
                decoration: _darkInput('Email'),
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 10),
              // Superadmin-only: set default password for first login
              if (_isSuperadmin) ...[
                TextField(
                  controller: _passwordCtrl,
                  decoration:
                      _darkInput('Initial password (first login)'),
                  style:
                      const TextStyle(color: Colors.white),
                  obscureText: true,
                ),
                const SizedBox(height: 10),
              ],
              DropdownButtonFormField<String>(
                value: _role,
                dropdownColor: const Color(0xFF111827),
                decoration: _darkInput('Role'),
                style: const TextStyle(color: Colors.white),
                items: const [
                  DropdownMenuItem(
                      value: 'staff', child: Text('Staff')),
                  DropdownMenuItem(
                      value: 'manager', child: Text('Manager')),
                  DropdownMenuItem(
                      value: 'admin', child: Text('Admin')),
                  DropdownMenuItem(
                      value: 'superadmin',
                      child: Text('Super Admin')),
                ],
                onChanged: (v) {
                  if (v != null) {
                    setState(() {
                      _role = v;
                      // If role switched to staff, enforce single branch
                      if (_role == 'staff' &&
                          _selectedBranches.length > 1) {
                        _selectedBranches
                          ..clear()
                          ..add(_selectedBranches.first);
                      }
                    });
                  }
                },
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerLeft,
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('branches')
                      .orderBy('name')
                      .snapshots(),
                  builder: (context, snap) {
                    if (!snap.hasData) {
                      return const SizedBox.shrink();
                    }
                    final branches = snap.data!.docs;
                    return Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: branches.map((b) {
                        final id = b.id;
                        final name =
                            (b.data() as Map<String, dynamic>? ??
                                    {})['name']
                                ?.toString() ??
                                id;
                        final selected =
                            _selectedBranches.contains(id);
                        return FilterChip(
                          selected: selected,
                          label: Text(
                            name,
                            style: TextStyle(
                                color: selected
                                    ? Colors.black
                                    : Colors.white),
                          ),
                          selectedColor: Colors.white,
                          backgroundColor:
                              const Color(0xFF0F172A),
                          onSelected: (v) {
                            setState(() {
                              if (v) {
                                if (_role == 'staff') {
                                  // Staff → only ONE branch allowed
                                  _selectedBranches
                                    ..clear()
                                    ..add(id);
                                } else {
                                  if (!_selectedBranches
                                      .contains(id)) {
                                    _selectedBranches.add(id);
                                  }
                                }
                              } else {
                                _selectedBranches.remove(id);
                              }
                            });
                          },
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              if (_error != null)
                Padding(
                  padding:
                      const EdgeInsets.only(bottom: 8.0),
                  child: Text(
                    _error!,
                    style: const TextStyle(
                        color: Colors.redAccent),
                  ),
                ),
              SizedBox(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  onPressed: _saving ? null : _create,
                  child: _saving
                      ? const CircularProgressIndicator()
                      : const Text('Create User'),
                ),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () =>
                    Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _darkInput(String label) {
    return const InputDecoration().copyWith(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      border: const OutlineInputBorder(),
      enabledBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white24),
      ),
      focusedBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
    );
  }

  Future<void> _create() async {
    final name = _nameCtrl.text.trim();
    final email = _emailCtrl.text.trim();
    final password = _passwordCtrl.text.trim();

    if (name.isEmpty || email.isEmpty) {
      setState(
          () => _error = 'Name and Email are required');
      return;
    }

    if (_role == 'staff' &&
        _selectedBranches.length > 1) {
      setState(() => _error =
          'Staff can be linked to only one branch.');
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    final payload = <String, dynamic>{
      'name': name,
      'email': email,
      'role': _role,
      'branchIds': _selectedBranches,
      if (_isSuperadmin && password.isNotEmpty)
        // Optional, handled by CF if implemented
        'tempPassword': password,
    };

    try {
      // Preferred: Cloud Function creates auth user with
      // temp password + claims + mustChangePassword
      final callable = FirebaseFunctions.instance
          .httpsCallable('createConsoleUser');
      await callable.call(payload);
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      // Fallback: create Firestore record so UI flows;
      // CF can be run later to finalize auth account.
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .add({
          'name': name,
          'email': email,
          'role': _role,
          'branchIds': _selectedBranches,
          'mustChangePassword': true,
          'createdAt': FieldValue.serverTimestamp(),
        });
        if (mounted) Navigator.of(context).pop(true);
      } catch (e2) {
        if (mounted) {
          setState(() =>
              _error = 'Failed to create user: $e2');
        }
      }
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }
}
