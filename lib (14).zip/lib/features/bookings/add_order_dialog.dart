import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AddOrderDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;

  const AddOrderDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
  });

  @override
  State<AddOrderDialog> createState() => _AddOrderDialogState();
}

class _AddOrderDialogState extends State<AddOrderDialog> {
  String? _selectedItemId;
  String? _selectedItemName;
  num _selectedItemPrice = 0;
  int _qty = 1;
  bool _saving = false;

  @override
  Widget build(BuildContext context) {
    final inventoryCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('inventory')
        .where('active', isEqualTo: true);

    return Dialog(
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Add Order',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 12),
            StreamBuilder<QuerySnapshot>(
              stream: inventoryCol.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snapshot.data?.docs ?? [];
                return DropdownButtonFormField<String>(
                  value: _selectedItemId,
                  decoration: const InputDecoration(
                    labelText: 'Select item',
                    border: OutlineInputBorder(),
                  ),
                  items: docs.map((d) {
                    final name = d['name'] ?? '';
                    final price = d['price'] ?? 0;
                    final stock = d['stockQty'] ?? 0;
                    return DropdownMenuItem(
                      value: d.id,
                      child: Text('$name • ₹$price • Stock: $stock'),
                    );
                  }).toList(),
                  onChanged: (v) {
                    setState(() {
                      _selectedItemId = v;
                      if (v != null) {
                        final doc =
                            docs.firstWhere((e) => e.id == v, orElse: () => docs.first);
                        _selectedItemName = doc['name'] ?? '';
                        _selectedItemPrice = doc['price'] ?? 0;
                      } else {
                        _selectedItemName = null;
                        _selectedItemPrice = 0;
                      }
                    });
                  },
                );
              },
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Text('Qty:'),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                  icon: const Icon(Icons.remove),
                ),
                Text(_qty.toString()),
                IconButton(
                  onPressed: () => setState(() => _qty++),
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                      onPressed:
                          _saving ? null : () => _save(closeAfter: false),
                      child: _saving
                          ? const CircularProgressIndicator()
                          : const Text('Add & keep open'),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                      onPressed:
                          _saving ? null : () => _save(closeAfter: true),
                      child: _saving
                          ? const CircularProgressIndicator()
                          : const Text('Add & close'),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save({bool closeAfter = true}) async {
    if (_selectedItemId == null) return;
    setState(() => _saving = true);

    final currentUser = FirebaseAuth.instance.currentUser;
    final uid = currentUser?.uid;

    try {
      final orderCol = FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .doc(widget.sessionId)
          .collection('orders');

      final inventoryDoc = FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('inventory')
          .doc(_selectedItemId);

      await FirebaseFirestore.instance.runTransaction((tx) async {
        final invSnap = await tx.get(inventoryDoc);
        final currentStock = (invSnap.data()?['stockQty'] ?? 0) as num;
        if (currentStock < _qty) {
          throw Exception('Not enough stock');
        }

        final orderRef = orderCol.doc();
        tx.set(orderRef, {
          'itemId': _selectedItemId,
          'itemName': _selectedItemName,
          'qty': _qty,
          'price': _selectedItemPrice,
          'total': _selectedItemPrice * _qty,
          'createdAt': FieldValue.serverTimestamp(),
        });

        tx.update(inventoryDoc, {
          'stockQty': currentStock - _qty,
        });

        final logRef = inventoryDoc.collection('logs').doc();
        tx.set(logRef, {
          'type': 'usage',
          'qty': _qty,
          'at': FieldValue.serverTimestamp(),
          'note': 'Used in session ${widget.sessionId}',
          if (uid != null) 'userId': uid,
        });
      });

      if (!mounted) return;

      if (closeAfter) {
        Navigator.of(context).pop();
      } else {
        // keep dialog open for more items
        setState(() {
          _saving = false;
          _selectedItemId = null;
          _selectedItemName = null;
          _selectedItemPrice = 0;
          _qty = 1;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Order added to booking')),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to add order: $e')),
        );
      }
    }
  }
}
