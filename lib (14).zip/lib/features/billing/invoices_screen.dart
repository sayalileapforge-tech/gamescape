import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import '../../services/invoice_pdf_service.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  int _tabIndex = 0; // 0 = pending, 1 = paid

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Invoices',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _TabChip(
                label: 'Pending',
                selected: _tabIndex == 0,
                onTap: () => setState(() => _tabIndex = 0),
              ),
              const SizedBox(width: 8),
              _TabChip(
                label: 'Paid',
                selected: _tabIndex == 1,
                onTap: () => setState(() => _tabIndex = 1),
              ),
              const Spacer(),
              TextButton.icon(
                onPressed: () => setState(() {}),
                icon: const Icon(Icons.refresh, color: Colors.white70, size: 18),
                label: const Text('Refresh', style: TextStyle(color: Colors.white70)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              // Keep query simple → avoid composite-index errors
              stream: FirebaseFirestore.instance
                  .collectionGroup('sessions')
                  .where('status', isEqualTo: 'completed')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Text('Failed to load invoices.', style: TextStyle(color: Colors.redAccent)),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator(color: Colors.white));
                }

                final all = snapshot.data?.docs ?? [];
                final filtered = all.where((d) {
                  final m = (d.data() as Map<String, dynamic>?) ?? {};
                  final p = (m['paymentStatus'] ?? '').toString();
                  return _tabIndex == 0 ? p == 'pending' : p == 'paid';
                }).toList()
                  ..sort((a, b) {
                    final aData = a.data() as Map<String, dynamic>? ?? {};
                    final bData = b.data() as Map<String, dynamic>? ?? {};
                    final aTs = (aData['closedAt'] as Timestamp?)?.toDate() ??
                        DateTime.fromMillisecondsSinceEpoch(0);
                    final bTs = (bData['closedAt'] as Timestamp?)?.toDate() ??
                        DateTime.fromMillisecondsSinceEpoch(0);
                    return bTs.compareTo(aTs); // latest first
                  });

                if (filtered.isEmpty) {
                  return Center(
                    child: Text(
                      _tabIndex == 0 ? 'No pending invoices.' : 'No paid invoices.',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  );
                }

                return ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final d = filtered[index];
                    final data = d.data() as Map<String, dynamic>;
                    final cust = data['customerName']?.toString() ?? 'Guest';
                    final amount = (data['billAmount'] as num?)?.toDouble() ?? 0.0;
                    final closedAt = (data['closedAt'] as Timestamp?)?.toDate();
                    final playedMinutes = (data['playedMinutes'] as num?)?.toInt();
                    final invoiceNumber = data['invoiceNumber'];
                    final branchId = data['branchId']?.toString() ?? '';
                    final payments = (data['payments'] as List<dynamic>?) ?? const [];
                    final totalPaid = payments.fold<num>(
                      0,
                      (prev, e) => prev + ((e as Map<String, dynamic>)['amount'] ?? 0),
                    );
                    final remaining = (amount - totalPaid).clamp(0, double.infinity);

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1F2937),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.receipt_long_outlined, color: Colors.white70),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(cust,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600, color: Colors.white)),
                                if (invoiceNumber != null)
                                  Text(invoiceNumber.toString(),
                                      style: TextStyle(color: Colors.grey.shade400)),
                                Text(
                                  closedAt != null ? closedAt.toLocal().toString() : '',
                                  style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
                                ),
                                if (playedMinutes != null)
                                  Text('Played: $playedMinutes minutes',
                                      style: TextStyle(color: Colors.grey.shade400)),
                                if (payments.isNotEmpty)
                                  Text(
                                    'Paid: ₹$totalPaid • Remaining: ₹$remaining',
                                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                                  ),
                              ],
                            ),
                          ),
                          Text(
                            '₹${amount.toStringAsFixed(0)}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton.icon(
                            onPressed: branchId.isEmpty
                                ? null
                                : () async {
                                    await InvoicePdfService().generateAndPrint(
                                      branchId: branchId,
                                      sessionId: d.id,
                                    );
                                  },
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text('PDF'),
                          ),
                          const SizedBox(width: 8),
                          if (_tabIndex == 0)
                            OutlinedButton(
                              onPressed: () =>
                                  _showRecordPaymentDialog(context, d, amount),
                              child: const Text('Record Payment'),
                            ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showRecordPaymentDialog(
    BuildContext context,
    QueryDocumentSnapshot doc,
    num billAmount,
  ) async {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    final existingPayments =
        (data['payments'] as List<dynamic>?) ?? <dynamic>[];

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _RecordPaymentDialog(
        sessionDoc: doc,
        sessionData: data,
        billAmount: billAmount.toDouble(),
        existingPayments:
            existingPayments.cast<Map<String, dynamic>>().toList(
                  growable: false,
                ),
      ),
    );
  }
}

class _TabChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TabChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.white24),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// RECORD PAYMENT DIALOG (dark UI; no logic changes to your schema)
// ---------------------------------------------------------------------------

class _RecordPaymentDialog extends StatefulWidget {
  final QueryDocumentSnapshot sessionDoc;
  final Map<String, dynamic> sessionData;
  final double billAmount;
  final List<Map<String, dynamic>> existingPayments;

  const _RecordPaymentDialog({
    required this.sessionDoc,
    required this.sessionData,
    required this.billAmount,
    required this.existingPayments,
  });

  @override
  State<_RecordPaymentDialog> createState() => _RecordPaymentDialogState();
}

class _PaymentRow {
  String mode;
  final TextEditingController amountCtrl;

  _PaymentRow({
    required this.mode,
    required this.amountCtrl,
  });
}

class _RecordPaymentDialogState extends State<_RecordPaymentDialog> {
  final List<_PaymentRow> _rows = [];
  bool _saving = false;
  String? _error;

  double get _existingTotal =>
      widget.existingPayments.fold<double>(0, (prev, e) {
        final v = (e['amount'] as num?) ?? 0;
        return prev + v.toDouble();
      });

  double get _remaining => widget.billAmount - _existingTotal;

  @override
  void initState() {
    super.initState();
    final initialAmount = _remaining > 0 ? _remaining : 0;
    _rows.add(
      _PaymentRow(
        mode: 'cash',
        amountCtrl:
            TextEditingController(text: initialAmount.toStringAsFixed(0)),
      ),
    );
  }

  @override
  void dispose() {
    for (final r in _rows) {
      r.amountCtrl.dispose();
    }
    super.dispose();
  }

  double _sumNewPayments() {
    double total = 0;
    for (final r in _rows) {
      final amt = double.tryParse(r.amountCtrl.text.trim()) ?? 0;
      total += amt;
    }
    return total;
  }

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final newPayments = <Map<String, dynamic>>[];
      for (final r in _rows) {
        final amt = double.tryParse(r.amountCtrl.text.trim()) ?? 0;
        if (amt <= 0) continue;
        newPayments.add({'mode': r.mode, 'amount': amt});
      }

      // Nothing due → allow mark-as-paid without adding new rows
      if (_remaining <= 0 && newPayments.isEmpty) {
        await widget.sessionDoc.reference.update({'paymentStatus': 'paid'});
        if (!mounted) return;
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invoice marked as paid')),
        );
        return;
      }

      if (newPayments.isEmpty) {
        setState(() {
          _error = 'Enter at least one valid payment amount.';
          _saving = false;
        });
        return;
      }

      final finalTotal = _existingTotal + _sumNewPayments();
      if ((finalTotal - widget.billAmount).abs() > 0.05) {
        setState(() {
          _error =
              'Payment split must equal ₹${widget.billAmount.toStringAsFixed(2)}.\n'
              'Currently: ₹${finalTotal.toStringAsFixed(2)}.';
          _saving = false;
        });
        return;
      }

      final allPayments = [...widget.existingPayments, ...newPayments];
      await widget.sessionDoc.reference.update({
        'payments': allPayments,
        'paymentStatus': 'paid',
      });

      if (!mounted) return;
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invoice marked as paid')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Failed to record payment: $e';
        _saving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.sessionData;
    final customerName = d['customerName']?.toString() ?? 'Guest';
    final customerPhone = d['customerPhone']?.toString() ?? '';
    final branchName = d['branchName']?.toString() ?? '';
    final seatLabel = d['seatLabel']?.toString() ?? '';
    final startTime = d['startTime'] as Timestamp?;
    final closedAt = d['closedAt'] as Timestamp?;
    final playedMinutes = (d['playedMinutes'] as num?)?.toInt();
    final subtotal =
        (d['subtotal'] as num?)?.toDouble() ?? widget.billAmount;
    final discount = (d['discount'] as num?)?.toDouble() ?? 0;
    final taxPercent = (d['taxPercent'] as num?)?.toDouble() ?? 0;
    final taxAmount = (d['taxAmount'] as num?)?.toDouble() ?? 0;

    return AlertDialog(
      backgroundColor: const Color(0xFF1F2937),
      contentPadding: const EdgeInsets.all(16),
      title: const Text(
        'Invoice & Payment',
        style: TextStyle(color: Colors.white),
      ),
      content: SizedBox(
        width: 720,
        child: SingleChildScrollView(
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // SESSION / CUSTOMER SUMMARY
                const Text(
                  'Customer & Session',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                _KeyValueRow(
                  label: 'Customer',
                  value: customerPhone.isNotEmpty
                      ? '$customerName • $customerPhone'
                      : customerName,
                ),
                _KeyValueRow(
                  label: 'Branch & Seat',
                  value: [
                    if (branchName.isNotEmpty) branchName,
                    if (seatLabel.isNotEmpty) 'Seat $seatLabel',
                  ].join(' • '),
                ),
                _KeyValueRow(
                  label: 'Timing',
                  value: [
                    if (startTime != null)
                      'Start: ${startTime.toDate().toLocal()}',
                    if (closedAt != null)
                      'End: ${closedAt.toDate().toLocal()}',
                  ].join('\n'),
                ),
                if (playedMinutes != null)
                  _KeyValueRow(
                    label: 'Played',
                    value: '$playedMinutes minutes',
                  ),
                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 12),

                // F&B ITEMS
                const Text(
                  'F&B / Orders',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                FutureBuilder<QuerySnapshot>(
                  future: widget.sessionDoc.reference
                      .collection('orders')
                      .orderBy('addedAt', descending: false)
                      .get(),
                  builder: (context, snap) {
                    if (snap.connectionState == ConnectionState.waiting &&
                        !snap.hasData) {
                      return const Text(
                        'Loading order items...',
                        style: TextStyle(color: Colors.white70),
                      );
                    }
                    final docs = snap.data?.docs ?? [];
                    if (docs.isEmpty) {
                      return const Text(
                        'No F&B items added.',
                        style: TextStyle(color: Colors.white70),
                      );
                    }
                    return Column(
                      children: docs.map((o) {
                        final od = o.data() as Map<String, dynamic>;
                        final itemName =
                            od['itemName']?.toString() ?? 'Item';
                        final qty =
                            (od['qty'] as num?)?.toInt() ?? 1;
                        final price =
                            (od['price'] as num?)?.toDouble() ?? 0;
                        final total =
                            (od['total'] as num?)?.toDouble() ??
                                (price * qty);
                        return Row(
                          children: [
                            Expanded(
                              child: Text(
                                '$itemName x$qty',
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                            Text(
                              '₹${total.toStringAsFixed(2)}',
                              style: const TextStyle(color: Colors.white),
                            ),
                          ],
                        );
                      }).toList(),
                    );
                  },
                ),

                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 12),

                // BILLING BREAKDOWN
                const Text(
                  'Billing Breakdown',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                _KeyValueRow(
                  label: 'Subtotal',
                  value: '₹${subtotal.toStringAsFixed(2)}',
                ),
                _KeyValueRow(
                  label: 'Discount',
                  value: discount == 0
                      ? '₹0.00'
                      : '- ₹${discount.toStringAsFixed(2)}',
                ),
                _KeyValueRow(
                  label: 'Tax',
                  value:
                      '${taxPercent.toStringAsFixed(1)}% • ₹${taxAmount.toStringAsFixed(2)}',
                ),
                const SizedBox(height: 4),
                _KeyValueRow(
                  label: 'Total Payable',
                  value: '₹${widget.billAmount.toStringAsFixed(2)}',
                  highlight: true,
                ),

                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 12),

                // EXISTING PAYMENTS
                if (widget.existingPayments.isNotEmpty) ...[
                  const Text(
                    'Existing Payments',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Column(
                    children: widget.existingPayments.map((p) {
                      final mode =
                          p['mode']?.toString().toUpperCase() ?? 'N/A';
                      final amount =
                          (p['amount'] as num?)?.toDouble() ?? 0;
                      return Row(
                        children: [
                          Expanded(
                            child: Text(
                              mode,
                              style: const TextStyle(color: Colors.white70),
                            ),
                          ),
                          Text(
                            '₹${amount.toStringAsFixed(2)}',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 4),
                  _KeyValueRow(
                    label: 'Total Already Paid',
                    value: '₹${_existingTotal.toStringAsFixed(2)}',
                  ),
                  _KeyValueRow(
                    label: 'Remaining to Collect',
                    value: '₹${_remaining <= 0 ? '0.00' : _remaining.toStringAsFixed(2)}',
                    highlight: true,
                  ),
                  const SizedBox(height: 16),
                ],

                // NEW PAYMENTS INPUT
                const Text(
                  'Record Payment (split by mode)',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Column(
                  children: [
                    for (int i = 0; i < _rows.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: DropdownButtonFormField<String>(
                                value: _rows[i].mode,
                                dropdownColor: const Color(0xFF111827),
                                decoration: const InputDecoration(
                                  labelText: 'Mode',
                                  labelStyle:
                                      TextStyle(color: Colors.white70),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(color: Colors.white24),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(color: Colors.white),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.white),
                                items: const [
                                  DropdownMenuItem(
                                      value: 'cash', child: Text('Cash')),
                                  DropdownMenuItem(
                                      value: 'card', child: Text('Card')),
                                  DropdownMenuItem(
                                      value: 'upi', child: Text('UPI')),
                                  DropdownMenuItem(
                                      value: 'other', child: Text('Other')),
                                ],
                                onChanged: (v) {
                                  setState(() {
                                    _rows[i].mode = v ?? 'cash';
                                  });
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 2,
                              child: TextField(
                                controller: _rows[i].amountCtrl,
                                style: const TextStyle(color: Colors.white),
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  labelText: 'Amount',
                                  labelStyle:
                                      TextStyle(color: Colors.white70),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(color: Colors.white24),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (_rows.length > 1)
                              IconButton(
                                tooltip: 'Remove row',
                                onPressed: () {
                                  setState(() {
                                    final r = _rows.removeAt(i);
                                    r.amountCtrl.dispose();
                                  });
                                },
                                icon: const Icon(
                                  Icons.remove_circle_outline,
                                  color: Colors.redAccent,
                                ),
                              ),
                          ],
                        ),
                      ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _rows.add(
                              _PaymentRow(
                                mode: 'cash',
                                amountCtrl: TextEditingController(),
                              ),
                            );
                          });
                        },
                        icon: const Icon(Icons.add, color: Colors.white, size: 18),
                        label: const Text('Add another payment',
                            style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _KeyValueRow(
                  label: 'New Payments Total',
                  value: '₹${_sumNewPayments().toStringAsFixed(2)}',
                ),
                _KeyValueRow(
                  label: 'Final Total (existing + new)',
                  value:
                      '₹${(_existingTotal + _sumNewPayments()).toStringAsFixed(2)}',
                  highlight: true,
                ),

                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _error!,
                    style: const TextStyle(
                      color: Colors.redAccent,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          child: _saving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Mark as Paid'),
        ),
      ],
    );
  }
}

class _KeyValueRow extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;

  const _KeyValueRow({
    required this.label,
    required this.value,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              label,
              style: TextStyle(
                color: Colors.grey.shade300,
                fontWeight: highlight ? FontWeight.w600 : FontWeight.w500,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: highlight ? Colors.white : Colors.white70,
                fontWeight: highlight ? FontWeight.w600 : FontWeight.w400,
                fontSize: highlight ? 13 : 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
