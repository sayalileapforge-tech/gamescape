import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/dashboard_prefs.dart';

/// Lightweight interface that sections implement.
/// IMPORTANT: Do NOT extend Widget here — just declare the metadata getters.
/// Your section classes can extend StatelessWidget/StatefulWidget and
/// `implements DashboardSectionWidget` safely without inheritance clashes.
abstract class DashboardSectionWidget {
  String get persistentKey; // e.g. "stats", "quick_actions"
  String get title;         // visible title on the card
}

/// Layout shell for the dashboard:
/// - Renders header (greeting + branch selector)
/// - Shows sections in a ReorderableListView
/// - Persists custom order to Firestore (users/{uid}/preferences.dashboardOrder)
class DashboardLayout extends StatefulWidget {
  final String userId;
  final String userName;
  final String role;

  final String selectedBranchId;
  final String selectedBranchName;

  /// Visible branches for the dropdown as Dart records ({id, name})
  final List<({String id, String name})> visibleBranches;

  /// Called when branch changes from the dropdown
  final ValueChanged<String> onChangeBranch;

  /// Sections to show (default order). Users can reorder; we’ll persist.
  final List<DashboardSectionWidget> sections;

  const DashboardLayout({
    super.key,
    required this.userId,
    required this.userName,
    required this.role,
    required this.selectedBranchId,
    required this.selectedBranchName,
    required this.visibleBranches,
    required this.onChangeBranch,
    required this.sections,
  });

  @override
  State<DashboardLayout> createState() => _DashboardLayoutState();
}

class _DashboardLayoutState extends State<DashboardLayout> {
  late final DashboardPrefsService _prefs;
  late List<DashboardSectionWidget> _ordered; // current in-memory order
  bool _loadingOrder = true;

  @override
  void initState() {
    super.initState();
    _prefs = DashboardPrefsService(widget.userId);
    _ordered = List.of(widget.sections);
    _restoreOrder();
  }

  Future<void> _restoreOrder() async {
    try {
      final saved = await _prefs.loadOrder();
      if (saved != null && saved.isNotEmpty) {
        final map = {for (final s in widget.sections) s.persistentKey: s};
        final restored = <DashboardSectionWidget>[];
        for (final key in saved) {
          final sec = map[key];
          if (sec != null) restored.add(sec);
        }
        // Include any newly added sections that weren’t saved yet.
        for (final s in widget.sections) {
          if (!restored.any((e) => e.persistentKey == s.persistentKey)) {
            restored.add(s);
          }
        }
        setState(() => _ordered = restored);
      }
    } finally {
      if (mounted) setState(() => _loadingOrder = false);
    }
  }

  Future<void> _persistOrder() async {
    await _prefs.saveOrder(_ordered.map((e) => e.persistentKey).toList());
  }

  @override
  void didUpdateWidget(covariant DashboardLayout oldWidget) {
    super.didUpdateWidget(oldWidget);
    // If the caller changes the provided sections (e.g., hot reload with new ones),
    // re-merge with current order while keeping as many positions as possible.
    final incoming = widget.sections;
    if (incoming.length != oldWidget.sections.length ||
        !_sameKeys(incoming, oldWidget.sections)) {
      final map = {for (final s in incoming) s.persistentKey: s};
      final next = <DashboardSectionWidget>[];
      for (final s in _ordered) {
        final rep = map[s.persistentKey];
        if (rep != null) next.add(rep);
      }
      for (final s in incoming) {
        if (!next.any((e) => e.persistentKey == s.persistentKey)) {
          next.add(s);
        }
      }
      setState(() => _ordered = next);
    }
  }

  bool _sameKeys(List<DashboardSectionWidget> a, List<DashboardSectionWidget> b) {
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if (a[i].persistentKey != b[i].persistentKey) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(right: 16, bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: greeting + branch selector
          Text(
            'Hello, ${widget.userName} 👋',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                'Branch:',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: Colors.white70,
                      fontWeight: FontWeight.w500,
                    ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF111827),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white12),
                ),
                child: DropdownButton<String>(
                  value: widget.selectedBranchId,
                  dropdownColor: const Color(0xFF111827),
                  underline: const SizedBox.shrink(),
                  style: const TextStyle(color: Colors.white),
                  items: widget.visibleBranches
                      .map(
                        (b) => DropdownMenuItem(
                          value: b.id,
                          child: Text(b.name),
                        ),
                      )
                      .toList(),
                  onChanged: (v) {
                    if (v == null) return;
                    widget.onChangeBranch(v);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          if (_loadingOrder)
            const Center(
              child:
                  Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()),
            )
          else
            _buildReorderable(),
        ],
      ),
    );
  }

  Widget _buildReorderable() {
    // Wrap in a container so the drag handles don’t clip on web
    return ReorderableListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _ordered.length,
      onReorder: (oldIndex, newIndex) async {
        if (newIndex > oldIndex) newIndex -= 1;
        setState(() {
          final item = _ordered.removeAt(oldIndex);
          _ordered.insert(newIndex, item);
        });
        await _persistOrder();
      },
      proxyDecorator: (child, index, animation) {
        return Material(
          color: Colors.transparent,
          child: Transform.scale(
            scale: 1.01,
            child: Opacity(
              opacity: 0.98,
              child: child,
            ),
          ),
        );
      },
      itemBuilder: (context, index) {
        final section = _ordered[index];
        return Padding(
          key: ValueKey(section.persistentKey),
          padding: const EdgeInsets.only(bottom: 24),
          child: _SectionCard(
            title: section.title,
            child: section as Widget, // every section is a Widget
          ),
        );
      },
    );
  }
}

/// Visual wrapper for each section with title & drag affordance.
class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row with drag handle
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 8, 6),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                  ),
                ),
                // Reorderable drag handle
                ReorderableDragStartListener(
                  index: 0, // index ignored by builder; needed by API
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white12),
                    ),
                    padding: const EdgeInsets.all(8),
                    child: const Icon(Icons.drag_indicator, color: Colors.white70),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: child,
          ),
        ],
      ),
    );
  }
}
