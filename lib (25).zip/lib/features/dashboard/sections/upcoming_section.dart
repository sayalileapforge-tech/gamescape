import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../layout/dashboard_layout.dart';
import '../../bookings/booking_actions_dialog.dart';

class UpcomingSection extends StatefulWidget implements DashboardSectionWidget {
  final String branchId;
  const UpcomingSection({super.key, required this.branchId});

  @override
  String get persistentKey => 'upcoming';

  @override
  String get title => 'Upcoming in next 60 minutes';

  @override
  State<UpcomingSection> createState() => _UpcomingSectionState();
}

class _UpcomingSectionState extends State<UpcomingSection> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final nowUtc = DateTime.now().toUtc();
      final snap = await FirebaseFirestore.instance
          .collection('branches').doc(widget.branchId)
          .collection('sessions')
          .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(nowUtc))
          .get();

      final oneHourAhead = nowUtc.add(const Duration(minutes: 60));
      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final ts = (m['startTime'] as Timestamp?)?.toDate();
        return ((m['status'] as String?) == 'reserved') && ts != null && !ts.isAfter(oneHourAhead);
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0);
          return ta.compareTo(tb);
        });

      setState(() { _docs = list; _loading = false; });
    } catch (e) {
      setState(() { _error = 'Failed to load upcoming bookings.'; _loading = false; });
    }
  }

  @override
  void initState() { super.initState(); _load(); }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Text('Loading upcoming bookings...', style: TextStyle(color: Colors.white70));
    if (_error != null) return const Text('Failed to load upcoming bookings.', style: TextStyle(color: Colors.redAccent));
    if (_docs.isEmpty) return const Text('No upcoming bookings in the next 60 minutes.', style: TextStyle(color: Colors.white70));

    return Column(
      children: _docs.map((doc) {
        final m = doc.data() as Map<String, dynamic>? ?? {};
        final customer = m['customerName']?.toString() ?? 'Walk-in';
        final seat = m['seatLabel']?.toString() ?? 'Seat';
        final ts = (m['startTime'] as Timestamp?)?.toDate();
        final timeString = ts != null ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}' : '—';
        final branchName = m['branchName']?.toString() ?? '';
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const CircleAvatar(backgroundColor: Colors.deepOrange, child: Icon(Icons.timer, color: Colors.white)),
          title: Text(customer, style: const TextStyle(color: Colors.white)),
          subtitle: Text('$branchName • Console: $seat • Starts at: $timeString • Yet to start',
              style: const TextStyle(color: Colors.white70)),
          trailing: TextButton(
            onPressed: () => showDialog(
              context: context,
              builder: (_) => BookingActionsDialog(branchId: widget.branchId, sessionId: doc.id, data: m),
            ),
            child: const Text('Manage'),
          ),
        );
      }).toList(),
    );
  }
}
