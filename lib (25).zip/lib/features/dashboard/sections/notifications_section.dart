import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../layout/dashboard_layout.dart';
import '../../bookings/booking_actions_dialog.dart';

/// Dashboard Notifications block (tabs + scrollable container),
/// filtered to the currently-selected branch.
class NotificationsSection extends StatelessWidget
    implements DashboardSectionWidget {
  final String userId;
  final String role;
  final String branchId;
  final String branchName;

  /// Role-based tab visibility. Use keys: all, alerts, payments, stock, system
  final Map<String, bool>? roleTabVisibility;

  const NotificationsSection({
    super.key,
    required this.userId,
    required this.role,
    required this.branchId,
    required this.branchName,
    this.roleTabVisibility,
  });

  @override
  String get persistentKey => 'notifications';

  @override
  String get title => 'Notifications';

  bool _tabVisible(String key) {
    // superadmin sees all by default; staff also sees all unless restricted
    return roleTabVisibility == null ||
        roleTabVisibility![key] == null ||
        roleTabVisibility![key] == true;
  }

  @override
  Widget build(BuildContext context) {
    final tabs = <({String key, String label, Widget body})>[
      if (_tabVisible('all'))
        (key: 'all', label: 'All', body: _AllTab(branchId: branchId)),
      if (_tabVisible('alerts'))
        (key: 'alerts', label: 'Alerts', body: _AlertsTab(branchId: branchId)),
      if (_tabVisible('payments'))
        (key: 'payments', label: 'Payments', body: _PaymentsTab(branchId: branchId)),
      if (_tabVisible('stock'))
        (key: 'stock', label: 'Stock', body: _StockTab(branchId: branchId)),
      if (_tabVisible('system'))
        (key: 'system', label: 'System', body: _SystemTab(branchId: branchId)),
    ];

    return DefaultTabController(
      length: tabs.length,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Tab bar row (compact, dark)
          Container(
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white10),
            ),
            child: TabBar(
              isScrollable: true,
              indicator: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              labelStyle:
                  const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
              unselectedLabelStyle:
                  const TextStyle(color: Colors.white70, fontWeight: FontWeight.w500),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              tabs: tabs.map((t) => Tab(text: t.label)).toList(),
            ),
          ),
          const SizedBox(height: 12),

          // Scrollable body (fixes overflow)
          SizedBox(
            height: 420,
            child: TabBarView(
              children: tabs.map((t) => t.body).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── Tab bodies ─────────────────────────

class _AllTab extends StatelessWidget {
  final String branchId;
  const _AllTab({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _EndingSoonTile(),
        SizedBox(height: 8),
        _OverdueTile(),
        SizedBox(height: 8),
        _UpcomingTile(),
        SizedBox(height: 8),
        _PendingDuesTodayTile(),
        SizedBox(height: 8),
        _LowStockTile(),
        SizedBox(height: 8),
        _NewBookingsTodayTile(),
      ],
    );
  }
}

class _AlertsTab extends StatelessWidget {
  final String branchId;
  const _AlertsTab({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _EndingSoonTile(),
        SizedBox(height: 8),
        _OverdueTile(),
        SizedBox(height: 8),
        _UpcomingTile(),
      ],
    );
  }
}

class _PaymentsTab extends StatelessWidget {
  final String branchId;
  const _PaymentsTab({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _PendingDuesTodayTile(),
      ],
    );
  }
}

class _StockTab extends StatelessWidget {
  final String branchId;
  const _StockTab({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _LowStockTile(),
      ],
    );
  }
}

class _SystemTab extends StatelessWidget {
  final String branchId;
  const _SystemTab({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        _NewBookingsTodayTile(),
      ],
    );
  }
}

// ───────────────────────── Tiles (reused across tabs) ─────────────────────────

Timestamp _startUtcToday() {
  final now = DateTime.now();
  final start = DateTime(now.year, now.month, now.day).toUtc();
  return Timestamp.fromDate(start);
}

Timestamp _endUtcToday() {
  final now = DateTime.now();
  final end = DateTime(now.year, now.month, now.day).add(const Duration(days: 1)).toUtc();
  return Timestamp.fromDate(end);
}

String _statusOf(Map<String, dynamic> m) => ((m['status'] as String?) ?? '').toLowerCase();
String _payStatusOf(Map<String, dynamic> m) =>
    ((m['paymentStatus'] as String?) ?? (m['status'] as String?) ?? '').toLowerCase();

class _EndingSoonTile extends StatelessWidget {
  const _EndingSoonTile();

  @override
  Widget build(BuildContext context) {
    final branchId = _nearestBranchId(context);
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final now = DateTime.now();
        final soon = now.add(const Duration(minutes: 10));
        int count = 0;
        QueryDocumentSnapshot? sample;

        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            if (_statusOf(m) != 'active') continue;
            final st = (m['startTime'] as Timestamp?)?.toDate();
            final dur = (m['durationMinutes'] as num?)?.toInt() ?? 0;
            if (st == null) continue;
            final end = st.add(Duration(minutes: dur));
            if (end.isAfter(now) && !end.isAfter(soon)) {
              count++; sample ??= d;
            }
          }
        }

        return _tile(
          icon: Icons.hourglass_bottom,
          title: 'Sessions ending soon',
          meta: '≤10 mins • Sessions',
          count: count,
          ctaLabel: 'Open',
          onTap: sample == null
              ? null
              : () {
                  final m = sample!.data() as Map<String, dynamic>? ?? {};
                  showDialog(
                    context: context,
                    builder: (_) => BookingActionsDialog(
                      branchId: branchId,
                      sessionId: sample!.id,
                      data: m,
                    ),
                  );
                },
        );
      },
    );
  }
}

class _OverdueTile extends StatelessWidget {
  const _OverdueTile();

  @override
  Widget build(BuildContext context) {
    final branchId = _nearestBranchId(context);
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final now = DateTime.now();
        int count = 0;
        QueryDocumentSnapshot? sample;

        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final st = (m['startTime'] as Timestamp?)?.toDate();
            final dur = (m['durationMinutes'] as num?)?.toInt() ?? 0;
            if (st == null) continue;
            final end = st.add(Duration(minutes: dur));
            if (_statusOf(m) != 'cancelled' && _statusOf(m) != 'completed' && now.isAfter(end)) {
              count++; sample ??= d;
            }
          }
        }

        return _tile(
          icon: Icons.warning_amber_outlined,
          title: 'Overdue sessions',
          meta: 'Action needed • Sessions',
          count: count,
          ctaLabel: 'Close',
          onTap: sample == null
              ? null
              : () {
                  final m = sample!.data() as Map<String, dynamic>? ?? {};
                  showDialog(
                    context: context,
                    builder: (_) => BookingActionsDialog(
                      branchId: branchId,
                      sessionId: sample!.id,
                      data: m,
                    ),
                  );
                },
        );
      },
    );
  }
}

class _UpcomingTile extends StatelessWidget {
  const _UpcomingTile();

  @override
  Widget build(BuildContext context) {
    final branchId = _nearestBranchId(context);
    final now = DateTime.now().toUtc();
    final inOneHour = now.add(const Duration(minutes: 60));

    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(now));

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final list = <QueryDocumentSnapshot>[];
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final ts = (m['startTime'] as Timestamp?)?.toDate();
            if (_statusOf(m) == 'reserved' && ts != null && !ts.isAfter(inOneHour)) {
              list.add(d);
            }
          }
        }

        return _tile(
          icon: Icons.schedule,
          title: 'Upcoming reservations',
          meta: '≤60 mins • Reservations',
          count: list.length,
          ctaLabel: 'View',
          onTap: list.isEmpty
              ? null
              : () => _openListDialog(context, 'Upcoming (≤60 mins)', branchId, list),
        );
      },
    );
  }
}

class _PendingDuesTodayTile extends StatelessWidget {
  const _PendingDuesTodayTile();

  @override
  Widget build(BuildContext context) {
    final branchId = _nearestBranchId(context);
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('closedAt', isGreaterThanOrEqualTo: _startUtcToday())
        .where('closedAt', isLessThan: _endUtcToday());

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final list = <QueryDocumentSnapshot>[];
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            if (_statusOf(m) == 'completed' && _payStatusOf(m) == 'pending') {
              list.add(d);
            }
          }
        }

        return _tile(
          icon: Icons.payments_outlined,
          title: 'Pending dues (today)',
          meta: 'Billing • Sessions',
          count: list.length,
          ctaLabel: 'Settle',
          onTap: list.isEmpty
              ? null
              : () => _openListDialog(context, 'Pending dues (today)', branchId, list),
        );
      },
    );
  }
}

class _LowStockTile extends StatelessWidget {
  const _LowStockTile();

  @override
  Widget build(BuildContext context) {
    final branchId = _nearestBranchId(context);
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('inventory');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final low = <QueryDocumentSnapshot>[];
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final active = (m['active'] as bool?) ?? true;
            final qty = (m['stockQty'] as num?)?.toDouble() ?? 0;
            final thr = (m['reorderThreshold'] as num?)?.toDouble() ?? -1;
            if (active && thr >= 0 && qty <= thr) low.add(d);
          }
        }

        return _tile(
          icon: Icons.inventory_2_outlined,
          title: 'Low stock',
          meta: 'Inventory • Items',
          count: low.length,
          ctaLabel: 'Open',
          onTap: low.isEmpty
              ? null
              : () => _openInventoryList(context, low),
        );
      },
    );
  }
}

class _NewBookingsTodayTile extends StatelessWidget {
  const _NewBookingsTodayTile();

  @override
  Widget build(BuildContext context) {
    final branchId = _nearestBranchId(context);
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: _startUtcToday())
        .where('startTime', isLessThan: _endUtcToday())
        .where('status', isNotEqualTo: 'cancelled');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final list = snap.data?.docs ?? [];
        return _tile(
          icon: Icons.add_alert_outlined,
          title: 'New bookings (today)',
          meta: 'Today • Sessions',
          count: list.length,
          ctaLabel: 'View',
          onTap: list.isEmpty
              ? null
              : () => _openListDialog(context, 'Today’s bookings', branchId, list),
        );
      },
    );
  }
}

// ───────────────────────── small helpers ─────────────────────────

String _nearestBranchId(BuildContext context) {
  // In this design each tile is used inside NotificationsSection which is
  // instantiated with a single branchId; we just climb the tree to find it.
  // Easier: pass via InheritedWidget or closure, but here we read it from
  // the nearest NotificationsSection by context.findAncestorWidgetOfExactType.
  final ns = context.findAncestorWidgetOfExactType<NotificationsSection>();
  return ns?.branchId ?? '';
}

Widget _tile({
  required IconData icon,
  required String title,
  required String meta,
  required int count,
  String ctaLabel = 'View',
  VoidCallback? onTap,
}) {
  return Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: const Color(0xFF0F172A),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white10),
    ),
    child: Row(
      children: [
        Container(
          height: 36,
          width: 36,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white12),
          ),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(meta, style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white12,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: Colors.white24),
          ),
          child: Text('$count', style: const TextStyle(color: Colors.white)),
        ),
        const SizedBox(width: 8),
        if (onTap != null) TextButton(onPressed: onTap, child: Text(ctaLabel)),
      ],
    ),
  );
}

void _openListDialog(
  BuildContext context,
  String title,
  String branchId,
  List<QueryDocumentSnapshot> docs,
) {
  showDialog(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xFF111827),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text(title,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 12),
              if (docs.isEmpty)
                const Text('Nothing here.', style: TextStyle(color: Colors.white70))
              else
                Flexible(
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: docs.length,
                    separatorBuilder: (_, __) => const Divider(color: Colors.white12, height: 12),
                    itemBuilder: (_, i) {
                      final d = docs[i];
                      final m = d.data() as Map<String, dynamic>? ?? {};
                      final name = (m['customerName'] ?? 'Walk-in').toString();
                      final seat = (m['seatLabel'] ?? '-').toString();
                      final ts = (m['startTime'] as Timestamp?)?.toDate();
                      final timeStr = ts != null
                          ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                          : '—';
                      return ListTile(
                        leading: const Icon(Icons.event, color: Colors.white70),
                        title: Text(name, style: const TextStyle(color: Colors.white)),
                        subtitle: Text('Seat $seat • $timeStr',
                            style: const TextStyle(color: Colors.white60)),
                        trailing: TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                            showDialog(
                              context: context,
                              builder: (_) => BookingActionsDialog(
                                branchId: branchId,
                                sessionId: d.id,
                                data: m,
                              ),
                            );
                          },
                          child: const Text('Manage'),
                        ),
                      );
                    },
                  ),
                ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Close')),
              )
            ],
          ),
        ),
      ),
    ),
  );
}

void _openInventoryList(BuildContext context, List<QueryDocumentSnapshot> docs) {
  showDialog(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xFF111827),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('Low stock items',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 12),
              if (docs.isEmpty)
                const Text('No low-stock items.', style: TextStyle(color: Colors.white70))
              else
                Flexible(
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: docs.length,
                    separatorBuilder: (_, __) => const Divider(color: Colors.white12, height: 12),
                    itemBuilder: (_, i) {
                      final d = docs[i];
                      final m = d.data() as Map<String, dynamic>? ?? {};
                      final name = (m['name'] ?? 'Item').toString();
                      final qty = (m['stockQty'] ?? '-').toString();
                      final thr = (m['reorderThreshold'] ?? '-').toString();
                      return ListTile(
                        leading: const Icon(Icons.inventory_2_outlined, color: Colors.white70),
                        title: Text(name, style: const TextStyle(color: Colors.white)),
                        subtitle:
                            Text('Qty: $qty • Threshold: $thr', style: const TextStyle(color: Colors.white60)),
                      );
                    },
                  ),
                ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Close')),
              )
            ],
          ),
        ),
      ),
    ),
  );
}
