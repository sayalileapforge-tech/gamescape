import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Brand colors from your guideline
  static const Color primaryBlue = Color(0xFF1C5484);
  static const Color lightCyan = Color(0xFF8EE3EF);
  static const Color bgGrey = Color(0xFFF6F6F6);

  static ThemeData get lightTheme {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryBlue,
        primary: primaryBlue,
        secondary: lightCyan,
      ),
    );

    return base.copyWith(
      scaffoldBackgroundColor: bgGrey,
      textTheme: GoogleFonts.montserratTextTheme(base.textTheme),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      // 👇 this is the part that was failing earlier
      cardTheme: const CardThemeData(
        color: Colors.white,
        elevation: 2,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
      ),
    );
  }
}
