// FULL FILE: lib/features/bookings/quick_shop_dialog.dart
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class QuickShopDialog extends StatefulWidget {
  final String branchId;
  const QuickShopDialog({super.key, required this.branchId});

  @override
  State<QuickShopDialog> createState() => _QuickShopDialogState();
}

class _QuickShopDialogState extends State<QuickShopDialog> {
  final _formKey = GlobalKey<FormState>();

  // modes
  String _mode = 'billOnly'; // 'billOnly' | 'blankSession'

  // items
  final List<_ItemRow> _items = [
    _ItemRow(name: '', qty: 1, price: 0),
  ];

  // money fields
  double _taxPercent = 0;
  double _discount = 0;

  // payment
  String _paymentStatus = 'paid'; // 'paid' or 'pending'

  // customer (optional)
  final _customerNameCtrl = TextEditingController();
  final _customerPhoneCtrl = TextEditingController();

  bool _submitting = false;

  double get _ordersSubtotal {
    double s = 0;
    for (final it in _items) {
      final q = it.qty.clamp(0, 1000000);
      final p = it.price.clamp(0, 100000000.0);
      s += q * p;
    }
    return s;
  }

  double get _taxAmount => (_ordersSubtotal - _discount).clamp(0, double.infinity) * (_taxPercent / 100.0);
  double get _billAmount => (_ordersSubtotal - _discount).clamp(0, double.infinity) + _taxAmount;

  @override
  void dispose() {
    _customerNameCtrl.dispose();
    _customerPhoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canSubmit = _mode == 'blankSession' || _items.any((e) => e.isValid);

    return Dialog(
      insetPadding: const EdgeInsets.all(16),
      backgroundColor: const Color(0xFF111827),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 720, maxHeight: 640),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // Header
                Row(
                  children: [
                    const Text('Quick Shop', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white70),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Mode selector
                Row(
                  children: [
                    _radio('Bill Only (no seat / invoice now)', 'billOnly'),
                    const SizedBox(width: 16),
                    _radio('Blank Session (no items, manage later)', 'blankSession'),
                  ],
                ),

                const SizedBox(height: 12),

                // Items + Money (only for billOnly mode)
                if (_mode == 'billOnly') ...[
                  _itemsHeader(),
                  const SizedBox(height: 8),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          for (int i = 0; i < _items.length; i++) _itemRow(i),
                          const SizedBox(height: 12),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: TextButton.icon(
                              onPressed: () => setState(() => _items.add(_ItemRow(name: '', qty: 1, price: 0))),
                              icon: const Icon(Icons.add, color: Colors.white),
                              label: const Text('Add item', style: TextStyle(color: Colors.white)),
                            ),
                          ),
                          const SizedBox(height: 12),
                          _moneyRow(),
                          const SizedBox(height: 12),
                          _customerRow(),
                        ],
                      ),
                    ),
                  ),
                ] else
                  // For blank session mode, keep some room for optional customer fields
                  Expanded(child: SingleChildScrollView(child: _customerRow())),

                const SizedBox(height: 16),

                // Footer actions
                Row(
                  children: [
                    if (_mode == 'billOnly')
                      Row(
                        children: [
                          const Text('Payment:', style: TextStyle(color: Colors.white70)),
                          const SizedBox(width: 8),
                          DropdownButton<String>(
                            value: _paymentStatus,
                            dropdownColor: const Color(0xFF1F2937),
                            style: const TextStyle(color: Colors.white),
                            items: const [
                              DropdownMenuItem(value: 'paid', child: Text('Paid')),
                              DropdownMenuItem(value: 'pending', child: Text('Pending')),
                            ],
                            onChanged: (v) => setState(() => _paymentStatus = v ?? 'paid'),
                          ),
                        ],
                      ),
                    const Spacer(),
                    TextButton(
                      onPressed: _submitting ? null : () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton.icon(
                      onPressed: !_submitting && canSubmit ? _submit : null,
                      icon: _submitting
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.check),
                      label: Text(_mode == 'billOnly' ? 'Generate Bill' : 'Create Blank Session'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _radio(String label, String value) {
    return InkWell(
      onTap: () => setState(() => _mode = value),
      borderRadius: BorderRadius.circular(8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Radio<String>(
            value: value,
            groupValue: _mode,
            onChanged: (v) => setState(() => _mode = v ?? 'billOnly'),
            fillColor: MaterialStateProperty.all(Colors.white),
          ),
          Text(label, style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _itemsHeader() {
    return Row(
      children: const [
        Expanded(flex: 5, child: Text('Item', style: TextStyle(color: Colors.white54))),
        Expanded(flex: 2, child: Text('Qty', style: TextStyle(color: Colors.white54))),
        Expanded(flex: 3, child: Text('Price', style: TextStyle(color: Colors.white54))),
        SizedBox(width: 40),
      ],
    );
  }

  Widget _itemRow(int index) {
    final it = _items[index];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
            flex: 5,
            child: TextFormField(
              initialValue: it.name,
              onChanged: (v) => it.name = v.trim(),
              style: const TextStyle(color: Colors.white),
              decoration: _dec('Item name'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              initialValue: it.qty.toString(),
              onChanged: (v) => it.qty = int.tryParse(v) ?? 0,
              style: const TextStyle(color: Colors.white),
              keyboardType: TextInputType.number,
              decoration: _dec('Qty'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 3,
            child: TextFormField(
              initialValue: it.price.toStringAsFixed(2),
              onChanged: (v) => it.price = double.tryParse(v) ?? 0,
              style: const TextStyle(color: Colors.white),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: _dec('Price'),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            tooltip: 'Remove',
            onPressed: _items.length == 1 ? null : () => setState(() => _items.removeAt(index)),
            icon: const Icon(Icons.delete_outline, color: Colors.white54),
          )
        ],
      ),
    );
  }

  Widget _moneyRow() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _numField(
                label: 'Discount (₹)',
                value: _discount,
                onChanged: (v) => setState(() => _discount = (double.tryParse(v) ?? 0).clamp(0, 1e12)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _numField(
                label: 'Tax (%)',
                value: _taxPercent,
                onChanged: (v) => setState(() => _taxPercent = (double.tryParse(v) ?? 0).clamp(0, 100)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF1F2937),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _sumLine('Items Subtotal', _ordersSubtotal),
                    _sumLine('Discount', -_discount),
                    _sumLine('Tax', _taxAmount),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('Total', style: TextStyle(color: Colors.white60)),
                  Text('₹ ${_billAmount.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _customerRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Customer (optional)', style: TextStyle(color: Colors.white54)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _customerNameCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: _dec('Name'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _customerPhoneCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: _dec('Phone'),
                keyboardType: TextInputType.phone,
              ),
            ),
          ],
        ),
      ],
    );
  }

  InputDecoration _dec(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white54),
      enabledBorder: const OutlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
      focusedBorder: const OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
    );
  }

  Widget _numField({required String label, required double value, required ValueChanged<String> onChanged}) {
    return TextFormField(
      initialValue: value.toString(),
      onChanged: onChanged,
      style: const TextStyle(color: Colors.white),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: _dec(label),
    );
  }

  Widget _sumLine(String label, double amt) {
    final sign = amt < 0 ? '-' : '+';
    final abs = amt.abs();
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.white60))),
          Text('$sign ₹ ${abs.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white)),
        ],
      ),
    );
  }

  Future<void> _submit() async {
    if (_submitting) return;
    setState(() => _submitting = true);

    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      final email = FirebaseAuth.instance.currentUser?.email;
      final disp = FirebaseAuth.instance.currentUser?.displayName;

      final now = DateTime.now();
      final sessionsRef = FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions');

      if (_mode == 'blankSession') {
        // Create a minimal session (no items) for staff to manage later
        await sessionsRef.add({
          'status': 'reserved',
          'paymentStatus': 'pending',
          'branchId': widget.branchId, // NEW: keep collectionGroup role filters working
          'startTime': Timestamp.fromDate(now),
          'durationMinutes': 60, // safe default
          'seatId': null,
          'seatLabel': '—',
          'pax': 1,
          'ordersSubtotal': 0.0,
          'subtotal': 0.0,
          'taxPercent': 0.0,
          'taxAmount': 0.0,
          'billAmount': 0.0,
          'discount': 0.0,
          'playedMinutes': 0,
          'customerName': _customerNameCtrl.text.trim().isEmpty ? null : _customerNameCtrl.text.trim(),
          'customerPhone': _customerPhoneCtrl.text.trim().isEmpty ? null : _customerPhoneCtrl.text.trim(),
          'createdAt': Timestamp.fromDate(now),
          'createdBy': uid,
          'createdByEmail': email,
          'createdByName': disp,
          'quickShop': true,
          'quickShopMode': 'blankSession',
        });
      } else {
        // billOnly → write a completed "quick" session (seatless) so Invoices screen continues to work
        final orders = _items
            .where((e) => e.isValid)
            .map((e) => {
                  'name': e.name,
                  'qty': e.qty,
                  'price': e.price,
                  'total': e.qty * e.price,
                })
            .toList();

        final doc = sessionsRef.doc();
        final invoiceNo = _genInvoiceNumber(doc.id, now);

        await doc.set({
          // session-like fields
          'status': 'completed',
          'paymentStatus': _paymentStatus, // 'paid'|'pending'
          'branchId': widget.branchId,     // NEW: for role-scoped collectionGroup queries
          'startTime': Timestamp.fromDate(now),
          'durationMinutes': 0,
          'seatId': null,
          'seatLabel': '—',
          'pax': 1,

          // money writeback (same invariant as Close & Bill)
          'ordersSubtotal': _ordersSubtotal,
          'subtotal': (_ordersSubtotal - _discount).clamp(0, double.infinity),
          'taxPercent': _taxPercent,
          'taxAmount': _taxAmount,
          'billAmount': _billAmount,
          'discount': _discount,
          'playedMinutes': 0,

          // invoice-ish fields
          'invoiceNumber': invoiceNo,
          'closedAt': Timestamp.fromDate(now),
          'closedBy': uid,
          'closedByName': disp,

          // customer (optional)
          'customerName': _customerNameCtrl.text.trim().isEmpty ? null : _customerNameCtrl.text.trim(),
          'customerPhone': _customerPhoneCtrl.text.trim().isEmpty ? null : _customerPhoneCtrl.text.trim(),

          // quick shop markers
          'itemsOnly': true,               // NEW: match Invoices "Items-only" chip
          'quickShop': true,
          'quickShopMode': 'billOnly',
          'orders': orders, // helpful for invoice itemization
          'createdAt': Timestamp.fromDate(now),
          'createdBy': uid,
          'createdByEmail': email,
          'createdByName': disp,
        });
      }

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  String _genInvoiceNumber(String docId, DateTime now) {
    final rand = Random(now.millisecondsSinceEpoch).nextInt(9999).toString().padLeft(4, '0');
    return 'INV-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-$rand';
  }
}

class _ItemRow {
  _ItemRow({required this.name, required this.qty, required this.price});
  String name;
  int qty;
  double price;

  bool get isValid => name.trim().isNotEmpty && qty > 0 && price >= 0;
}
