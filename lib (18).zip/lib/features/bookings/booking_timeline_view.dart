import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class BookingTimelineView extends StatefulWidget {
  final List<QueryDocumentSnapshot> bookings;
  final DateTime date;

  const BookingTimelineView({
    super.key,
    required this.bookings,
    required this.date,
  });

  @override
  State<BookingTimelineView> createState() => _BookingTimelineViewState();
}

class _BookingTimelineViewState extends State<BookingTimelineView> {
  final ScrollController _hCtrl = ScrollController();

  static const int _minutesInDay = 24 * 60;
  static const double _minuteWidth = 1.8;

  @override
  void didUpdateWidget(covariant BookingTimelineView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.date != widget.date) {
      _scrollToNow();
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToNow());
  }

  void _scrollToNow() {
    final dayStart =
        DateTime(widget.date.year, widget.date.month, widget.date.day);
    final now = DateTime.now();
    int minsFromStart = now.difference(dayStart).inMinutes;
    if (minsFromStart < 0) minsFromStart = 0;
    if (minsFromStart > _minutesInDay) minsFromStart = _minutesInDay;
    final double target = minsFromStart * _minuteWidth;
    if (_hCtrl.hasClients) {
      _hCtrl.jumpTo(target);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dayStart =
        DateTime(widget.date.year, widget.date.month, widget.date.day);

    // filter bookings for this date
    final dayBookings = widget.bookings.where((d) {
      final data = d.data() as Map<String, dynamic>;
      final ts = data['startTime'] as Timestamp?;
      if (ts == null) return false;
      final st = ts.toDate();
      return st.year == dayStart.year &&
          st.month == dayStart.month &&
          st.day == dayStart.day;
    }).toList();

    // group by seat label
    final Map<String, List<QueryDocumentSnapshot>> bySeat = {};
    for (final d in dayBookings) {
      final data = d.data() as Map<String, dynamic>;
      final seat = (data['seatLabel'] ?? 'Unknown').toString();
      bySeat.putIfAbsent(seat, () => []).add(d);
    }

    final totalWidth = _minutesInDay * _minuteWidth;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      controller: _hCtrl,
      child: SizedBox(
        width: totalWidth + 140,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TimelineHeader(minuteWidth: _minuteWidth),
            const SizedBox(height: 12),
            for (final entry in bySeat.entries)
              _SeatLane(
                seatName: entry.key,
                docs: entry.value,
                dayStart: dayStart,
                minuteWidth: _minuteWidth,
              ),
            if (bySeat.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'No bookings for this day.',
                  style: TextStyle(color: Colors.white70),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TimelineHeader extends StatelessWidget {
  final double minuteWidth;
  const _TimelineHeader({required this.minuteWidth});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 30,
      child: Row(
        children: [
          const SizedBox(width: 140),
          for (int h = 0; h < 24; h++)
            Container(
              width: 60 * minuteWidth,
              alignment: Alignment.centerLeft,
              child: Text(
                '${h.toString().padLeft(2, '0')}:00',
                style: const TextStyle(color: Colors.white38, fontSize: 11),
              ),
            ),
        ],
      ),
    );
  }
}

class _LaidOutBooking {
  final Map<String, dynamic> data;
  final int startMins;
  final int endMins;
  final int row;
  _LaidOutBooking({
    required this.data,
    required this.startMins,
    required this.endMins,
    required this.row,
  });
}

class _SeatLane extends StatelessWidget {
  final String seatName;
  final List<QueryDocumentSnapshot> docs;
  final DateTime dayStart;
  final double minuteWidth;

  const _SeatLane({
    required this.seatName,
    required this.docs,
    required this.dayStart,
    required this.minuteWidth,
  });

  @override
  Widget build(BuildContext context) {
    final List<_LaidOutBooking> laidOut = [];
    final temp = <_LaidOutBooking>[];

    // project each booking into minutes-from-day-start
    for (final d in docs) {
      final data = d.data() as Map<String, dynamic>;
      final ts = data['startTime'] as Timestamp?;
      if (ts == null) continue;
      final start = ts.toDate();
      final dur = (data['durationMinutes'] ?? 60) as int;
      final startMins = start.difference(dayStart).inMinutes;
      if (startMins < 0) continue;
      final endMins = startMins + dur;
      temp.add(
        _LaidOutBooking(
          data: data,
          startMins: startMins,
          endMins: endMins,
          row: 0,
        ),
      );
    }

    temp.sort((a, b) => a.startMins.compareTo(b.startMins));

    // Interval graph coloring: assign rows so intervals in same row don't overlap
    final List<List<_LaidOutBooking>> rows = [];
    for (final item in temp) {
      int rowIndex = 0;
      while (true) {
        if (rowIndex >= rows.length) {
          rows.add([item]);
          laidOut.add(
            _LaidOutBooking(
              data: item.data,
              startMins: item.startMins,
              endMins: item.endMins,
              row: rowIndex,
            ),
          );
          break;
        } else {
          final last = rows[rowIndex].last;
          final overlaps =
              item.startMins < last.endMins && last.startMins < item.endMins;
          if (!overlaps) {
            rows[rowIndex].add(item);
            laidOut.add(
              _LaidOutBooking(
                data: item.data,
                startMins: item.startMins,
                endMins: item.endMins,
                row: rowIndex,
              ),
            );
            break;
          } else {
            rowIndex++;
          }
        }
      }
    }

    final int rowCount = rows.isEmpty ? 1 : rows.length;
    const double rowHeight = 30.0;
    final double laneHeight = rowCount * rowHeight + 16;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              seatName,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: SizedBox(
              height: laneHeight,
              child: Stack(
                children: [
                  for (final b in laidOut)
                    _BookingBlock(
                      data: b.data,
                      dayStart: dayStart,
                      minuteWidth: minuteWidth,
                      top: 6 + b.row * rowHeight,
                    ),
                  Positioned.fill(
                    child: Container(
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(color: Colors.white12, width: 1),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BookingBlock extends StatelessWidget {
  final Map<String, dynamic> data;
  final DateTime dayStart;
  final double minuteWidth;
  final double top;

  const _BookingBlock({
    required this.data,
    required this.dayStart,
    required this.minuteWidth,
    required this.top,
  });

  @override
  Widget build(BuildContext context) {
    final ts = data['startTime'] as Timestamp?;
    if (ts == null) return const SizedBox.shrink();
    final start = ts.toDate();
    final dur = (data['durationMinutes'] ?? 60) as int;
    final status = (data['status'] ?? 'active').toString();

    final minsFromStart = start.difference(dayStart).inMinutes;
    if (minsFromStart < 0) return const SizedBox.shrink();

    final left = minsFromStart * minuteWidth;
    final width = (dur * minuteWidth).clamp(70.0, 99999.0);

    Color bg;
    switch (status) {
      case 'cancelled':
      case 'canceled':
        bg = Colors.redAccent.withOpacity(0.5);
        break;
      case 'completed':
        bg = Colors.greenAccent.withOpacity(0.5);
        break;
      default:
        bg = Colors.lightBlueAccent.withOpacity(0.6);
    }

    final customer = (data['customerName'] ?? '').toString();

    return Positioned(
      top: top,
      left: left,
      width: width,
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white24),
        ),
        child: Text(
          '$customer\n${_timeLabel(start, dur)}',
          style: const TextStyle(color: Colors.black87, fontSize: 10),
        ),
      ),
    );
  }

  String _timeLabel(DateTime start, int dur) {
    final end = start.add(Duration(minutes: dur));
    String f(DateTime d) =>
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return '${f(start)} – ${f(end)} (${dur}m)';
  }
}
