import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class BookingCloseBillDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingCloseBillDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingCloseBillDialog> createState() => _BookingCloseBillDialogState();
}

class _BookingCloseBillDialogState extends State<BookingCloseBillDialog> {
  bool _loading = true;
  bool _closing = false; // guard while closing

  num _ordersTotal = 0;
  num _sessionTotal = 0;
  num _grandTotal = 0;
  int _playedMinutes = 0;
  List<Map<String, dynamic>> _orders = [];

  final TextEditingController _discountCtrl = TextEditingController(text: '0');
  final TextEditingController _taxPercentCtrl =
      TextEditingController(text: '0');

  // segment models
  final List<_SeatSegment> _segments = [];

  late final DateTime? _startTime;
  late final int _plannedDuration; // minutes
  late final DateTime? _plannedEnd; // clamp target
  late final String _paymentType; // prepaid / postpaid

  @override
  void initState() {
    super.initState();
    final sessionData = widget.data;
    _startTime = (sessionData['startTime'] as Timestamp?)?.toDate();
    _plannedDuration = (sessionData['durationMinutes'] as int?) ?? 0;
    _plannedEnd = _startTime == null
        ? null
        : _startTime!.add(Duration(minutes: _plannedDuration));
    _paymentType =
        (sessionData['paymentType'] ?? 'postpaid').toString().toLowerCase();
    _loadBill();
  }

  Future<void> _loadBill() async {
    final sessionData = widget.data;
    final branchId = widget.branchId;
    final currentSeatId = sessionData['seatId'] as String?;

    // orders
    final ordersSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('orders')
        .get();

    num ordersTotal = 0;
    final ordersList = <Map<String, dynamic>>[];

    for (final doc in ordersSnap.docs) {
      final d = doc.data();

      // Robust line total calculation: prefer total, else price * qty
      num price = 0;
      int qty = 1;

      final rawPrice = d['price'];
      if (rawPrice is num) {
        price = rawPrice;
      }

      final rawQty = d['qty'];
      if (rawQty is int) {
        qty = rawQty;
      } else if (rawQty is num) {
        qty = rawQty.toInt();
      }

      num lineTotal;
      final rawTotal = d['total'];
      if (rawTotal is num) {
        lineTotal = rawTotal;
      } else {
        lineTotal = price * qty;
      }

      ordersTotal += lineTotal;
      ordersList.add({
        ...d,
        'computedTotal': lineTotal,
      });
    }

    // seat changes
    final seatChangesSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('seat_changes')
        .orderBy('changedAt')
        .get();

    final now = DateTime.now();

    final segmentsRaw = <_SeatSegment>[];
    if (_startTime != null) {
      DateTime currentFrom = _startTime!;
      String? currentSeat = currentSeatId;

      if (seatChangesSnap.docs.isEmpty) {
        segmentsRaw.add(
          _SeatSegment(
            seatId: currentSeat,
            from: currentFrom,
            to: _clampToPlanned(now),
            billAs: 'actual',
          ),
        );
      } else {
        for (final sc in seatChangesSnap.docs) {
          final d = sc.data();
          final changedAt = (d['changedAt'] as Timestamp?)?.toDate();
          final toSeatId = d['toSeatId'] as String?;
          final billAs = d['billSegmentAs']?.toString() ?? 'actual';
          if (changedAt != null) {
            segmentsRaw.add(
              _SeatSegment(
                seatId: currentSeat,
                from: currentFrom,
                to: _clampToPlanned(changedAt),
                billAs: billAs,
              ),
            );
            currentFrom = changedAt;
            currentSeat = toSeatId;
          }
        }
        // last stretch till now (clamped)
        segmentsRaw.add(
          _SeatSegment(
            seatId: currentSeat,
            from: currentFrom,
            to: _clampToPlanned(now),
            billAs: 'actual',
          ),
        );
      }
    }

    // fetch seat labels + rates & compute minutes
    int totalPlayed = 0;
    for (final seg in segmentsRaw) {
      num ratePerHour = 0;
      String seatLabel = 'Seat';
      if (seg.seatId != null) {
        final seatSnap = await FirebaseFirestore.instance
            .collection('branches')
            .doc(branchId)
            .collection('seats')
            .doc(seg.seatId!)
            .get();
        final seatData = seatSnap.data();
        ratePerHour = (seatData?['ratePerHour'] ?? 0) as num;
        seatLabel = seatData?['label']?.toString() ?? seg.seatId!;
      }
      final actualMins =
          seg.to.difference(seg.from).inMinutes.clamp(0, _plannedDuration);
      totalPlayed += actualMins;

      _segments.add(
        seg.copyWith(
          seatLabel: seatLabel,
          ratePerHour: ratePerHour,
          actualMinutes: actualMins,
          billedMinutes: _computeBilledMins(seg.billAs, actualMins),
        ),
      );
    }

    final sessionTotal = _segments.fold<num>(
      0,
      (prev, s) => prev + s.ratePerHour * (s.billedMinutes / 60),
    );

    setState(() {
      _ordersTotal = ordersTotal;
      _sessionTotal = sessionTotal;
      _orders = ordersList;
      _playedMinutes = totalPlayed;
      _loading = false;
      _grandTotal = _calcGrandTotal();
    });
  }

  DateTime _clampToPlanned(DateTime candidate) {
    if (_plannedEnd == null) return candidate;
    return candidate.isAfter(_plannedEnd!) ? _plannedEnd! : candidate;
  }

  int _computeBilledMins(String billAs, int actual) {
    if (billAs == '30') return 30;
    if (billAs == '60') return 60;
    return actual;
  }

  num _calcSessionTotal() {
    return _segments.fold<num>(
      0,
      (prev, s) => prev + s.ratePerHour * (s.billedMinutes / 60),
    );
  }

  num _calcGrandTotal() {
    final discount = num.tryParse(_discountCtrl.text.trim()) ?? 0;
    final taxPercent = num.tryParse(_taxPercentCtrl.text.trim()) ?? 0;
    final sessionTotal = _calcSessionTotal();
    final subTotal = _ordersTotal + sessionTotal;
    final afterDiscount = (subTotal - discount).clamp(0, 999999);
    final taxAmount = afterDiscount * (taxPercent / 100);
    return afterDiscount + taxAmount;
  }

  void _recalcAll() {
    setState(() {
      _sessionTotal = _calcSessionTotal();
      _grandTotal = _calcGrandTotal();
    });
  }

  Future<void> _closeSession() async {
    if (_closing) return;
    setState(() => _closing = true);

    try {
      final discount = num.tryParse(_discountCtrl.text.trim()) ?? 0;
      final taxPercent = num.tryParse(_taxPercentCtrl.text.trim()) ?? 0;

      final sessionTotal = _calcSessionTotal();
      final subTotal = (sessionTotal + _ordersTotal) - discount;
      final fixedSubTotal = subTotal < 0 ? 0 : subTotal;
      final taxAmount = fixedSubTotal * (taxPercent / 100);
      final grandTotal = fixedSubTotal + taxAmount;

      // Payment status:
      // - postpaid  -> pending
      // - prepaid   -> paid
      final paymentStatus = _paymentType == 'prepaid' ? 'paid' : 'pending';

      final now = DateTime.now();
      final invoiceNumber =
          'INV-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${(now.millisecondsSinceEpoch % 100000).toString().padLeft(5, '0')}';

      final currentUser = FirebaseAuth.instance.currentUser;
      String? closedByName;
      if (currentUser != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser.uid)
            .get();
        if (userDoc.exists) {
          closedByName =
              (userDoc.data()?['name'] as String?) ?? currentUser.email;
        }
      }

      await FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .doc(widget.sessionId)
          .update({
        'status': 'completed',
        'paymentStatus': paymentStatus,
        'closedAt': FieldValue.serverTimestamp(),
        'billAmount': grandTotal,
        'subtotal': fixedSubTotal,
        'taxPercent': taxPercent,
        'taxAmount': taxAmount,
        'playedMinutes': _playedMinutes,
        'invoiceNumber': invoiceNumber,
        'discount': discount,
        if (currentUser != null) 'closedBy': currentUser.uid,
        if (closedByName != null) 'closedByName': closedByName,
      });

      // Upsert simple customer aggregates
      final custName =
          (widget.data['customerName'] ?? '').toString().trim();
      final custPhone =
          (widget.data['customerPhone'] ?? '').toString().trim();
      if (custName.isNotEmpty || custPhone.isNotEmpty) {
        final customerId =
            custPhone.isNotEmpty ? 'phone:$custPhone' : 'name:$custName';
        final custRef =
            FirebaseFirestore.instance.collection('customers').doc(customerId);

        await FirebaseFirestore.instance.runTransaction((tx) async {
          final snap = await tx.get(custRef);
          final existing = snap.data() ?? {};
          final num prevLifetimeSpend =
              (existing['lifetimeSpend'] ?? 0) as num;
          final int prevLifetimeVisits =
              (existing['lifetimeVisits'] ?? 0) as int;
          final num prevSpend90 = (existing['spendLast90d'] ?? 0) as num;
          final bool prevPending =
              (existing['hasPendingDue'] ?? false) as bool;

          final num lifetimeSpend = prevLifetimeSpend + grandTotal;
          final int lifetimeVisits = prevLifetimeVisits + 1;

          tx.set(
            custRef,
            {
              'name': custName,
              'phone': custPhone,
              'lifetimeSpend': lifetimeSpend,
              'lifetimeVisits': lifetimeVisits,
              'avgSpend':
                  lifetimeSpend / (lifetimeVisits == 0 ? 1 : lifetimeVisits),
              'spendLast90d': prevSpend90 + grandTotal,
              'lastVisitAt': FieldValue.serverTimestamp(),
              'firstVisitAt':
                  existing['firstVisitAt'] ?? FieldValue.serverTimestamp(),
              'hasPendingDue': prevPending || paymentStatus == 'pending',
              'updatedAt': FieldValue.serverTimestamp(),
            },
            SetOptions(merge: true),
          );
        });
      }

      if (!mounted) return;
      // return TRUE so parent dialog can close too
      Navigator.of(context, rootNavigator: true).pop(true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Session closed')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Failed to close: $e')));
    } finally {
      if (mounted) setState(() => _closing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(18),
        child: _loading
            ? const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              )
            : SingleChildScrollView(
                child: DefaultTextStyle(
                  style: const TextStyle(color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'Close & Bill',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 16),
                      ),
                      const SizedBox(height: 10),
                      Text('Played: $_playedMinutes minutes'),
                      const SizedBox(height: 10),

                      const Text('Session segments (choose billing):'),
                      const SizedBox(height: 6),
                      ..._segments.asMap().entries.map((entry) {
                        final idx = entry.key;
                        final seg = entry.value;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 6),
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                  '${seg.seatLabel ?? "Seat"} • actual: ${seg.actualMinutes}m • rate: ₹${seg.ratePerHour}/hr'),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  DropdownButton<String>(
                                    value: seg.billAs,
                                    dropdownColor: const Color(0xFF111827),
                                    style:
                                        const TextStyle(color: Colors.white),
                                    items: const [
                                      DropdownMenuItem(
                                          value: 'actual',
                                          child: Text('Actual minutes')),
                                      DropdownMenuItem(
                                          value: '30',
                                          child: Text('30 minutes')),
                                      DropdownMenuItem(
                                          value: '60',
                                          child: Text('1 hour')),
                                    ],
                                    onChanged: (v) {
                                      if (v == null) return;
                                      setState(() {
                                        _segments[idx] = seg.copyWith(
                                          billAs: v,
                                          billedMinutes: _computeBilledMins(
                                              v, seg.actualMinutes),
                                        );
                                      });
                                      _recalcAll();
                                    },
                                  ),
                                  const SizedBox(width: 12),
                                  Text(
                                    'Billed: ${seg.billedMinutes}m  → ₹${(seg.ratePerHour * (seg.billedMinutes / 60)).toStringAsFixed(2)}',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }),

                      const SizedBox(height: 8),
                      Text(
                          'Session total: ₹${_sessionTotal.toStringAsFixed(2)}'),

                      const SizedBox(height: 8),
                      const Text('Orders:'),
                      if (_orders.isEmpty) const Text('• No orders added'),
                      if (_orders.isNotEmpty)
                        ..._orders.map((o) {
                          final name = o['itemName'] ?? '';
                          final qty = o['qty'] ?? 0;
                          final total =
                              o['total'] ?? o['computedTotal'] ?? 0;
                          return Text('• $name x$qty → ₹$total');
                        }),
                      const SizedBox(height: 8),
                      Text(
                          'Orders total: ₹${_ordersTotal.toStringAsFixed(2)}'),

                      const Divider(color: Colors.white24),
                      const Text(
                        'Adjustments',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _discountCtrl,
                              onChanged: (_) => _recalcAll(),
                              decoration: const InputDecoration(
                                labelText: 'Discount (₹)',
                                labelStyle:
                                    TextStyle(color: Colors.white70),
                                enabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.white24),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.white),
                                ),
                              ),
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _taxPercentCtrl,
                              onChanged: (_) => _recalcAll(),
                              decoration: const InputDecoration(
                                labelText: 'Tax %',
                                labelStyle:
                                    TextStyle(color: Colors.white70),
                                enabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.white24),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.white),
                                ),
                              ),
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ],
                      ),

                      const Divider(color: Colors.white24),
                      Text(
                        'Grand total: ₹${_calcGrandTotal().toStringAsFixed(2)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 16),
                      ),
                      const SizedBox(height: 14),

                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _closing ? null : _closeSession,
                          child: _closing
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2),
                                )
                              : const Text('Close session'),
                        ),
                      ),
                      TextButton(
                        onPressed:
                            _closing ? null : () => Navigator.of(context).pop(),
                        child: const Text('Cancel'),
                      ),
                    ],
                  ),
                ),
      ),
    ));
  }
}

// helper classes -------------------------------------------------------
class _SeatSegment {
  final String? seatId;
  final String? seatLabel;
  final DateTime from;
  final DateTime to;
  final String billAs; // 'actual' | '30' | '60'
  final int actualMinutes;
  final int billedMinutes;
  final num ratePerHour;

  _SeatSegment({
    required this.seatId,
    this.seatLabel,
    required this.from,
    required this.to,
    this.billAs = 'actual',
    this.actualMinutes = 0,
    this.billedMinutes = 0,
    this.ratePerHour = 0,
  });

  _SeatSegment copyWith({
    String? seatId,
    String? seatLabel,
    DateTime? from,
    DateTime? to,
    String? billAs,
    int? actualMinutes,
    int? billedMinutes,
    num? ratePerHour,
  }) {
    return _SeatSegment(
      seatId: seatId ?? this.seatId,
      seatLabel: seatLabel ?? this.seatLabel,
      from: from ?? this.from,
      to: to ?? this.to,
      billAs: billAs ?? this.billAs,
      actualMinutes: actualMinutes ?? this.actualMinutes,
      billedMinutes: billedMinutes ?? this.billedMinutes,
      ratePerHour: ratePerHour ?? this.ratePerHour,
    );
  }
}
