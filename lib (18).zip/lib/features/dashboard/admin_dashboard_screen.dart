import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/app_shell.dart';
import '../bookings/add_booking_dialog.dart';
import '../bookings/booking_actions_dialog.dart';
import '../bookings/booking_close_bill_dialog.dart';

/// ---------- Local time/window helpers (additive, file-scoped) ----------
DateTime _startOfDay(DateTime now) => DateTime(now.year, now.month, now.day);
DateTime _endOfDay(DateTime now) => _startOfDay(now).add(const Duration(days: 1));

DateTime? _endFrom(Map<String, dynamic> m) {
  final ts = (m['startTime'] as Timestamp?)?.toDate();
  final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
  if (ts == null) return null;
  return ts.add(Duration(minutes: dur));
}

String _statusOf(Map<String, dynamic> m) =>
    ((m['status'] as String?) ?? '').toLowerCase();

bool _isCancelled(Map<String, dynamic> m) => _statusOf(m) == 'cancelled';
bool _isCompleted(Map<String, dynamic> m) => _statusOf(m) == 'completed';

bool _isActiveNow(Map<String, dynamic> m, DateTime now) {
  // Only truly "live" sessions should be treated as active
  if (_isCancelled(m) || _isCompleted(m)) return false;
  final start = (m['startTime'] as Timestamp?)?.toDate();
  final end = _endFrom(m);
  if (start == null || end == null) return false;
  return start.isBefore(now) && end.isAfter(now);
}

bool _isOverdueNow(Map<String, dynamic> m, DateTime now) {
  // Overdue only matters for sessions that are NOT completed / cancelled
  if (_isCancelled(m) || _isCompleted(m)) return false;
  final end = _endFrom(m);
  if (end == null) return false;
  return now.isAfter(end);
}

/// ======================================================================

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  String? _selectedBranchId;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return AppShell(
      child: user == null
          ? const Center(
              child: Text(
                'Not logged in',
                style: TextStyle(color: Colors.white),
              ),
            )
          : StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(user.uid)
                  .snapshots(),
              builder: (context, userSnap) {
                if (userSnap.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Colors.white),
                  );
                }

                final userData =
                    userSnap.data?.data() as Map<String, dynamic>? ?? {};
                final role = (userData['role'] ?? 'staff').toString();
                final List<dynamic> branchIdsDyn =
                    (userData['branchIds'] as List<dynamic>?) ?? [];
                final allowedBranchIds =
                    branchIdsDyn.map((e) => e.toString()).toList();

                final branchesRef =
                    FirebaseFirestore.instance.collection('branches');

                return StreamBuilder<QuerySnapshot>(
                  stream: branchesRef.snapshots(),
                  builder: (context, branchSnap) {
                    if (branchSnap.connectionState ==
                        ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(color: Colors.white),
                      );
                    }

                    if (!branchSnap.hasData ||
                        branchSnap.data!.docs.isEmpty) {
                      return const Center(
                        child: Text(
                          'No branches configured yet.',
                          style: TextStyle(color: Colors.white70),
                        ),
                      );
                    }

                    final allBranches = branchSnap.data!.docs;
                    final visibleBranches =
                        (role == 'superadmin' || allowedBranchIds.isEmpty)
                            ? allBranches
                            : allBranches
                                .where(
                                  (b) => allowedBranchIds.contains(b.id),
                                )
                                .toList();

                    if (visibleBranches.isEmpty) {
                      return const Center(
                        child: Text(
                          'No branches assigned to your account.',
                          style: TextStyle(color: Colors.white70),
                        ),
                      );
                    }

                    // keep branch selection stable
                    String effectiveBranchId = _selectedBranchId ??
                        visibleBranches.first.id;
                    if (_selectedBranchId == null ||
                        !visibleBranches
                            .any((b) => b.id == _selectedBranchId)) {
                      effectiveBranchId = visibleBranches.first.id;
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (!mounted) return;
                        setState(() {
                          _selectedBranchId = effectiveBranchId;
                        });
                      });
                    }

                    final selectedBranchDoc = visibleBranches
                        .firstWhere((b) => b.id == effectiveBranchId);
                    final selectedBranchName =
                        (selectedBranchDoc.data()
                                    as Map<String, dynamic>?)?['name']
                                ?.toString() ??
                            effectiveBranchId;

                    return SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Greeting
                          Text(
                            'Hello, ${userData['name'] ?? 'Admin'} 👋',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                          ),
                          const SizedBox(height: 12),

                          // Branch selector
                          Row(
                            children: [
                              Text(
                                'Branch:',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleSmall
                                    ?.copyWith(
                                      color: Colors.white70,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                              const SizedBox(width: 12),
                              Container(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF111827),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: Colors.white12,
                                  ),
                                ),
                                child: DropdownButton<String>(
                                  value: effectiveBranchId,
                                  dropdownColor: const Color(0xFF111827),
                                  underline: const SizedBox.shrink(),
                                  style: const TextStyle(color: Colors.white),
                                  items: visibleBranches.map((b) {
                                    final data =
                                        b.data() as Map<String, dynamic>? ??
                                            {};
                                    final name =
                                        (data['name'] ?? b.id).toString();
                                    return DropdownMenuItem(
                                      value: b.id,
                                      child: Text(name),
                                    );
                                  }).toList(),
                                  onChanged: (v) {
                                    if (v == null) return;
                                    setState(() {
                                      _selectedBranchId = v;
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 20),

                          // Top stats (per selected branch)
                          Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              const _BranchesStatCard(),
                              _TodayTotalBookingsStatCard(
                                role: role,
                                selectedBranchId: effectiveBranchId,
                              ),
                              _ActiveSessionsStatCard(
                                role: role,
                                selectedBranchId: effectiveBranchId,
                              ),
                              _TodayRevenueStatCard(
                                role: role,
                                selectedBranchId: effectiveBranchId,
                              ),
                              _PendingPaymentsStatCard(
                                role: role,
                                selectedBranchId: effectiveBranchId,
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),

                          // Quick actions (branch-scoped)
                          _QuickActionsRow(
                            role: role,
                            allowedBranchIds: allowedBranchIds,
                            selectedBranchId: effectiveBranchId,
                          ),
                          const SizedBox(height: 24),

                          Text(
                            'Console Map (Live)',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                          ),
                          const SizedBox(height: 12),
                          _ConsoleMapCard(
                            branchId: effectiveBranchId,
                          ),
                          const SizedBox(height: 30),

                          _UpcomingSessionsCard(
                            branchId: effectiveBranchId,
                          ),
                          const SizedBox(height: 30),

                          Text(
                            'Today\'s Active Sessions',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                          ),
                          const SizedBox(height: 12),
                          _TodayActiveSessionsCard(
                            branchId: effectiveBranchId,
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

// ----------------- generic stat card -----------------
class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  const _StatCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 22,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _BranchesStatCard extends StatelessWidget {
  const _BranchesStatCard();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('branches').snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _StatCard(title: 'Total Branches', value: '$count');
      },
    );
  }
}

/// Today total bookings = sessions that start today (per selected branch)
class _TodayTotalBookingsStatCard extends StatelessWidget {
  final String role;
  final String selectedBranchId;
  const _TodayTotalBookingsStatCard({
    required this.role,
    required this.selectedBranchId,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream:
          FirebaseFirestore.instance.collectionGroup('sessions').snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const _StatCard(title: 'Today’s Bookings', value: '0');
        }

        final now = DateTime.now();
        final startOfDay = _startOfDay(now);
        final endOfDay = _endOfDay(now);

        int count = 0;
        for (final d in snap.data!.docs) {
          final data = d.data() as Map<String, dynamic>? ?? {};
          final branchId = data['branchId']?.toString();
          if (branchId != selectedBranchId) continue;

          final ts = (data['startTime'] as Timestamp?)?.toDate();
          if (ts == null) continue;
          if (!ts.isBefore(endOfDay) || ts.isBefore(startOfDay)) continue;

          count++;
        }

        return _StatCard(title: 'Today’s Bookings', value: '$count');
      },
    );
  }
}

/// Active sessions STAT = time-window active for selected branch (ignore status)
class _ActiveSessionsStatCard extends StatelessWidget {
  final String role;
  final String selectedBranchId;
  const _ActiveSessionsStatCard({
    required this.role,
    required this.selectedBranchId,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfDay = _startOfDay(now);
    final endOfDay = _endOfDay(now);

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('branches')
          .doc(selectedBranchId)
          .collection('sessions')
          .where('startTime',
              isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('startTime', isLessThan: Timestamp.fromDate(endOfDay))
          .snapshots(),
      builder: (context, snap) {
        final docs = (snap.data?.docs ?? []).where((d) {
          final m = d.data() as Map<String, dynamic>? ?? {};
          return _isActiveNow(m, DateTime.now());
        }).toList();
        return _StatCard(title: 'Active Bookings', value: '${docs.length}');
      },
    );
  }
}

/// Today Revenue = sum of PAID, COMPLETED sessions closed today (selected branch)
class _TodayRevenueStatCard extends StatelessWidget {
  final String role;
  final String selectedBranchId;
  const _TodayRevenueStatCard({
    required this.role,
    required this.selectedBranchId,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfDay = _startOfDay(now);
    final endOfDay = _endOfDay(now);

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collectionGroup('sessions')
          .where('closedAt',
              isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('closedAt', isLessThan: Timestamp.fromDate(endOfDay))
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const _StatCard(title: 'Today Revenue', value: '₹0');
        }
        double total = 0;
        for (final d in snap.data!.docs) {
          final data = d.data() as Map<String, dynamic>? ?? {};
          final branchId = data['branchId']?.toString();
          if (branchId != selectedBranchId) continue;

          final status = (data['status'] as String?) ?? '';
          final payStat = (data['paymentStatus'] as String?) ?? '';
          if (status == 'completed' && payStat == 'paid') {
            total += (data['billAmount'] as num?)?.toDouble() ?? 0.0;
          }
        }
        return _StatCard(
          title: 'Today Revenue',
          value: '₹${total.toStringAsFixed(0)}',
        );
      },
    );
  }
}

/// Pending Payments — SUM of billAmount where paymentStatus == 'pending' AND status == 'completed' (selected branch)
class _PendingPaymentsStatCard extends StatelessWidget {
  final String role;
  final String selectedBranchId;
  const _PendingPaymentsStatCard({
    required this.role,
    required this.selectedBranchId,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collectionGroup('sessions')
          .where('paymentStatus', isEqualTo: 'pending')
          .snapshots(),
      builder: (context, snap) {
        double sum = 0;
        for (final d in snap.data?.docs ?? []) {
          final m = d.data() as Map<String, dynamic>? ?? {};
          final b = m['branchId']?.toString();
          if (b != selectedBranchId) continue;

          // Only count sessions that are actually completed but not yet paid
          if (_statusOf(m) != 'completed') continue;

          sum += (m['billAmount'] as num?)?.toDouble() ?? 0.0;
        }
        return _StatCard(
            title: 'Pending Payments', value: '₹${sum.toStringAsFixed(0)}');
      },
    );
  }
}

class _QuickActionsRow extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  final String selectedBranchId;
  const _QuickActionsRow({
    required this.role,
    required this.allowedBranchIds,
    required this.selectedBranchId,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        // 1) New Walk-in: open AddBookingDialog with selected branch preselected
        _QuickActionButton(
          icon: Icons.person_add_alt_1,
          label: 'New Walk-in',
          onTap: () async {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => AddBookingDialog(
                allowedBranchIds: allowedBranchIds,
                initialBranchId: selectedBranchId,
              ),
            );
          },
        ),

        // View Bookings -> popup (today, selected branch only)
        _QuickActionButton(
          icon: Icons.event_note_outlined,
          label: 'View Bookings',
          onTap: () {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            showDialog(
              context: context,
              builder: (_) =>
                  _TodaysBookingsDialog(branchId: selectedBranchId),
            );
          },
        ),

        // 2) Add F&B Order — time-window active picker
        _QuickActionButton(
          icon: Icons.fastfood_outlined,
          label: 'Add F&B Order',
          onTap: () async {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            await _openSessionPickerAndThen(
              context: context,
              branchId: selectedBranchId,
              onSessionSelected: (branchId, sessionId, data) {
                showDialog(
                  context: context,
                  builder: (_) => BookingActionsDialog(
                    branchId: branchId,
                    sessionId: sessionId,
                    data: data,
                  ),
                );
              },
            );
          },
        ),

        // 3) Quick Checkout — time-window active picker
        _QuickActionButton(
          icon: Icons.payments_outlined,
          label: 'Quick Checkout',
          onTap: () async {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            await _openSessionPickerAndThen(
              context: context,
              branchId: selectedBranchId,
              onSessionSelected: (branchId, sessionId, data) {
                showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: branchId,
                    sessionId: sessionId,
                    data: data,
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  /// Picker now uses TIME-WINDOW ACTIVE (ignores status in DB but respects completed/cancelled),
  /// excludes only `cancelled` and `completed`, scoped to TODAY for performance.
  Future<void> _openSessionPickerAndThen({
    required BuildContext context,
    required String branchId,
    required void Function(
            String branchId, String sessionId, Map<String, dynamic> data)
        onSessionSelected,
  }) async {
    final now = DateTime.now();
    final startOfDay = _startOfDay(now);
    final endOfDay = _endOfDay(now);

    final sessionsSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .where('startTime',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('startTime', isLessThan: Timestamp.fromDate(endOfDay))
        .get();

    final activeDocs = sessionsSnap.docs.where((doc) {
      final data = (doc.data() as Map<String, dynamic>?) ?? {};
      return _isActiveNow(data, now);
    }).toList();

    if (activeDocs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No active sessions for this branch')),
      );
      return;
    }

    if (activeDocs.length == 1) {
      final s = activeDocs.first;
      final data = (s.data() as Map<String, dynamic>?) ?? {};
      onSessionSelected(branchId, s.id, data);
      return;
    }

    showDialog(
      context: context,
      builder: (_) {
        return Dialog(
          backgroundColor: const Color(0xFF111827),
          child: Container(
            width: 400,
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Select session',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 12),
                ...activeDocs.map((doc) {
                  final data = (doc.data() as Map<String, dynamic>?) ?? {};
                  final customer =
                      data['customerName']?.toString() ?? 'Walk-in';
                  final seat = data['seatLabel']?.toString() ?? 'Seat';
                  final ts = (data['startTime'] as Timestamp?)?.toDate();
                  final timeString = ts != null
                      ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                      : '—';
                  return ListTile(
                    title: Text(
                      customer,
                      style: const TextStyle(color: Colors.white),
                    ),
                    subtitle: Text(
                      'Console: $seat | Start: $timeString',
                      style: const TextStyle(color: Colors.white70),
                    ),
                    onTap: () {
                      Navigator.of(context).pop();
                      onSessionSelected(branchId, doc.id, data);
                    },
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2937),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 32,
              width: 32,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- console map ----------------

class _ConsoleMapCard extends StatelessWidget {
  final String branchId;
  const _ConsoleMapCard({
    required this.branchId,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: _BranchConsoleGrid(branchId: branchId),
    );
  }
}

class _SeatSession {
  final String id;
  final String status;
  final String customerName;
  final DateTime? start;
  final DateTime? end;

  _SeatSession({
    required this.id,
    required this.status,
    required this.customerName,
    required this.start,
    required this.end,
  });
}

class _BranchConsoleGrid extends StatelessWidget {
  final String branchId;
  const _BranchConsoleGrid({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final seatsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('seats');
    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: seatsRef.snapshots(),
      builder: (context, seatsSnap) {
        final seats = seatsSnap.data?.docs ?? [];

        return StreamBuilder<QuerySnapshot>(
          stream: sessionsRef.snapshots(),
          builder: (context, sessionsSnap) {
            if (seatsSnap.connectionState == ConnectionState.waiting &&
                seatsSnap.data == null) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: LinearProgressIndicator(color: Colors.white),
              );
            }

            if (seats.isEmpty) {
              return const Text(
                'No consoles/seats found for this branch.',
                style: TextStyle(color: Colors.white70),
              );
            }

            final sessions = sessionsSnap.data?.docs ?? [];
            final now = DateTime.now();

            // Map seatId -> list of sessions for that seat
            final Map<String, List<_SeatSession>> sessionsBySeat = {};
            for (final s in sessions) {
              final sData = s.data() as Map<String, dynamic>? ?? {};
              final seatId = sData['seatId']?.toString();
              if (seatId == null) continue;

              final statusRaw = sData['status']?.toString() ?? 'active';
              final status = statusRaw.toLowerCase();

              // Skip cancelled and completed sessions for live map status
              if (status == 'cancelled' || status == 'completed') continue;

              final start = (sData['startTime'] as Timestamp?)?.toDate();
              final dur = (sData['durationMinutes'] as num?)?.toInt() ?? 60;
              final end =
                  start != null ? start.add(Duration(minutes: dur)) : null;

              sessionsBySeat.putIfAbsent(seatId, () => []).add(
                    _SeatSession(
                      id: s.id,
                      status: statusRaw,
                      customerName:
                          sData['customerName']?.toString() ?? 'Walk-in',
                      start: start,
                      end: end,
                    ),
                  );
            }

            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: seats.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 6,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.15,
              ),
              itemBuilder: (context, index) {
                final seatDoc = seats[index];
                final seatId = seatDoc.id;
                final data = seatDoc.data() as Map<String, dynamic>? ?? {};
                final label = data['label']?.toString() ?? 'Seat ${index + 1}';
                final type = data['type']?.toString() ?? 'console';
                final isActive = (data['active'] as bool?) ?? true;

                final seatSessions = (sessionsBySeat[seatId] ?? []).toList()
                  ..sort(
                    (a, b) {
                      final aStart =
                          a.start ?? DateTime.fromMillisecondsSinceEpoch(0);
                      final bStart =
                          b.start ?? DateTime.fromMillisecondsSinceEpoch(0);
                      return aStart.compareTo(bStart);
                    },
                  );

                // Determine overall status for the tile (time-window truth)
                String status = 'free';
                bool hasActiveNow = false;
                bool hasReservedFuture = false;
                bool hasFutureAny = false;

                for (final s in seatSessions) {
                  final start = s.start;
                  final end = s.end;
                  if (start == null || end == null) continue;

                  // active now if time-window contains now
                  if (now.isAfter(start) && now.isBefore(end)) {
                    hasActiveNow = true;
                  }
                  if (s.status.toLowerCase() == 'reserved' &&
                      start.isAfter(now)) {
                    hasReservedFuture = true;
                  }
                  if (start.isAfter(now)) {
                    hasFutureAny = true;
                  }
                }

                if (hasActiveNow) {
                  status = 'in_use';
                } else if (hasReservedFuture) {
                  status = 'reserved';
                } else if (hasFutureAny) {
                  status = 'booked';
                }

                // Detect overlap among sessions for this seat
                bool hasOverlap = false;
                for (var i = 0; i < seatSessions.length; i++) {
                  final a = seatSessions[i];
                  if (a.start == null || a.end == null) continue;
                  for (var j = i + 1; j < seatSessions.length; j++) {
                    final b = seatSessions[j];
                    if (b.start == null || b.end == null) continue;
                    final overlap = a.start!.isBefore(b.end!) &&
                        b.start!.isBefore(a.end!);
                    if (overlap) {
                      hasOverlap = true;
                      break;
                    }
                  }
                  if (hasOverlap) break;
                }

                return _ConsoleTile(
                  label: label,
                  type: type,
                  isActive: isActive,
                  status: status,
                  sessions: seatSessions,
                  hasOverlap: hasOverlap,
                );
              },
            );
          },
        );
      },
    );
  }
}

class _ConsoleTile extends StatelessWidget {
  final String label;
  final String type;
  final bool isActive;
  final String status;
  final List<_SeatSession> sessions;
  final bool hasOverlap;

  const _ConsoleTile({
    required this.label,
    required this.type,
    required this.isActive,
    required this.status,
    required this.sessions,
    required this.hasOverlap,
  });

  Color _statusColor() {
    switch (status) {
      case 'in_use':
        return Colors.grey.shade300; // grey (in use)
      case 'booked':
        return Colors.amberAccent;
      case 'reserved':
        return Colors.orangeAccent;
      default: // free
        return Colors.greenAccent; // green (free)
    }
  }

  Color _statusBg() {
    switch (status) {
      case 'in_use':
        return const Color(0xFF374151); // dark grey
      case 'booked':
        return const Color(0xFF3B2F0B); // dark yellow-ish
      case 'reserved':
        return const Color(0xFF4A1F1A);
      default: // free
        return const Color(0xFF064E3B); // dark green
    }
  }

  String _statusText() {
    switch (status) {
      case 'in_use':
        return 'In use';
      case 'booked':
        return 'Booked';
      case 'reserved':
        return 'Reserved';
      default:
        return 'Free';
    }
  }

  IconData _iconForType() {
    final lower = type.toLowerCase();
    if (lower.contains('pc')) return Icons.computer;
    if (lower.contains('console')) return Icons.sports_esports;
    if (lower.contains('recliner')) return Icons.chair_alt;
    return Icons.chair;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: sessions.isEmpty
          ? null
          : () {
              showDialog(
                context: context,
                builder: (_) {
                  return Dialog(
                    backgroundColor: const Color(0xFF111827),
                    child: DefaultTextStyle(
                      style: const TextStyle(color: Colors.white),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        width: 360,
                        color: const Color(0xFF111827),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              label,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 16),
                            ),
                            const SizedBox(height: 8),
                            Text('Status: ${_statusText()}'),
                            if (!isActive)
                              const Text(
                                'Console is marked inactive',
                                style: TextStyle(
                                    color: Colors.redAccent, fontSize: 12),
                              ),
                            const SizedBox(height: 12),
                            if (hasOverlap)
                              const Padding(
                                padding: EdgeInsets.only(bottom: 8.0),
                                child: Text(
                                  '⚠ Overlapping bookings detected on this console.',
                                  style: TextStyle(
                                    color: Colors.redAccent,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            const Text(
                              'Bookings for this console',
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 13),
                            ),
                            const SizedBox(height: 8),
                            if (sessions.isEmpty)
                              const Text(
                                'No bookings found.',
                                style: TextStyle(color: Colors.white70),
                              ),
                            if (sessions.isNotEmpty)
                              ...sessions.map((s) {
                                final st = s.start;
                                final et = s.end;
                                final stStr = st != null
                                    ? '${st.hour.toString().padLeft(2, '0')}:${st.minute.toString().padLeft(2, '0')}'
                                    : '—';
                                final etStr = et != null
                                    ? '${et.hour.toString().padLeft(2, '0')}:${et.minute.toString().padLeft(2, '0')}'
                                    : '—';
                                return Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 4.0),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.white10,
                                          borderRadius:
                                              BorderRadius.circular(999),
                                        ),
                                        child: Text(
                                          s.status,
                                          style: const TextStyle(fontSize: 10),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          s.customerName,
                                          style: const TextStyle(
                                              fontSize: 13,
                                              color: Colors.white),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        '$stStr–$etStr',
                                        style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.white70),
                                      ),
                                    ],
                                  ),
                                );
                              }),
                            const SizedBox(height: 12),
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                onPressed: () => Navigator.of(context).pop(),
                                child: const Text(
                                  'Close',
                                  style: TextStyle(color: Colors.white70),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            },
      child: Container(
        decoration: BoxDecoration(
          color: _statusBg(),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _statusColor(), width: 3),
        ),
        padding: const EdgeInsets.all(10),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(_iconForType(), color: Colors.white, size: 30),
                const SizedBox(height: 8),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  isActive ? type : '$type (inactive)',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                  ),
                ),
                if (sessions.length > 1)
                  const Padding(
                    padding: EdgeInsets.only(top: 4.0),
                    child: Text(
                      'Multiple bookings',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                      ),
                    ),
                  ),
              ],
            ),
            Positioned(
              right: 0,
              top: 0,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _statusColor().withOpacity(0.2),
                  border: Border.all(color: _statusColor()),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusText(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TodayActiveSessionsCard extends StatelessWidget {
  final String branchId;
  const _TodayActiveSessionsCard({
    required this.branchId,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfDay = _startOfDay(now);
    final endOfDay = _endOfDay(now);

    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .where('startTime',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('startTime', isLessThan: Timestamp.fromDate(endOfDay));

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: sessionsRef.snapshots(),
        builder: (context, sessionSnap) {
          if (sessionSnap.connectionState == ConnectionState.waiting) {
            return const LinearProgressIndicator(color: Colors.white);
          }
          final docs = sessionSnap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Text(
              'No sessions for today.',
              style: TextStyle(color: Colors.white70),
            );
          }

          final now = DateTime.now();
          final active = <QueryDocumentSnapshot>[];
          final overdue = <QueryDocumentSnapshot>[];

          for (final doc in docs) {
            final data = doc.data() as Map<String, dynamic>? ?? {};
            if (_isActiveNow(data, now)) {
              active.add(doc);
            } else if (_isOverdueNow(data, now)) {
              overdue.add(doc);
            }
          }

          if (active.isEmpty && overdue.isEmpty) {
            return const Text(
              'No active sessions right now.',
              style: TextStyle(color: Colors.white70),
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ...active.map((doc) {
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final customer =
                    data['customerName']?.toString() ?? 'Walk-in';
                final seatLabel =
                    data['seatLabel']?.toString() ?? 'Seat';
                final ts = (data['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null
                    ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                    : '—';
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Colors.black,
                    child:
                        Icon(Icons.chair_outlined, color: Colors.white),
                  ),
                  title: Text(
                    customer,
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    'Console: $seatLabel | Started: $timeString',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                  trailing: ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => BookingActionsDialog(
                          branchId: branchId,
                          sessionId: doc.id,
                          data: data,
                        ),
                      );
                    },
                    child: const Text('View'),
                  ),
                );
              }).toList(),
              if (overdue.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text(
                  'Overdue sessions',
                  style: TextStyle(
                    color: Colors.redAccent.shade100,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                ...overdue.map((doc) {
                  final data = doc.data() as Map<String, dynamic>? ?? {};
                  final customer =
                      data['customerName']?.toString() ?? 'Walk-in';
                  final seatLabel =
                      data['seatLabel']?.toString() ?? 'Seat';
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(
                      backgroundColor: Colors.redAccent,
                      child: Icon(Icons.warning_amber,
                          color: Colors.white),
                    ),
                    title: Text(
                      customer,
                      style: const TextStyle(color: Colors.white),
                    ),
                    subtitle: const Text(
                      'Should be closed',
                      style: TextStyle(color: Colors.white70),
                    ),
                    trailing: ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (_) => BookingActionsDialog(
                            branchId: branchId,
                            sessionId: doc.id,
                            data: data,
                          ),
                        );
                      },
                      child: const Text('Close now'),
                    ),
                  );
                }).toList(),
              ]
            ],
          );
        },
      ),
    );
  }
}

/// Upcoming card with manual Refresh (per selected branch)
class _UpcomingSessionsCard extends StatefulWidget {
  final String branchId;
  const _UpcomingSessionsCard({
    required this.branchId,
  });

  @override
  State<_UpcomingSessionsCard> createState() => _UpcomingSessionsCardState();
}

class _UpcomingSessionsCardState extends State<_UpcomingSessionsCard> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final now = DateTime.now();
      final inOneHour = now.add(const Duration(minutes: 60));
      // Query only this branch; filter status in memory
      final snap = await FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .where('startTime',
              isGreaterThanOrEqualTo: Timestamp.fromDate(now))
          .where('startTime',
              isLessThanOrEqualTo: Timestamp.fromDate(inOneHour))
          .get();

      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] as String?) ?? '';
        if (status != 'reserved') return false;
        return true;
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ??
              DateTime.fromMillisecondsSinceEpoch(0);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ??
              DateTime.fromMillisecondsSinceEpoch(0);
          return ta.compareTo(tb);
        });

      setState(() {
        _docs = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load upcoming bookings.';
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Upcoming in next 60 minutes',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Refresh',
                onPressed: _load,
                icon: const Icon(Icons.refresh, color: Colors.white70),
              )
            ],
          ),
          const SizedBox(height: 8),
          if (_loading)
            const Text(
              'Loading upcoming bookings...',
              style: TextStyle(color: Colors.white70),
            )
          else if (_error != null)
            const Text(
              'Failed to load upcoming bookings.',
              style: TextStyle(color: Colors.redAccent),
            )
          else if (_docs.isEmpty)
            const Text(
              'No upcoming bookings in the next 60 minutes.',
              style: TextStyle(color: Colors.white70),
            )
          else
            Column(
              children: _docs.map((doc) {
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final customer =
                    data['customerName']?.toString() ?? 'Walk-in';
                final seat = data['seatLabel']?.toString() ?? 'Seat';
                final ts = (data['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null
                    ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                    : '—';
                final branchName =
                    data['branchName']?.toString() ?? '';

                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Colors.deepOrange,
                    child: Icon(Icons.timer, color: Colors.white),
                  ),
                  title: Text(
                    customer,
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    '$branchName • Console: $seat • Starts at: $timeString • Yet to start',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                  trailing: TextButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => BookingActionsDialog(
                          branchId: widget.branchId,
                          sessionId: doc.id,
                          data: data,
                        ),
                      );
                    },
                    child: const Text('Manage'),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}

/// Popup: Today’s bookings (per selected branch)
class _TodaysBookingsDialog extends StatefulWidget {
  final String branchId;
  const _TodaysBookingsDialog({required this.branchId});

  @override
  State<_TodaysBookingsDialog> createState() => _TodaysBookingsDialogState();
}

class _TodaysBookingsDialogState extends State<_TodaysBookingsDialog> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final now = DateTime.now();
      final startOfDay = _startOfDay(now);
      final endOfDay = _endOfDay(now);

      // Branch-scoped time window
      final snap = await FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .where('startTime',
              isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
          .where('startTime',
              isLessThan: Timestamp.fromDate(endOfDay))
          .get();

      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] as String?) ?? '';
        if (status == 'cancelled') return false;
        return true;
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ??
              DateTime.fromMillisecondsSinceEpoch(0);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ??
              DateTime.fromMillisecondsSinceEpoch(0);
          return ta.compareTo(tb);
        });

      setState(() {
        _docs = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load bookings.';
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF111827),
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(16),
        color: const Color(0xFF111827),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Today’s Bookings',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Refresh',
                  onPressed: _load,
                  icon: const Icon(Icons.refresh, color: Colors.white70),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Text('Loading...',
                  style: TextStyle(color: Colors.white70))
            else if (_error != null)
              const Text(
                'Failed to load bookings.',
                style: TextStyle(color: Colors.redAccent),
              )
            else if (_docs.isEmpty)
              const Text('No bookings today.',
                  style: TextStyle(color: Colors.white70))
            else
              SizedBox(
                height: 380,
                child: ListView.separated(
                  itemCount: _docs.length,
                  separatorBuilder: (_, __) =>
                      const Divider(color: Colors.white12, height: 12),
                  itemBuilder: (context, i) {
                    final d = _docs[i];
                    final m = d.data() as Map<String, dynamic>? ?? {};
                    final name =
                        m['customerName']?.toString() ?? 'Walk-in';
                    final seat = m['seatLabel']?.toString() ?? '-';
                    final branch = m['branchName']?.toString() ?? '';
                    final ts = (m['startTime'] as Timestamp?)?.toDate();
                    final timeStr = ts != null
                        ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                        : '—';
                    final status = (m['status'] as String?) ?? '';

                    return ListTile(
                      leading: const Icon(Icons.event,
                          color: Colors.white70),
                      title: Text(name,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                        '$branch • Seat $seat • $status',
                        style: const TextStyle(color: Colors.white60),
                      ),
                      trailing: Text(
                        timeStr,
                        style:
                            const TextStyle(color: Colors.white70),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'Close',
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
