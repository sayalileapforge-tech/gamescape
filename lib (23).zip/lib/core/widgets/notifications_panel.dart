// lib/features/dashboard/notification_panel.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:gamescape_admin/features/bookings/booking_actions_dialog.dart';

/// Public widget you import in the dashboard:
/// `import 'notification_panel.dart';`
class NotificationsPanel extends StatefulWidget {
  final String userId;
  final String branchId;
  final String branchName;

  const NotificationsPanel({
    super.key,
    required this.userId,
    required this.branchId,
    required this.branchName,
  });

  @override
  State<NotificationsPanel> createState() => _NotificationsPanelState();
}

class _NotificationsPanelState extends State<NotificationsPanel> {
  bool _collapsed = false;

  // defaults if user has no prefs yet
  static const Map<String, bool> _defaults = {
    'endingSoon': true,
    'upcoming': true,
    'overdue': true,
    'lowStock': true,
    'pendingDues': true,
    'newBookings': true,
  };

  @override
  Widget build(BuildContext context) {
    final userDoc = FirebaseFirestore.instance.collection('users').doc(widget.userId);

    return StreamBuilder<DocumentSnapshot>(
      stream: userDoc.snapshots(),
      builder: (context, snap) {
        Map<String, dynamic> data = {};
        if (snap.hasData && snap.data?.data() != null) {
          data = snap.data!.data() as Map<String, dynamic>;
        }
        final prefsDyn = (data['notificationPrefs'] as Map?) ?? {};
        final prefs = <String, bool>{
          ..._defaults,
          ...prefsDyn.map((k, v) => MapEntry(k.toString(), v == true)),
        };

        if (_collapsed) {
          return _CollapsedRail(onExpand: () => setState(() => _collapsed = false));
        }

        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF111827),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white12),
          ),
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(Icons.notifications_active_outlined, color: Colors.white),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text('Notifications',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ),
                  IconButton(
                    tooltip: 'Preferences',
                    onPressed: () => showDialog(
                      context: context,
                      builder: (_) => Dialog(
                        backgroundColor: const Color(0xFF111827),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          // ⬇⬇⬇ Private editor widget in this file
                          child: _PrefsEditor(
                            userId: widget.userId,
                            initialPrefs: prefs,
                          ),
                        ),
                      ),
                    ),
                    icon: const Icon(Icons.tune, color: Colors.white70),
                  ),
                  IconButton(
                    tooltip: 'Collapse',
                    onPressed: () => setState(() => _collapsed = true),
                    icon: const Icon(Icons.chevron_right, color: Colors.white70),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView(
                  children: [
                    if (prefs['endingSoon'] == true)
                      _EndingSoonListTile(branchId: widget.branchId),
                    if (prefs['upcoming'] == true)
                      _UpcomingListTile(branchId: widget.branchId),
                    if (prefs['overdue'] == true)
                      _OverdueListTile(branchId: widget.branchId),
                    if (prefs['lowStock'] == true)
                      _LowStockListTile(branchId: widget.branchId),
                    if (prefs['pendingDues'] == true)
                      _PendingDuesListTile(branchId: widget.branchId),
                    if (prefs['newBookings'] == true)
                      _NewBookingsTodayListTile(branchId: widget.branchId),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _CollapsedRail extends StatelessWidget {
  final VoidCallback onExpand;
  const _CollapsedRail({required this.onExpand});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onExpand,
      child: Container(
        height: 420,
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white12),
        ),
        child: const Center(
          child: RotatedBox(
            quarterTurns: 1,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.notifications_none, color: Colors.white70),
                SizedBox(width: 8),
                Text('Notifications', style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// ───────────────────────── Preferences Editor (private in this file) ─────────────────────────
class _PrefsEditor extends StatefulWidget {
  final String userId;
  final Map<String, bool> initialPrefs;
  const _PrefsEditor({required this.userId, required this.initialPrefs});

  @override
  State<_PrefsEditor> createState() => _PrefsEditorState();
}

class _PrefsEditorState extends State<_PrefsEditor> {
  late Map<String, bool> _prefs;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _prefs = Map<String, bool>.from(widget.initialPrefs);
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final userDoc = FirebaseFirestore.instance.collection('users').doc(widget.userId);
    await userDoc.set({'notificationPrefs': _prefs}, SetOptions(merge: true));
    if (!mounted) return;
    setState(() => _saving = false);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Notification preferences saved')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style: const TextStyle(color: Colors.white),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('Notification Preferences',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          const SizedBox(height: 12),
          _toggle('Sessions ending in ≤10 mins', 'endingSoon'),
          _toggle('Upcoming reservations in ≤60 mins', 'upcoming'),
          _toggle('Overdue sessions', 'overdue'),
          _toggle('Low stock items', 'lowStock'),
          _toggle('Pending dues (today)', 'pendingDues'),
          _toggle('New bookings (today)', 'newBookings'),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving ? const CircularProgressIndicator() : const Text('Save'),
                ),
              ),
              const SizedBox(width: 12),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _toggle(String label, String key) {
    return SwitchListTile(
      value: _prefs[key] == true,
      onChanged: (v) => setState(() => _prefs[key] = v),
      contentPadding: EdgeInsets.zero,
      activeColor: Colors.white,
      title: Text(label, style: const TextStyle(color: Colors.white)),
    );
  }
}

/// ───────────────────────── Tiles (streams & counters) ─────────────────────────

class _EndingSoonListTile extends StatelessWidget {
  final String branchId;
  const _EndingSoonListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final now = DateTime.now();
        final soon = now.add(const Duration(minutes: 10));
        int count = 0;
        QueryDocumentSnapshot? example;
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            if ((m['status'] ?? '').toString().toLowerCase() != 'active') continue;
            final st = (m['startTime'] as Timestamp?)?.toDate();
            final dur = (m['durationMinutes'] as num?)?.toInt() ?? 0;
            if (st == null) continue;
            final end = st.add(Duration(minutes: dur));
            if (end.isAfter(now) && !end.isAfter(soon)) {
              count++;
              example ??= d;
            }
          }
        }
        return _panelTile(
          icon: Icons.hourglass_bottom,
          title: 'Ending soon (≤10m)',
          badge: '$count',
          onTap: example == null
              ? null
              : () {
                  final m = example!.data() as Map<String, dynamic>? ?? {};
                  showDialog(
                    context: context,
                    builder: (_) => BookingActionsDialog(
                      branchId: branchId,
                      sessionId: example!.id,
                      data: m,
                    ),
                  );
                },
        );
      },
    );
  }
}

class _UpcomingListTile extends StatelessWidget {
  final String branchId;
  const _UpcomingListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final inOneHour = now.add(const Duration(minutes: 60));
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
        .where('startTime', isLessThanOrEqualTo: Timestamp.fromDate(inOneHour))
        .where('status', isEqualTo: 'reserved');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _panelTile(
          icon: Icons.schedule, // safe alternative
          title: 'Upcoming (≤60m)',
          badge: '$count',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Open "Upcoming in next 60 minutes" section on the left.')),
            );
          },
        );
      },
    );
  }
}

class _OverdueListTile extends StatelessWidget {
  final String branchId;
  const _OverdueListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        int count = 0;
        QueryDocumentSnapshot? example;
        if (snap.hasData) {
          final now = DateTime.now();
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final st = (m['startTime'] as Timestamp?)?.toDate();
            final dur = (m['durationMinutes'] as num?)?.toInt() ?? 0;
            final status = (m['status'] ?? '').toString().toLowerCase();
            if (st == null) continue;
            final end = st.add(Duration(minutes: dur));
            final cancelled = status == 'cancelled' || status == 'completed';
            if (!cancelled && now.isAfter(end)) {
              count++;
              example ??= d;
            }
          }
        }
        return _panelTile(
          icon: Icons.warning_amber_outlined,
          title: 'Overdue',
          badge: '$count',
          onTap: example == null
              ? null
              : () {
                  final m = example!.data() as Map<String, dynamic>? ?? {};
                  showDialog(
                    context: context,
                    builder: (_) => BookingActionsDialog(
                      branchId: branchId,
                      sessionId: example!.id,
                      data: m,
                    ),
                  );
                },
        );
      },
    );
  }
}

class _LowStockListTile extends StatelessWidget {
  final String branchId;
  const _LowStockListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('inventory');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        int low = 0;
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final active = (m['active'] as bool?) ?? true;
            final qty = (m['stockQty'] as num?)?.toDouble() ?? 0;
            final thr = (m['reorderThreshold'] as num?)?.toDouble() ?? -1;
            if (active && thr >= 0 && qty <= thr) low++;
          }
        }
        return _panelTile(
          icon: Icons.inventory_2_outlined,
          title: 'Low stock',
          badge: '$low',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Open Inventory to adjust or reorder.')),
            );
          },
        );
      },
    );
  }
}

class _PendingDuesListTile extends StatelessWidget {
  final String branchId;
  const _PendingDuesListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    // Today window in IST converted to UTC
    final range = _todayIstToUtc();
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('closedAt', isGreaterThanOrEqualTo: range.startUtc)
        .where('closedAt', isLessThan: range.endUtc);

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        int pending = 0;
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final status = (m['status'] ?? '').toString().toLowerCase();
            final pay = (m['paymentStatus'] ?? '').toString().toLowerCase();
            if (status == 'completed' && pay == 'pending') {
              pending++;
            }
          }
        }
        return _panelTile(
          icon: Icons.payments_outlined,
          title: 'Pending dues (today)',
          badge: '$pending',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Use Invoices or Today stats to settle pending payments.')),
            );
          },
        );
      },
    );
  }
}

class _NewBookingsTodayListTile extends StatelessWidget {
  final String branchId;
  const _NewBookingsTodayListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
        .where('startTime', isLessThan: range.endUtc)
        .where('status', isNotEqualTo: 'cancelled');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _panelTile(
          icon: Icons.add_alert_outlined,
          title: 'New bookings (today)',
          badge: '$count',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Open “Today’s Bookings” from Quick Actions.')),
            );
          },
        );
      },
    );
  }
}

/// Helper for panel rows
Widget _panelTile({
  required IconData icon,
  required String title,
  required String badge,
  VoidCallback? onTap,
}) {
  return ListTile(
    leading: Icon(icon, color: Colors.white70),
    title: Text(title, style: const TextStyle(color: Colors.white)),
    trailing: Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white12,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white24),
      ),
      child: Text(badge, style: const TextStyle(color: Colors.white)),
    ),
    onTap: onTap,
  );
}

/// IST → UTC day window (same helper you used on dashboard)
class _DayRangeUtc {
  final Timestamp startUtc;
  final Timestamp endUtc;
  const _DayRangeUtc(this.startUtc, this.endUtc);
}

_DayRangeUtc _todayIstToUtc() {
  final nowLocal = DateTime.now(); // device IST in your case
  final startLocal = DateTime(nowLocal.year, nowLocal.month, nowLocal.day);
  final endLocal = startLocal.add(const Duration(days: 1));
  return _DayRangeUtc(
    Timestamp.fromDate(startLocal.toUtc()),
    Timestamp.fromDate(endLocal.toUtc()),
  );
}
