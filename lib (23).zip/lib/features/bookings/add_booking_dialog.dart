import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AddBookingDialog extends StatefulWidget {
  final List<String>? allowedBranchIds;
  final String? initialBranchId;

  // Prefill from Customers → Bookings flow
  final String? prefillName;
  final String? prefillPhone;

  const AddBookingDialog({
    super.key,
    this.allowedBranchIds,
    this.initialBranchId,
    this.prefillName,
    this.prefillPhone,
  });

  @override
  State<AddBookingDialog> createState() => _AddBookingDialogState();
}

class _AddBookingDialogState extends State<AddBookingDialog> {
  final _formKey = GlobalKey<FormState>();

  String? _selectedBranchId;
  String? _selectedBranchName;

  String? _selectedSeatType; // filter
  String? _selectedSeatId;
  String? _selectedSeatLabel;
  String? _selectedSeatTypeDisplay;

  // Multi-seat booking: list of seats in this booking
  final List<_SelectedSeat> _selectedSeats = [];

  final _customerNameCtrl = TextEditingController();
  final _customerPhoneCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  final _paxCtrl = TextEditingController();
  final _gamePrefCtrl = TextEditingController();
  String _paymentType = 'postpaid';

  final List<int> _durationOptions =
      const [30, 60, 90, 120, 150, 180, 240, 300];
  int _selectedDuration = 60;

  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _selectedBranchId = widget.initialBranchId;

    if ((widget.prefillName ?? '').isNotEmpty) {
      _customerNameCtrl.text = widget.prefillName!;
    }
    if ((widget.prefillPhone ?? '').isNotEmpty) {
      _customerPhoneCtrl.text = widget.prefillPhone!;
    }
  }

  @override
  Widget build(BuildContext context) {
    final branchesCol = FirebaseFirestore.instance.collection('branches');

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(18),
        child: SingleChildScrollView(
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Form(
              key: _formKey,
              autovalidateMode: AutovalidateMode.disabled,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Create Booking',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  const SizedBox(height: 14),

                  // Branch
                  StreamBuilder<QuerySnapshot>(
                    stream: branchesCol.snapshots(),
                    builder: (context, snapshot) {
                      final all = snapshot.hasData
                          ? snapshot.data!.docs
                          : <QueryDocumentSnapshot>[];
                      final items = (widget.allowedBranchIds == null ||
                              widget.allowedBranchIds!.isEmpty)
                          ? all
                          : all
                              .where((d) =>
                                  widget.allowedBranchIds!.contains(d.id))
                              .toList();

                      if (_selectedBranchId == null && items.isNotEmpty) {
                        _selectedBranchId = items.first.id;
                        _selectedBranchName =
                            (items.first.data() as Map<String, dynamic>? ??
                                    {})['name']
                                ?.toString();
                      }

                      return DropdownButtonFormField<String>(
                        value: _selectedBranchId,
                        dropdownColor: const Color(0xFF111827),
                        style: const TextStyle(color: Colors.white),
                        decoration: _darkInput('Select branch'),
                        items: items.map((d) {
                          final name =
                              (d.data() as Map<String, dynamic>? ?? {})['name']
                                      ?.toString() ??
                                  'Branch';
                          return DropdownMenuItem(
                            value: d.id,
                            child: Text(name),
                          );
                        }).toList(),
                        onChanged: (v) {
                          setState(() {
                            _selectedBranchId = v;
                            if (v != null) {
                              final doc = items.firstWhere(
                                (e) => e.id == v,
                                orElse: () => items.first,
                              );
                              final name =
                                  (doc.data() as Map<String, dynamic>? ??
                                          {})['name']
                                      ?.toString();
                              _selectedBranchName = name ?? '';
                            } else {
                              _selectedBranchName = null;
                            }
                            _selectedSeatId = null;
                            _selectedSeatLabel = null;
                            _selectedSeatType = null;
                            _selectedSeatTypeDisplay = null;
                            _selectedSeats.clear(); // reset multi-seat list
                          });
                        },
                        validator: (v) =>
                            (v == null || v.isEmpty) ? 'Select a branch' : null,
                      );
                    },
                  ),

                  const SizedBox(height: 10),

                  // Seat type filter + seat select + multi-seat selector
                  if (_selectedBranchId != null)
                    StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('branches')
                          .doc(_selectedBranchId)
                          .collection('seats')
                          .where('active', isEqualTo: true)
                          .snapshots(),
                      builder: (context, snapshot) {
                        // COPY & SORT seats by label
                        final List<QueryDocumentSnapshot> seatDocs =
                            snapshot.hasData
                                ? snapshot.data!.docs.toList()
                                : <QueryDocumentSnapshot>[];

                        seatDocs.sort((a, b) {
                          final la =
                              ((a.data() as Map<String, dynamic>)['label'] ??
                                      '')
                                  .toString()
                                  .toLowerCase();
                          final lb =
                              ((b.data() as Map<String, dynamic>)['label'] ??
                                      '')
                                  .toString()
                                  .toLowerCase();
                          return la.compareTo(lb);
                        });

                        final types = <String>{};
                        for (final d in seatDocs) {
                          final t = ((d.data() as Map<String, dynamic>)['type'] ?? '')
                              .toString();
                          if (t.isNotEmpty) types.add(t);
                        }
                        final typeList = ['All', ...types.toList()..sort()];

                        final filtered =
                            (_selectedSeatType == null || _selectedSeatType == 'All')
                                ? seatDocs
                                : seatDocs
                                    .where((d) =>
                                        ((d.data()
                                                    as Map<String, dynamic>)[
                                                'type'] ??
                                            '') ==
                                        _selectedSeatType)
                                    .toList();

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            DropdownButtonFormField<String>(
                              value: _selectedSeatType ?? 'All',
                              dropdownColor: const Color(0xFF111827),
                              style: const TextStyle(color: Colors.white),
                              decoration: _darkInput('Seat type'),
                              items: typeList
                                  .map((t) => DropdownMenuItem(
                                      value: t, child: Text(t)))
                                  .toList(),
                              onChanged: (v) {
                                setState(() {
                                  _selectedSeatType = v;
                                  _selectedSeatId = null;
                                  _selectedSeatLabel = null;
                                  _selectedSeatTypeDisplay = null;
                                });
                              },
                            ),
                            const SizedBox(height: 10),
                            DropdownButtonFormField<String>(
                              value: _selectedSeatId,
                              dropdownColor: const Color(0xFF111827),
                              style: const TextStyle(color: Colors.white),
                              decoration: _darkInput('Select seat'),
                              items: filtered.map((d) {
                                final data =
                                    d.data() as Map<String, dynamic>;
                                final t = (data['type'] ?? '').toString();
                                final rate =
                                    (data['ratePerHour'] ?? 0).toString();
                                final label =
                                    (data['label'] ?? 'Seat').toString();
                                return DropdownMenuItem(
                                  value: d.id,
                                  child: Text('$label • $t • ₹$rate/hr'),
                                );
                              }).toList(),
                              onChanged: (v) {
                                setState(() {
                                  _selectedSeatId = v;
                                  if (v != null && filtered.isNotEmpty) {
                                    // Find matching doc; if not found but list non-empty, take first safely
                                    QueryDocumentSnapshot match;
                                    try {
                                      match = filtered.firstWhere(
                                          (e) => e.id == v);
                                    } catch (_) {
                                      match = filtered.first;
                                    }
                                    final data = match.data()
                                        as Map<String, dynamic>;
                                    _selectedSeatLabel =
                                        (data['label'] ?? '').toString();
                                    _selectedSeatTypeDisplay =
                                        (data['type'] ?? '').toString();
                                  } else {
                                    _selectedSeatLabel = null;
                                    _selectedSeatTypeDisplay = null;
                                  }
                                });
                              },
                              validator: (v) {
                                // Allow "seat from list" OR "seats added" below.
                                if ((_selectedSeats.isEmpty) &&
                                    (v == null || v.isEmpty)) {
                                  return 'Select at least one seat';
                                }
                                return null;
                              },
                            ),
                            if (_selectedSeatTypeDisplay != null) ...[
                              const SizedBox(height: 10),
                              InputDecorator(
                                decoration: _darkInput('Selected seat type'),
                                child: Text(_selectedSeatTypeDisplay!),
                              ),
                            ],
                            const SizedBox(height: 8),
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton.icon(
                                onPressed: _selectedSeatId == null
                                    ? null
                                    : () {
                                        final id = _selectedSeatId!;
                                        final already = _selectedSeats.any(
                                            (s) => s.seatId == id);
                                        if (already) {
                                          _toast('Seat already added');
                                          return;
                                        }
                                        _selectedSeats.add(
                                          _SelectedSeat(
                                            seatId: id,
                                            seatLabel:
                                                _selectedSeatLabel ?? 'Seat',
                                            seatType:
                                                _selectedSeatTypeDisplay ??
                                                    '',
                                          ),
                                        );
                                        setState(() {});
                                      },
                                icon: const Icon(Icons.add, size: 16),
                                label: const Text('Add seat to booking'),
                              ),
                            ),
                            if (_selectedSeats.isNotEmpty) ...[
                              const SizedBox(height: 6),
                              const Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  'Seats in this booking:',
                                  style: TextStyle(
                                      color: Colors.white70, fontSize: 12),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Wrap(
                                spacing: 6,
                                runSpacing: 4,
                                children: _selectedSeats
                                    .map(
                                      (s) => Chip(
                                        label: Text(
                                          '${s.seatLabel} (${s.seatType})',
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11),
                                        ),
                                        backgroundColor:
                                            const Color(0xFF111827),
                                        deleteIcon:
                                            const Icon(Icons.close, size: 14),
                                        onDeleted: () {
                                          setState(() {
                                            _selectedSeats.remove(s);
                                          });
                                        },
                                      ),
                                    )
                                    .toList(),
                              ),
                            ],
                            const SizedBox(height: 8),
                            const Text(
                              'Tip: For a group of players on multiple seats, add all seats here before creating the booking.',
                              style: TextStyle(
                                  color: Colors.white38, fontSize: 11),
                            ),
                          ],
                        );
                      },
                    ),

                  const SizedBox(height: 10),

                  // Customer details
                  TextFormField(
                    controller: _customerPhoneCtrl,
                    decoration: _darkTextField('Customer phone'),
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    validator: (v) {
                      final normalized = _normalizePhone(v ?? '');
                      if (normalized.isEmpty) return 'Enter phone number';
                      if (normalized.length != 10) {
                        return 'Enter 10-digit phone';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: _customerNameCtrl,
                    decoration: _darkTextField('Customer name'),
                    style: const TextStyle(color: Colors.white),
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Enter customer name'
                        : null,
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: _paxCtrl,
                    decoration: _darkTextField('Number of people'),
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) {
                        return 'Enter number of people';
                      }
                      final n = int.tryParse(v.trim());
                      if (n == null || n <= 0) return 'Pax must be at least 1';
                      if (n > 99) return 'Pax out of range';
                      return null;
                    },
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _gamePrefCtrl,
                    decoration:
                        _darkTextField('Game preference (optional)'),
                    style: const TextStyle(color: Colors.white),
                  ),

                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: _paymentType,
                    dropdownColor: const Color(0xFF111827),
                    style: const TextStyle(color: Colors.white),
                    decoration: _darkInput('Payment type'),
                    items: const [
                      DropdownMenuItem(
                          value: 'prepaid', child: Text('Prepaid')),
                      DropdownMenuItem(
                          value: 'postpaid', child: Text('Postpaid')),
                    ],
                    onChanged: (v) {
                      if (v != null) setState(() => _paymentType = v);
                    },
                  ),

                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: _pickDate,
                          child: InputDecorator(
                            decoration: _darkInput('Date'),
                            child: Text(
                              '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}',
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: InkWell(
                          onTap: _pickTime,
                          child: InputDecorator(
                            decoration: _darkInput('Time'),
                            child: Text(_selectedTime.format(context)),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 10),
                  DropdownButtonFormField<int>(
                    value: _selectedDuration,
                    dropdownColor: const Color(0xFF111827),
                    style: const TextStyle(color: Colors.white),
                    decoration: _darkInput('Duration'),
                    items: _durationOptions
                        .map((m) => DropdownMenuItem(
                            value: m, child: Text('$m minutes')))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _selectedDuration = v);
                    },
                  ),

                  const SizedBox(height: 10),
                  TextField(
                    controller: _notesCtrl,
                    decoration: _darkTextField('Notes'),
                    style: const TextStyle(color: Colors.white),
                    maxLines: 2,
                  ),

                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 42,
                          child: ElevatedButton(
                            onPressed: _saving ? null : _onSubmit,
                            child: _saving
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2),
                                  )
                                : const Text('Create'),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Cancel'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _darkInput(String label) {
    return const InputDecoration(
      labelText: null,
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white24),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
    ).copyWith(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
    );
  }

  InputDecoration _darkTextField(String label) => _darkInput(label);

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 30)),
      initialDate: _selectedDate,
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _showBookingDeniedDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1F2937),
          title: const Text(
            'Booking denied',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
          ),
          content: const Text(
            'One or more seats are already booked for the selected time range.',
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _onSubmit() async {
    if (!_formKey.currentState!.validate()) return;
    await _save();
  }

  String _normalizePhone(String raw) {
    var s = raw.replaceAll(RegExp(r'\D'), ''); // keep digits
    if (s.startsWith('91') && s.length == 12) {
      s = s.substring(2);
    }
    if (s.startsWith('0') && s.length == 11) {
      s = s.substring(1);
    }
    return s;
  }

  Future<void> _save() async {
    if (_selectedBranchId == null) {
      _toast('Select a branch');
      return;
    }

    // At least one seat: from multi-list or currently selected
    if (_selectedSeats.isEmpty && _selectedSeatId == null) {
      _toast('Select at least one seat');
      return;
    }

    final seatsToBook = _selectedSeats.isNotEmpty
        ? _selectedSeats
        : [
            _SelectedSeat(
              seatId: _selectedSeatId!,
              seatLabel: _selectedSeatLabel ?? 'Seat',
              seatType: _selectedSeatTypeDisplay ?? '',
            )
          ];

    final normalizedPhone = _normalizePhone(_customerPhoneCtrl.text);
    if (normalizedPhone.isEmpty || normalizedPhone.length != 10) {
      _toast('Enter a valid 10-digit phone');
      return;
    }
    if (_customerNameCtrl.text.trim().isEmpty) {
      _toast('Enter customer name');
      return;
    }
    if (_paxCtrl.text.trim().isEmpty ||
        (int.tryParse(_paxCtrl.text.trim()) ?? 0) <= 0) {
      _toast('Enter number of people');
      return;
    }

    setState(() => _saving = true);

    try {
      final start = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );
      final end = start.add(Duration(minutes: _selectedDuration));
      final now = DateTime.now();
      final isFuture = start.isAfter(now);

      final fs = FirebaseFirestore.instance;
      final sessionsCol = fs
          .collection('branches')
          .doc(_selectedBranchId)
          .collection('sessions');
      final seatsCol = fs
          .collection('branches')
          .doc(_selectedBranchId)
          .collection('seats');

      // Preload seat state + overlap check for each seat
      final Map<String, Map<String, dynamic>> seatDataMap = {};
      final Map<String, String> seatStatusMap = {};

      for (final sel in seatsToBook) {
        final seatRef = seatsCol.doc(sel.seatId);

        // Load current seat state
        final seatSnap = await seatRef.get();
        final seatData = seatSnap.data() ?? {};
        final seatStatus = (seatData['status'] ?? 'free').toString();

        seatDataMap[sel.seatId] = seatData;
        seatStatusMap[sel.seatId] = seatStatus;

        // Overlap check for this seat
        final seatSessionsSnap =
            await sessionsCol.where('seatId', isEqualTo: sel.seatId).get();

        bool hasOverlap = false;
        for (final doc in seatSessionsSnap.docs) {
          final data = doc.data() as Map<String, dynamic>;
          final status = (data['status'] ?? '').toString();
          if (status != 'active' && status != 'reserved') continue;

          final otherStart = (data['startTime'] as Timestamp?)?.toDate();
          final otherDuration =
              (data['durationMinutes'] as num?)?.toInt() ?? 0;
          if (otherStart == null) continue;

          final otherEnd =
              otherStart.add(Duration(minutes: otherDuration));
          final overlaps =
              otherStart.isBefore(end) && otherEnd.isAfter(start);
          if (overlaps) {
            hasOverlap = true;
            break;
          }
        }

        if (hasOverlap) {
          setState(() => _saving = false);
          await _showBookingDeniedDialog();
          return;
        }
      }

      String? createdByName;
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        final userDoc =
            await fs.collection('users').doc(currentUser.uid).get();
        if (userDoc.exists) {
          createdByName =
              (userDoc.data()?['name'] as String?) ?? currentUser.email;
        }
      }

      final batch = fs.batch();

      for (final sel in seatsToBook) {
        final seatRef = seatsCol.doc(sel.seatId);
        final seatData = seatDataMap[sel.seatId] ?? {};
        final seatStatus = seatStatusMap[sel.seatId] ?? 'free';

        // Decide new seat status without corrupting currentSessionId for future reservations
        String newSeatStatus;
        bool setCurrentSessionOnSeat;
        if (isFuture) {
          newSeatStatus =
              (seatStatus == 'in-use') ? 'in-use' : 'reserved';
          setCurrentSessionOnSeat = false;
        } else {
          newSeatStatus = 'in-use';
          setCurrentSessionOnSeat = true;
        }

        final sessionRef = sessionsCol.doc();

        final payload = <String, dynamic>{
          'customerName': _customerNameCtrl.text.trim(),
          'customerPhone': normalizedPhone,
          'branchId': _selectedBranchId,
          'branchName': _selectedBranchName,
          'seatId': sel.seatId,
          'seatLabel': sel.seatLabel,
          'startTime': Timestamp.fromDate(start),
          'durationMinutes': _selectedDuration,
          'pax': int.tryParse(_paxCtrl.text.trim()),
          'gamePreference': _gamePrefCtrl.text.trim(),
          'paymentType': _paymentType,
          'status': isFuture ? 'reserved' : 'active',
          'paymentStatus': 'pending',
          'notes': _notesCtrl.text.trim(),
          // snapshot a few seat fields in case rate changes later
          'seatType': sel.seatType,
          'seatRatePerHour': seatData['ratePerHour'],
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
          if (currentUser != null) 'createdBy': currentUser.uid,
          if (createdByName != null) 'createdByName': createdByName,
        };

        batch.set(sessionRef, payload);
        batch.update(seatRef, {
          'status': newSeatStatus,
          'currentSessionId':
              setCurrentSessionOnSeat ? sessionRef.id : (seatData['currentSessionId'] ?? null),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }

      await batch.commit();

      if (!mounted) return;
      Navigator.of(context).pop(true);
      _toast(seatsToBook.length > 1
          ? 'Group booking created (${seatsToBook.length} seats)'
          : 'Booking created');
    } catch (e) {
      if (!mounted) return;
      _toast('Failed to create booking: $e');
      setState(() => _saving = false);
    }
  }
}

class _SelectedSeat {
  final String seatId;
  final String seatLabel;
  final String seatType;

  _SelectedSeat({
    required this.seatId,
    required this.seatLabel,
    required this.seatType,
  });
}
