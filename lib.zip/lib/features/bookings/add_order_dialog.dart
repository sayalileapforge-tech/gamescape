import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AddOrderDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;

  const AddOrderDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
  });

  @override
  State<AddOrderDialog> createState() => _AddOrderDialogState();
}

class _AddOrderDialogState extends State<AddOrderDialog> {
  String? _selectedItemId;
  String? _selectedItemName;
  num _selectedItemPrice = 0;
  int _qty = 1;
  bool _saving = false;

  @override
  Widget build(BuildContext context) {
    final inventoryCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('inventory')
        .where('active', isEqualTo: true);

    return Dialog(
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Add Order',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 12),
            StreamBuilder<QuerySnapshot>(
              stream: inventoryCol.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snapshot.data?.docs ?? [];
                return DropdownButtonFormField<String>(
                  value: _selectedItemId,
                  decoration: const InputDecoration(
                    labelText: 'Select item',
                    border: OutlineInputBorder(),
                  ),
                  items: docs.map((d) {
                    final name = d['name'] ?? '';
                    final price = d['price'] ?? 0;
                    final stock = d['stockQty'] ?? 0;
                    return DropdownMenuItem(
                      value: d.id,
                      child: Text('$name • ₹$price • Stock: $stock'),
                    );
                  }).toList(),
                  onChanged: (v) {
                    setState(() {
                      _selectedItemId = v;
                      final doc = docs.firstWhere((e) => e.id == v);
                      _selectedItemName = doc['name'] ?? '';
                      _selectedItemPrice = doc['price'] ?? 0;
                    });
                  },
                );
              },
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Text('Qty:'),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _qty > 1
                      ? () => setState(() => _qty--)
                      : null,
                  icon: const Icon(Icons.remove),
                ),
                Text(_qty.toString()),
                IconButton(
                  onPressed: () => setState(() => _qty++),
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 40,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const CircularProgressIndicator()
                    : const Text('Add to booking'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_selectedItemId == null) return;
    setState(() => _saving = true);

    final orderCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('orders');

    final inventoryDoc = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('inventory')
        .doc(_selectedItemId);

    // write order + decrement stock
    await FirebaseFirestore.instance.runTransaction((tx) async {
      // create order
      tx.set(orderCol.doc(), {
        'itemId': _selectedItemId,
        'itemName': _selectedItemName,
        'qty': _qty,
        'price': _selectedItemPrice,
        'total': _selectedItemPrice * _qty,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // decrement stock
      final invSnap = await tx.get(inventoryDoc);
      final currentStock = (invSnap.data()?['stockQty'] ?? 0) as num;
      tx.update(inventoryDoc, {
        'stockQty': currentStock - _qty,
      });
    });

    if (mounted) Navigator.of(context).pop();
  }
}
