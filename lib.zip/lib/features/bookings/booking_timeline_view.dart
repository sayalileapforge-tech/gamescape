import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class BookingTimelineView extends StatelessWidget {
  final List<QueryDocumentSnapshot> bookings;
  const BookingTimelineView({super.key, required this.bookings});

  @override
  Widget build(BuildContext context) {
    // group by seat
    final Map<String, List<Map<String, dynamic>>> bySeat = {};
    for (final doc in bookings) {
      final data = doc.data() as Map<String, dynamic>;
      final seat = data['seatLabel'] ?? 'Unknown';
      bySeat.putIfAbsent(seat, () => []);
      bySeat[seat]!.add({
        'customerName': data['customerName'] ?? '',
        'startTime': (data['startTime'] as Timestamp?)?.toDate(),
        'durationMinutes': data['durationMinutes'] ?? 0,
      });
    }

    return ListView(
      children: bySeat.entries.map((entry) {
        final seat = entry.key;
        final list = entry.value;

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                seat,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: list.map((b) {
                    final dt = b['startTime'] as DateTime?;
                    final dur = b['durationMinutes'] as int;
                    return Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(b['customerName'] as String),
                          if (dt != null)
                            Text(
                              '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')} (${dur}m)',
                              style: TextStyle(
                                color: Colors.grey.shade600,
                                fontSize: 12,
                              ),
                            ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
