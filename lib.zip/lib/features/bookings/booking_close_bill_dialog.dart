import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class BookingCloseBillDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingCloseBillDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingCloseBillDialog> createState() => _BookingCloseBillDialogState();
}

class _BookingCloseBillDialogState extends State<BookingCloseBillDialog> {
  bool _loading = true;
  num _ordersTotal = 0;
  num _sessionTotal = 0;
  num _grandTotal = 0;

  @override
  void initState() {
    super.initState();
    _loadBill();
  }

  Future<void> _loadBill() async {
    final sessionData = widget.data;
    final branchId = widget.branchId;
    final seatId = sessionData['seatId'] as String?;
    final startTime = (sessionData['startTime'] as Timestamp?)?.toDate();

    // 1. orders total
    final ordersSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('orders')
        .get();

    num ordersTotal = 0;
    for (final doc in ordersSnap.docs) {
      final d = doc.data();
      ordersTotal += (d['total'] ?? 0) as num;
    }

    // 2. session total
    num sessionTotal = 0;
    if (seatId != null && startTime != null) {
      final seatSnap = await FirebaseFirestore.instance
          .collection('branches')
          .doc(branchId)
          .collection('seats')
          .doc(seatId)
          .get();
      final seatData = seatSnap.data();
      final rate = (seatData?['ratePerHour'] ?? 0) as num;
      final elapsedMinutes =
          DateTime.now().difference(startTime).inMinutes.clamp(1, 9999);
      sessionTotal = rate * (elapsedMinutes / 60);
    }

    setState(() {
      _ordersTotal = ordersTotal;
      _sessionTotal = sessionTotal;
      _grandTotal = ordersTotal + sessionTotal;
      _loading = false;
    });
  }

  Future<void> _closeSession() async {
    await FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .update({
      'status': 'completed',
      'closedAt': FieldValue.serverTimestamp(),
      'billAmount': _grandTotal,
    });
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: _loading
            ? const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Close & Bill',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text('Session total: ₹${_sessionTotal.toStringAsFixed(2)}'),
                  Text('Orders total: ₹${_ordersTotal.toStringAsFixed(2)}'),
                  const Divider(),
                  Text(
                    'Grand total: ₹${_grandTotal.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _closeSession,
                      child: const Text('Close session'),
                    ),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                ],
              ),
      ),
    );
  }
}
