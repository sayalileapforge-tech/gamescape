import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'add_order_dialog.dart';
import 'booking_move_seat_dialog.dart';
import 'booking_close_bill_dialog.dart';

class BookingActionsDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingActionsDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingActionsDialog> createState() => _BookingActionsDialogState();
}

class _BookingActionsDialogState extends State<BookingActionsDialog> {
  bool _extending = false;

  Future<void> _extendBy(int minutes) async {
    setState(() => _extending = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      final current = snap.data() as Map<String, dynamic>;
      final currentDuration = (current['durationMinutes'] ?? 0) as int;
      tx.update(docRef, {
        'durationMinutes': currentDuration + minutes,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });

    if (mounted) {
      setState(() => _extending = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Extended by $minutes minutes')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cust = widget.data['customerName'] ?? '';
    final seatId = widget.data['seatId'] ?? '';
    final seat = widget.data['seatLabel'] ?? '';
    final duration = widget.data['durationMinutes'] ?? 0;

    return Dialog(
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Booking Actions',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 10),
            Text('Customer: $cust'),
            Text('Seat: $seat'),
            Text('Duration: $duration mins'),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _extending ? null : () => _extendBy(30),
              icon: const Icon(Icons.add_alarm),
              label: _extending
                  ? const Text('Extending...')
                  : const Text('Extend by 30 mins'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => AddOrderDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                  ),
                );
              },
              icon: const Icon(Icons.add_shopping_cart_outlined),
              label: const Text('Add Order'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => BookingMoveSeatDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    currentSeatId: seatId,
                  ),
                );
              },
              icon: const Icon(Icons.chair_outlined),
              label: const Text('Move Seat'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    data: widget.data,
                  ),
                );
              },
              icon: const Icon(Icons.payments_outlined),
              label: const Text('Close & Bill'),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }
}
