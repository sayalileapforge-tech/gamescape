import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SideNav extends StatefulWidget {
  const SideNav({super.key});

  @override
  State<SideNav> createState() => _SideNavState();
}

class _SideNavState extends State<SideNav> with SingleTickerProviderStateMixin {
  bool _isExpanded = false;

  void _toggleExpanded() {
    setState(() => _isExpanded = !_isExpanded);
  }

  @override
  Widget build(BuildContext context) {
    final width = _isExpanded ? 200.0 : 70.0;

    return AnimatedContainer(
      width: width,
      duration: const Duration(milliseconds: 250),
      color: Colors.black,
      child: Column(
        children: [
          const SizedBox(height: 16),
          // Logo
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            alignment: Alignment.center,
            child: const Text(
              'G',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
          ),
          const SizedBox(height: 30),

          // Nav items
          _NavTile(
            icon: Icons.dashboard_outlined,
            label: 'Dashboard',
            expanded: _isExpanded,
            onTap: () => context.go('/dashboard'),
          ),
          _NavTile(
            icon: Icons.home_work_outlined,
            label: 'Branches',
            expanded: _isExpanded,
            onTap: () => context.go('/branches'),
          ),
          _NavTile(
            icon: Icons.chair_outlined,
            label: 'Bookings',
            expanded: _isExpanded,
            onTap: () => context.go('/bookings'),
          ),
          _NavTile(
            icon: Icons.inventory_2_outlined,
            label: 'Inventory',
            expanded: _isExpanded,
            onTap: () => context.go('/inventory'),
          ),
          _NavTile(
            icon: Icons.receipt_long_outlined,
            label: 'Reports',
            expanded: _isExpanded,
            onTap: () {}, // placeholder for later
          ),
          const Spacer(),

          // Collapse / expand toggle
          InkWell(
            onTap: _toggleExpanded,
            child: Container(
              margin: const EdgeInsets.only(bottom: 20),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.grey.shade900,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: _isExpanded
                    ? MainAxisAlignment.start
                    : MainAxisAlignment.center,
                children: [
                  Icon(
                    _isExpanded
                        ? Icons.arrow_back_ios_new_rounded
                        : Icons.arrow_forward_ios_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                  if (_isExpanded)
                    const SizedBox(width: 8),
                  if (_isExpanded)
                    const Text(
                      'Collapse',
                      style: TextStyle(color: Colors.white),
                    ),
                ],
              ),
            ),
          ),

          // Logout
          _NavTile(
            icon: Icons.logout,
            label: 'Logout',
            expanded: _isExpanded,
            onTap: () => context.go('/login'),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool expanded;

  const _NavTile({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.expanded,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment:
              expanded ? MainAxisAlignment.start : MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            if (expanded) const SizedBox(width: 10),
            if (expanded)
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
