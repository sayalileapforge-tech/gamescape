import 'package:cloud_firestore/cloud_firestore.dart';

class BookingModel {
  final String id;
  final String customerName;
  final String? customerPhone;
  final String branchId;
  final String branchName;
  final String seatId;
  final String seatLabel;
  final DateTime startTime;
  final String status; // active, completed, moved, cancelled
  final String? notes;

  // Additive metadata for richer logic
  final String? seatType;
  final String? paymentType;
  final int? durationMinutes;
  final String? createdBy;
  final String? createdByName;

  BookingModel({
    required this.id,
    required this.customerName,
    this.customerPhone,
    required this.branchId,
    required this.branchName,
    required this.seatId,
    required this.seatLabel,
    required this.startTime,
    required this.status,
    this.notes,
    this.seatType,
    this.paymentType,
    this.durationMinutes,
    this.createdBy,
    this.createdByName,
  });

  factory BookingModel.fromMap(String id, Map<String, dynamic> data) {
    return BookingModel(
      id: id,
      customerName: data['customerName'] ?? '',
      customerPhone: data['customerPhone'],
      branchId: data['branchId'] ?? '',
      branchName: data['branchName'] ?? '',
      seatId: data['seatId'] ?? '',
      seatLabel: data['seatLabel'] ?? '',
      startTime: (data['startTime'] as Timestamp).toDate(),
      status: data['status'] ?? 'active',
      notes: data['notes'],
      seatType: data['seatType'],
      paymentType: data['paymentType'],
      durationMinutes: (data['durationMinutes'] as num?)?.toInt(),
      createdBy: data['createdBy'],
      createdByName: data['createdByName'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'customerName': customerName,
      'customerPhone': customerPhone,
      'branchId': branchId,
      'branchName': branchName,
      'seatId': seatId,
      'seatLabel': seatLabel,
      'startTime': startTime,
      'status': status,
      'notes': notes,
      if (seatType != null) 'seatType': seatType,
      if (paymentType != null) 'paymentType': paymentType,
      if (durationMinutes != null) 'durationMinutes': durationMinutes,
      if (createdBy != null) 'createdBy': createdBy,
      if (createdByName != null) 'createdByName': createdByName,
    };
  }
}
