import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import 'add_booking_dialog.dart';
import 'booking_actions_dialog.dart';
import 'booking_timeline_view.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  String? _selectedBranchId;
  String? _selectedBranchName;
  bool _showTimeline = false;
  String _statusFilter = 'all'; // default all
  bool _hideOverdue = false;
  int _upcomingWindowMins = 0; // 0 = off

  @override
  Widget build(BuildContext context) {
    final branchesCol = FirebaseFirestore.instance.collection('branches');

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header + filters
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Bookings',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
              ),
              Row(
                children: [
                  DropdownButton<String>(
                    value: _statusFilter,
                    dropdownColor: const Color(0xFF111827),
                    style: const TextStyle(color: Colors.white),
                    items: const [
                      DropdownMenuItem(value: 'all', child: Text('All')),
                      DropdownMenuItem(value: 'active', child: Text('Active')),
                      DropdownMenuItem(
                          value: 'completed', child: Text('Completed')),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() => _statusFilter = v);
                    },
                  ),
                  const SizedBox(width: 12),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(
                        value: false,
                        label: Text('Table'),
                        icon: Icon(Icons.table_chart),
                      ),
                      ButtonSegment(
                        value: true,
                        label: Text('Timeline'),
                        icon: Icon(Icons.timeline),
                      ),
                    ],
                    selected: {_showTimeline},
                    onSelectionChanged: (s) {
                      setState(() {
                        _showTimeline = s.first;
                      });
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          // branch & new booking
          Row(
            children: [
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: branchesCol.snapshots(),
                  builder: (context, snapshot) {
                    final items = snapshot.hasData
                        ? snapshot.data!.docs
                        : <QueryDocumentSnapshot>[];
                    return DropdownButtonFormField<String>(
                      value: _selectedBranchId,
                      dropdownColor: const Color(0xFF111827),
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        labelText: 'Select branch',
                        border: OutlineInputBorder(),
                        labelStyle: TextStyle(color: Colors.white70),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white38),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      items: items.map((d) {
                        return DropdownMenuItem(
                          value: d.id,
                          child: Text(d['name'] ?? 'Branch'),
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          _selectedBranchId = v;
                          if (v != null) {
                            final doc = items.firstWhere((e) => e.id == v);
                            _selectedBranchName = doc['name'] ?? '';
                          } else {
                            _selectedBranchName = null;
                          }
                        });
                      },
                    );
                  },
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (_) => const AddBookingDialog(),
                  );
                },
                icon: const Icon(Icons.add),
                label: const Text('New Booking'),
              ),
              const SizedBox(width: 12),
              Row(
                children: [
                  const Text('Hide overdue',
                      style: TextStyle(color: Colors.white70)),
                  Switch(
                    value: _hideOverdue,
                    onChanged: (v) {
                      setState(() => _hideOverdue = v);
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          // upcoming chips
          Row(
            children: [
              const Text('Upcoming:',
                  style: TextStyle(color: Colors.white70)),
              const SizedBox(width: 8),
              _UpcomingChip(
                label: 'Off',
                selected: _upcomingWindowMins == 0,
                onTap: () => setState(() => _upcomingWindowMins = 0),
              ),
              _UpcomingChip(
                label: 'Next 60m',
                selected: _upcomingWindowMins == 60,
                onTap: () => setState(() => _upcomingWindowMins = 60),
              ),
              _UpcomingChip(
                label: 'Next 120m',
                selected: _upcomingWindowMins == 120,
                onTap: () => setState(() => _upcomingWindowMins = 120),
              ),
              _UpcomingChip(
                label: 'Next 180m',
                selected: _upcomingWindowMins == 180,
                onTap: () => setState(() => _upcomingWindowMins = 180),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // main body
          Expanded(
            child: _selectedBranchId == null
                ? const Center(
                    child: Text(
                      'Select a branch to view bookings',
                      style: TextStyle(color: Colors.white70),
                    ),
                  )
                : StreamBuilder<QuerySnapshot>(
                    stream: _buildSessionsStream(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Center(
                            child: CircularProgressIndicator());
                      }
                      if (!snapshot.hasData ||
                          snapshot.data!.docs.isEmpty) {
                        return const Center(
                          child: Text(
                            'No bookings found.',
                            style: TextStyle(color: Colors.white70),
                          ),
                        );
                      }

                      final docs = snapshot.data!.docs.toList();

                      // extra upcoming filter (client-side)
                      final filteredDocs = docs.where((d) {
                        if (_upcomingWindowMins == 0) return true;
                        final data = d.data() as Map<String, dynamic>;
                        final status = data['status']?.toString() ?? 'active';
                        if (status != 'reserved') return true;
                        final startTs = data['startTime'] as Timestamp?;
                        if (startTs == null) return false;
                        final start = startTs.toDate();
                        final now = DateTime.now();
                        final limit =
                            now.add(Duration(minutes: _upcomingWindowMins));
                        return start.isAfter(now) && start.isBefore(limit);
                      }).toList();

                      if (_showTimeline) {
                        return BookingTimelineView(bookings: filteredDocs);
                      }

                      // tabular list
                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: 1100,
                          child: ListView.separated(
                            shrinkWrap: true,
                            itemCount: filteredDocs.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              final d = filteredDocs[index];
                              final data =
                                  d.data() as Map<String, dynamic>? ?? {};
                              final seatLabel =
                                  data['seatLabel']?.toString() ?? '';
                              final cust =
                                  data['customerName']?.toString() ?? '';
                              final started =
                                  (data['startTime'] as Timestamp?)
                                      ?.toDate();
                              final durationMins =
                                  (data['durationMinutes'] ?? 0) as int;
                              final status =
                                  data['status']?.toString() ?? 'active';
                              final paymentType =
                                  (data['paymentType'] ?? 'postpaid')
                                      .toString();

                              bool isOverdue = false;
                              if (status == 'active' && started != null) {
                                final end = started
                                    .add(Duration(minutes: durationMins));
                                isOverdue = DateTime.now().isAfter(end);
                              }
                              if (_hideOverdue && isOverdue) {
                                return const SizedBox.shrink();
                              }

                              final startStr = started != null
                                  ? '${started.hour.toString().padLeft(2, '0')}:${started.minute.toString().padLeft(2, '0')}'
                                  : '—';

                              return Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1F2937),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  children: [
                                    _Cell(
                                      width: 70,
                                      child: Text(
                                        '#${index + 1}',
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                    ),
                                    _Cell(
                                      width: 180,
                                      child: Text(
                                        cust,
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                    ),
                                    _Cell(
                                      width: 120,
                                      child: Text(
                                        seatLabel,
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                    ),
                                    _Cell(
                                      width: 140,
                                      child: Text(
                                        startStr,
                                        style: const TextStyle(
                                            color: Colors.white70),
                                      ),
                                    ),
                                    _Cell(
                                      width: 140,
                                      child: status == 'reserved'
                                          ? const Text(
                                              'Yet to start',
                                              style: TextStyle(
                                                color: Colors.orangeAccent,
                                              ),
                                            )
                                          : status == 'active' &&
                                                  started != null
                                              ? BookingCountdown(
                                                  endTime: started.add(
                                                    Duration(
                                                        minutes: durationMins),
                                                  ),
                                                )
                                              : Text(
                                                  status,
                                                  style: const TextStyle(
                                                      color: Colors.white70),
                                                ),
                                    ),
                                    _Cell(
                                      width: 110,
                                      child: _PaymentChip(
                                          paymentType: paymentType),
                                    ),
                                    _Cell(
                                      width: 110,
                                      child: _StatusChip(status: status),
                                    ),
                                    _Cell(
                                      width: 140,
                                      child: Builder(
                                        builder: (context) {
                                          if (status == 'completed') {
                                            return const Text(
                                              '—',
                                              style: TextStyle(
                                                  color: Colors.white38),
                                            );
                                          }
                                          if (status == 'reserved') {
                                            return Row(
                                              children: [
                                                IconButton(
                                                  tooltip: 'Start now',
                                                  onPressed: () async {
                                                    await FirebaseFirestore
                                                        .instance
                                                        .collection('branches')
                                                        .doc(_selectedBranchId!)
                                                        .collection('sessions')
                                                        .doc(d.id)
                                                        .update({
                                                      'status': 'active',
                                                      'startTime':
                                                          Timestamp.fromDate(
                                                              DateTime.now()),
                                                    });
                                                  },
                                                  icon: const Icon(
                                                    Icons.play_arrow,
                                                    color: Colors.greenAccent,
                                                  ),
                                                ),
                                                IconButton(
                                                  tooltip: 'Cancel booking',
                                                  onPressed: () async {
                                                    await FirebaseFirestore
                                                        .instance
                                                        .collection('branches')
                                                        .doc(_selectedBranchId!)
                                                        .collection('sessions')
                                                        .doc(d.id)
                                                        .update({
                                                      'status': 'cancelled',
                                                    });
                                                  },
                                                  icon: const Icon(
                                                    Icons.close,
                                                    color: Colors.redAccent,
                                                  ),
                                                ),
                                              ],
                                            );
                                          }
                                          return ElevatedButton(
                                            onPressed: () {
                                              showDialog(
                                                context: context,
                                                builder: (_) =>
                                                    BookingActionsDialog(
                                                  branchId:
                                                      _selectedBranchId!,
                                                  sessionId: d.id,
                                                  data: data,
                                                ),
                                              );
                                            },
                                            child: const Text('Actions'),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Stream<QuerySnapshot> _buildSessionsStream() {
    Query q = FirebaseFirestore.instance
        .collection('branches')
        .doc(_selectedBranchId)
        .collection('sessions')
        .orderBy('startTime', descending: false);

    if (_statusFilter == 'active') {
      q = q.where('status', isEqualTo: 'active');
    } else if (_statusFilter == 'completed') {
      q = q.where('status', isEqualTo: 'completed');
    }
    return q.snapshots();
  }
}

class _Cell extends StatelessWidget {
  final double width;
  final Widget child;
  const _Cell({required this.width, required this.child});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6.0),
        child: child,
      ),
    );
  }
}

class _UpcomingChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _UpcomingChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 6.0),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: Colors.white24),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.black : Colors.white,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}

class _PaymentChip extends StatelessWidget {
  final String paymentType;
  const _PaymentChip({required this.paymentType});

  @override
  Widget build(BuildContext context) {
    Color bg;
    String label;
    if (paymentType == 'prepaid') {
      bg = Colors.blueAccent.withOpacity(0.2);
      label = 'Prepaid';
    } else {
      bg = Colors.greenAccent.withOpacity(0.2);
      label = 'Postpaid';
    }
    return Container(
      margin: const EdgeInsets.only(left: 0),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, fontSize: 11),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color bg = Colors.white12;
    String label = status;

    if (status == 'cancelled' || status == 'canceled') {
      bg = Colors.red.withOpacity(0.2);
      label = 'Cancelled';
    } else if (status == 'completed') {
      bg = Colors.grey.withOpacity(0.2);
      label = 'Completed';
    } else if (status == 'reserved') {
      bg = Colors.orange.withOpacity(0.2);
      label = 'Reserved';
    }

    return Container(
      margin: const EdgeInsets.only(left: 0),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, fontSize: 11),
      ),
    );
  }
}

class BookingCountdown extends StatefulWidget {
  final DateTime endTime;
  const BookingCountdown({super.key, required this.endTime});

  @override
  State<BookingCountdown> createState() => _BookingCountdownState();
}

class _BookingCountdownState extends State<BookingCountdown> {
  late Timer _timer;
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _remaining =
        widget.endTime.difference(DateTime.now()) + const Duration(seconds: 59);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      final diff = widget.endTime.difference(DateTime.now());
      if (diff.isNegative) {
        t.cancel();
      }
      if (mounted) {
        setState(() => _remaining = diff);
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _fmt(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final total = _remaining.isNegative ? Duration.zero : _remaining;
    final h = total.inHours;
    final m = total.inMinutes.remainder(60);
    final s = total.inSeconds.remainder(60);

    return Text(
      'Time left: ${_fmt(h)}:${_fmt(m)}:${_fmt(s)}',
      style: TextStyle(
        color: total.inMinutes < 5 ? Colors.redAccent : Colors.greenAccent,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}
