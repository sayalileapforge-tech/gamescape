import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../core/widgets/app_shell.dart';

class UserManagementScreen extends StatelessWidget {
  const UserManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'User Management',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () async {
                final created = await showDialog<bool>(
                  context: context,
                  builder: (_) => const _CreateUserDialog(),
                );
                if (created == true && context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('User created')),
                  );
                }
              },
              icon: const Icon(Icons.person_add, color: Colors.white),
              label: const Text(
                'Create User',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance.collection('users').snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snap.data!.docs;
                return ListView.separated(
                  itemCount: docs.length,
                  separatorBuilder: (_, __) =>
                      const Divider(color: Colors.white12),
                  itemBuilder: (context, index) {
                    final d = docs[index];
                    final data = d.data() as Map<String, dynamic>? ?? {};
                    final name = data['name']?.toString() ?? 'User';
                    final email = data['email']?.toString() ?? '';
                    final role = data['role']?.toString() ?? 'staff';
                    final branches =
                        (data['branchIds'] as List?)?.cast<String>() ?? [];

                    return ListTile(
                      title: Text(name,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                        '$email • $role • ${branches.join(', ')}',
                        style: TextStyle(color: Colors.grey.shade400),
                      ),
                      trailing: (currentUser != null &&
                              d.id == currentUser.uid)
                          ? const Text(
                              'You',
                              style: TextStyle(color: Colors.white54),
                            )
                          : null,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _CreateUserDialog extends StatefulWidget {
  const _CreateUserDialog();

  @override
  State<_CreateUserDialog> createState() => _CreateUserDialogState();
}

class _CreateUserDialogState extends State<_CreateUserDialog> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  String _role = 'staff';
  final List<String> _selectedBranches = [];
  bool _saving = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Create Console User',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _nameCtrl,
                decoration: _darkInput('Name'),
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _emailCtrl,
                decoration: _darkInput('Email'),
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _role,
                dropdownColor: const Color(0xFF111827),
                decoration: _darkInput('Role'),
                style: const TextStyle(color: Colors.white),
                items: const [
                  DropdownMenuItem(value: 'staff', child: Text('Staff')),
                  DropdownMenuItem(value: 'manager', child: Text('Manager')),
                  DropdownMenuItem(value: 'admin', child: Text('Admin')),
                  DropdownMenuItem(
                      value: 'superadmin', child: Text('Super Admin')),
                ],
                onChanged: (v) {
                  if (v != null) {
                    setState(() => _role = v);
                  }
                },
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerLeft,
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('branches')
                      .snapshots(),
                  builder: (context, snap) {
                    if (!snap.hasData) {
                      return const SizedBox.shrink();
                    }
                    final branches = snap.data!.docs;
                    return Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: branches.map((b) {
                        final id = b.id;
                        final name =
                            (b.data() as Map<String, dynamic>? ?? {})['name']
                                    ?.toString() ??
                                id;
                        final selected = _selectedBranches.contains(id);
                        return FilterChip(
                          selected: selected,
                          label: Text(
                            name,
                            style: TextStyle(
                              color: selected ? Colors.black : Colors.white,
                            ),
                          ),
                          selectedColor: Colors.white,
                          backgroundColor: const Color(0xFF0F172A),
                          onSelected: (v) {
                            setState(() {
                              if (v) {
                                _selectedBranches.add(id);
                              } else {
                                _selectedBranches.remove(id);
                              }
                            });
                          },
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.redAccent),
                  ),
                ),
              SizedBox(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  onPressed: _saving ? null : _create,
                  child: _saving
                      ? const CircularProgressIndicator()
                      : const Text('Create User'),
                ),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _darkInput(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      border: const OutlineInputBorder(),
      enabledBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white24),
      ),
      focusedBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
    );
  }

  Future<void> _create() async {
    final name = _nameCtrl.text.trim();
    final email = _emailCtrl.text.trim();
    if (name.isEmpty || email.isEmpty) {
      setState(() => _error = 'Name and Email are required');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      // try cloud function first
      final callable =
          FirebaseFunctions.instance.httpsCallable('createConsoleUser');
      await callable.call({
        'name': name,
        'email': email,
        'role': _role,
        'branchIds': _selectedBranches,
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      // fallback: just create the firestore doc so UI doesn’t break
      try {
        final usersCol = FirebaseFirestore.instance.collection('users');
        await usersCol.add({
          'name': name,
          'email': email,
          'role': _role,
          'branchIds': _selectedBranches,
          'mustChangePassword': true,
          'createdAt': FieldValue.serverTimestamp(),
        });
        if (mounted) Navigator.of(context).pop(true);
      } catch (e2) {
        if (mounted) {
          setState(() => _error = 'Failed to create user: $e2');
        }
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }
}
