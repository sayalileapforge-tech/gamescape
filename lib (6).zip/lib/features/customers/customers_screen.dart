import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});

  @override
  State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  String _search = '';
  String _filter = 'all'; // all | high | frequent

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Customers',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    hintText: 'Search by name or phone',
                    hintStyle: TextStyle(color: Colors.white54),
                    prefixIcon: Icon(Icons.search, color: Colors.white54),
                    border: OutlineInputBorder(),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white24),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                    ),
                  ),
                  style: const TextStyle(color: Colors.white),
                  onChanged: (v) =>
                      setState(() => _search = v.trim().toLowerCase()),
                ),
              ),
              const SizedBox(width: 12),
              _CustomerFilterChip(
                label: 'All',
                selected: _filter == 'all',
                onTap: () => setState(() => _filter = 'all'),
              ),
              const SizedBox(width: 6),
              _CustomerFilterChip(
                label: 'High spender',
                selected: _filter == 'high',
                onTap: () => setState(() => _filter = 'high'),
              ),
              const SizedBox(width: 6),
              _CustomerFilterChip(
                label: 'Frequent',
                selected: _filter == 'frequent',
                onTap: () => setState(() => _filter = 'frequent'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collectionGroup('sessions')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Colors.white),
                  );
                }
                final docs = snapshot.data?.docs ?? [];

                final Map<String, _CustomerAgg> customers = {};

                for (final d in docs) {
                  final data = d.data() as Map<String, dynamic>? ?? {};
                  final phone = (data['customerPhone'] ?? '').toString().trim();
                  final name = (data['customerName'] ?? '').toString().trim();
                  final billAmount = (data['billAmount'] ?? 0) as num;
                  final status = data['status']?.toString() ?? '';
                  final key = phone.isNotEmpty ? 'phone:$phone' : 'name:$name';

                  if (key.trim().isEmpty) continue;

                  customers.putIfAbsent(
                    key,
                    () => _CustomerAgg(
                      name: name.isNotEmpty ? name : 'Walk-in',
                      phone: phone,
                      visits: 0,
                      totalSpend: 0,
                      sessions: [],
                    ),
                  );

                  final agg = customers[key]!;
                  agg.visits += 1;
                  if (status == 'completed') {
                    agg.totalSpend += billAmount;
                  }
                  agg.sessions.add(_CustomerSession(
                    id: d.id,
                    branchName: data['branchName']?.toString() ?? '-',
                    seatLabel: data['seatLabel']?.toString() ?? '-',
                    status: status,
                    billAmount: billAmount,
                    startTime: (data['startTime'] as Timestamp?)?.toDate(),
                  ));
                }

                var list = customers.values.toList();

                if (_search.isNotEmpty) {
                  list = list.where((c) {
                    return c.name.toLowerCase().contains(_search) ||
                        c.phone.toLowerCase().contains(_search);
                  }).toList();
                }

                if (_filter == 'high') {
                  list = list.where((c) => c.totalSpend >= 5000).toList();
                } else if (_filter == 'frequent') {
                  list = list.where((c) => c.visits >= 5).toList();
                }

                list.sort((a, b) => b.totalSpend.compareTo(a.totalSpend));

                if (list.isEmpty) {
                  return const Center(
                    child: Text(
                      'No customers found.',
                      style: TextStyle(color: Colors.white70),
                    ),
                  );
                }

                return ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final c = list[index];
                    return InkWell(
                      onTap: () => _showCustomerDetail(context, c),
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1F2937),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.white12,
                              child: Text(
                                c.name.isNotEmpty
                                    ? c.name[0].toUpperCase()
                                    : 'C',
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    c.name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  Text(
                                    c.phone.isNotEmpty ? c.phone : 'No phone',
                                    style: const TextStyle(
                                      color: Colors.white54,
                                      fontSize: 12,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '${c.visits} visits • ₹${c.totalSpend.toStringAsFixed(2)} total',
                                    style: const TextStyle(
                                      color: Colors.white60,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right,
                                color: Colors.white),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showCustomerDetail(BuildContext context, _CustomerAgg c) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      isScrollControlled: true,
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 4,
                  width: 50,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                Text(
                  c.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
                Text(
                  c.phone.isNotEmpty ? c.phone : 'No phone',
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
                const SizedBox(height: 14),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Visit history',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 280,
                  child: ListView.builder(
                    itemCount: c.sessions.length,
                    itemBuilder: (context, i) {
                      final s = c.sessions[i];
                      return ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          '${s.branchName} • ${s.seatLabel}',
                          style: const TextStyle(color: Colors.white),
                        ),
                        subtitle: Text(
                          '${s.status} • ${s.startTime != null ? s.startTime.toString() : ''}',
                          style: const TextStyle(
                              color: Colors.white54, fontSize: 12),
                        ),
                        trailing: Text(
                          s.billAmount > 0 ? '₹${s.billAmount}' : '',
                          style: const TextStyle(
                              color: Colors.greenAccent,
                              fontWeight: FontWeight.w600),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CustomerFilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _CustomerFilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.white24),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}

class _CustomerAgg {
  final String name;
  final String phone;
  int visits;
  num totalSpend;
  final List<_CustomerSession> sessions;

  _CustomerAgg({
    required this.name,
    required this.phone,
    required this.visits,
    required this.totalSpend,
    required this.sessions,
  });
}

class _CustomerSession {
  final String id;
  final String branchName;
  final String seatLabel;
  final String status;
  final num billAmount;
  final DateTime? startTime;

  _CustomerSession({
    required this.id,
    required this.branchName,
    required this.seatLabel,
    required this.status,
    required this.billAmount,
    required this.startTime,
  });
}
