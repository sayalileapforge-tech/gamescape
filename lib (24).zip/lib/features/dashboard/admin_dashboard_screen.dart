// FULL FILE: lib/features/dashboard/admin_dashboard_screen.dart
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/app_shell.dart';
import '../bookings/add_booking_dialog.dart';
import '../bookings/booking_actions_dialog.dart';
import '../bookings/booking_close_bill_dialog.dart';
import '../bookings/booking_timeline_view.dart';

// ───────────────────────── Time helpers ─────────────────────────
DateTime _startOfDayLocal(DateTime now) => DateTime(now.year, now.month, now.day);
DateTime _endOfDayLocal(DateTime now) => _startOfDayLocal(now).add(const Duration(days: 1));

class _DayRangeUtc {
  final Timestamp startUtc;
  final Timestamp endUtc;
  const _DayRangeUtc(this.startUtc, this.endUtc);
}

_DayRangeUtc _todayIstToUtc() {
  final nowLocal = DateTime.now();
  final startLocal = DateTime(nowLocal.year, nowLocal.month, nowLocal.day);
  final endLocal = startLocal.add(const Duration(days: 1));
  return _DayRangeUtc(
    Timestamp.fromDate(startLocal.toUtc()),
    Timestamp.fromDate(endLocal.toUtc()),
  );
}

DateTime? _endFrom(Map<String, dynamic> m) {
  final ts = (m['startTime'] as Timestamp?)?.toDate();
  final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
  if (ts == null) return null;
  return ts.add(Duration(minutes: dur));
}

String _statusOf(Map<String, dynamic> m) => ((m['status'] as String?) ?? '').toLowerCase();
bool _isCancelled(Map<String, dynamic> m) => _statusOf(m) == 'cancelled';
bool _isCompleted(Map<String, dynamic> m) => _statusOf(m) == 'completed';

bool _isActiveNow(Map<String, dynamic> m, DateTime now) {
  if (_isCancelled(m) || _isCompleted(m)) return false;
  final start = (m['startTime'] as Timestamp?)?.toDate();
  final end = _endFrom(m);
  if (start == null || end == null) return false;
  return start.isBefore(now) && end.isAfter(now);
}

bool _isOverdueNow(Map<String, dynamic> m, DateTime now) {
  if (_isCancelled(m) || _isCompleted(m)) return false;
  final end = _endFrom(m);
  if (end == null) return false;
  return now.isAfter(end);
}

// ───────────────────────── Invoice helpers ─────────────────────────
double _readInvoiceAmount(Map<String, dynamic> m) {
  final v = m['grandTotal'] ?? m['total'] ?? m['amount'] ?? m['billAmount'] ?? 0;
  if (v is int) return v.toDouble();
  if (v is double) return v;
  if (v is num) return v.toDouble();
  return 0.0;
}

String _readPaymentStatus(Map<String, dynamic> m) {
  final s = (m['paymentStatus'] ?? m['status'] ?? '').toString().toLowerCase();
  return s; // expect 'paid' or 'pending'
}

Timestamp? _readInvoiceDateForQuery(Map<String, dynamic> m) {
  return (m['createdAt'] as Timestamp?) ??
      (m['issuedAt'] as Timestamp?) ??
      (m['closedAt'] as Timestamp?);
}

bool _isInTodayUtcWindow(Map<String, dynamic> m, _DayRangeUtc range) {
  final t = _readInvoiceDateForQuery(m);
  if (t == null) return false;
  final d = t.toDate().toUtc();
  return !d.isBefore(range.startUtc.toDate()) && d.isBefore(range.endUtc.toDate());
}

// ───────────────────────── Dashboard Screen ─────────────────────────

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});
  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  String? _selectedBranchId;

  // Right drawer (notifications) open/close
  bool _notifOpen = false;

  // “ending soon” watcher state
  final Set<String> _endingSoonAlerted = <String>{};
  bool _endingSoonDialogOpen = false;
  StreamSubscription<QuerySnapshot>? _endingSoonSub;

  @override
  void dispose() {
    _endingSoonSub?.cancel();
    super.dispose();
  }

  void _attachEndingSoonWatcher({required String branchId}) {
    _endingSoonSub?.cancel();

    // Watch active sessions that end in the next 10 minutes.
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    _endingSoonSub = col.snapshots().listen((snap) async {
      if (!mounted) return;
      final docs = snap.docs;

      for (final d in docs) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] ?? '').toString().toLowerCase();
        if (status != 'active') continue;

        final start = (m['startTime'] as Timestamp?)?.toDate();
        final dur = (m['durationMinutes'] as num?)?.toInt() ?? 0;
        if (start == null) continue;
        final endAt = start.add(Duration(minutes: dur));

        final now = DateTime.now();
        final timeLeft = endAt.difference(now);

        if (timeLeft.inMilliseconds <= 0) continue; // already overdue
        if (endAt.isAfter(now) && !endAt.isAfter(now.add(const Duration(minutes: 10)))) {
          // within next 10 mins
          if (_endingSoonAlerted.contains(d.id) || _endingSoonDialogOpen) continue;
          _endingSoonAlerted.add(d.id);
          _endingSoonDialogOpen = true;

          final data = m;
          unawaited(showDialog(
            context: context,
            barrierDismissible: true,
            builder: (_) {
              final customer = data['customerName']?.toString() ?? 'Walk-in';
              final seat = data['seatLabel']?.toString() ?? 'Seat';
              final mm = timeLeft.inMinutes;
              final ss = (timeLeft.inSeconds % 60).toString().padLeft(2, '0');
              return AlertDialog(
                backgroundColor: const Color(0xFF111827),
                title: const Text('Session ending soon', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                content: Text(
                  '$customer • $seat\nEnds in ~$mm:${ss} min',
                  style: const TextStyle(color: Colors.white70),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: const Text('Later', style: TextStyle(color: Colors.white70)),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      showDialog(
                        context: context,
                        builder: (_) => BookingActionsDialog(
                          branchId: branchId,
                          sessionId: d.id,
                          data: data,
                        ),
                      );
                    },
                    child: const Text('Open booking'),
                  ),
                ],
              );
            },
          ).whenComplete(() {
            _endingSoonDialogOpen = false;
          }));
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    // Drawer sizes
    const double drawerWidth = 360;      // Full panel width (like left nav)
    const double tabWidth = 44;          // Always-visible bell tab width
    final double closedRight = -(drawerWidth - tabWidth);
    final double openRight = 0;

    return AppShell(
      child: user == null
          ? const Center(child: Text('Not logged in', style: TextStyle(color: Colors.white)))
          : StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
              builder: (context, userSnap) {
                if (userSnap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: Colors.white));
                }

                final userData = userSnap.data?.data() as Map<String, dynamic>? ?? {};
                final role = (userData['role'] ?? 'staff').toString();
                final List<dynamic> branchIdsDyn = (userData['branchIds'] as List<dynamic>?) ?? [];
                final allowedBranchIds = branchIdsDyn.map((e) => e.toString()).toList();

                final branchesRef = FirebaseFirestore.instance.collection('branches');

                return StreamBuilder<QuerySnapshot>(
                  stream: branchesRef.snapshots(),
                  builder: (context, branchSnap) {
                    if (branchSnap.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator(color: Colors.white));
                    }
                    if (branchSnap.hasError) {
                      return const Center(child: Text('Failed to load branches', style: TextStyle(color: Colors.white70)));
                    }
                    if (!branchSnap.hasData || branchSnap.data!.docs.isEmpty) {
                      return const Center(child: Text('No branches configured yet.', style: TextStyle(color: Colors.white70)));
                    }

                    final allBranches = branchSnap.data!.docs;
                    final visibleBranches = (role == 'superadmin' || allowedBranchIds.isEmpty)
                        ? allBranches
                        : allBranches.where((b) => allowedBranchIds.contains(b.id)).toList();

                    if (visibleBranches.isEmpty) {
                      return const Center(child: Text('No branches assigned to your account.', style: TextStyle(color: Colors.white70)));
                    }

                    String effectiveBranchId = _selectedBranchId ?? visibleBranches.first.id;
                    if (_selectedBranchId == null || !visibleBranches.any((b) => b.id == _selectedBranchId)) {
                      effectiveBranchId = visibleBranches.first.id;
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (!mounted) return;
                        setState(() {
                          _selectedBranchId = effectiveBranchId;
                        });
                        // attach watcher on first resolution
                        _attachEndingSoonWatcher(branchId: effectiveBranchId);
                      });
                    } else {
                      // ensure watcher is attached to the current branch
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        _attachEndingSoonWatcher(branchId: effectiveBranchId);
                      });
                    }

                    final selectedBranchDoc = visibleBranches.firstWhere((b) => b.id == effectiveBranchId);
                    final selectedBranchName =
                        (selectedBranchDoc.data() as Map<String, dynamic>?)?['name']?.toString() ?? effectiveBranchId;

                    // ── Page layout: content + right overlay drawer ──
                    return Stack(
                      children: [
                        // Main content (no forced right padding now; drawer overlays)
                        SingleChildScrollView(
                          padding: const EdgeInsets.only(right: 16, bottom: 24),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Greeting
                              Text(
                                'Hello, ${userData['name'] ?? 'Admin'} 👋',
                                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(height: 12),

                              // Branch selector
                              Row(
                                children: [
                                  Text('Branch:',
                                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w500,
                                      )),
                                  const SizedBox(width: 12),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF111827),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(color: Colors.white12),
                                    ),
                                    child: DropdownButton<String>(
                                      value: effectiveBranchId,
                                      dropdownColor: const Color(0xFF111827),
                                      underline: const SizedBox.shrink(),
                                      style: const TextStyle(color: Colors.white),
                                      items: visibleBranches.map((b) {
                                        final data = b.data() as Map<String, dynamic>? ?? {};
                                        final name = (data['name'] ?? b.id).toString();
                                        return DropdownMenuItem(value: b.id, child: Text(name));
                                      }).toList(),
                                      onChanged: (v) {
                                        if (v == null) return;
                                        setState(() {
                                          _selectedBranchId = v;
                                          _endingSoonAlerted.clear(); // reset per-branch
                                        });
                                        _attachEndingSoonWatcher(branchId: v);
                                      },
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 20),

                              // Top stats
                              Wrap(
                                spacing: 16,
                                runSpacing: 16,
                                children: [
                                  const _BranchesStatCard(),
                                  _TodayStatsCards(selectedBranchId: effectiveBranchId),
                                  _TodayInvoiceStatsCards(selectedBranchId: effectiveBranchId),
                                ],
                              ),
                              const SizedBox(height: 24),

                              _QuickActionsRow(
                                role: role,
                                allowedBranchIds: allowedBranchIds,
                                selectedBranchId: effectiveBranchId,
                              ),
                              const SizedBox(height: 24),

                              Text('Console Map (Live)',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white,
                                  )),
                              const SizedBox(height: 12),
                              _ConsoleMapCard(branchId: effectiveBranchId),
                              const SizedBox(height: 30),

                              Text('Today’s Timeline (All Consoles)',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white,
                                  )),
                              const SizedBox(height: 12),
                              _DashboardTimelineCard(branchId: effectiveBranchId),
                              const SizedBox(height: 30),

                              Text('Today\'s Active Sessions',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white,
                                  )),
                              const SizedBox(height: 12),
                              _TodayActiveSessionsCard(branchId: effectiveBranchId),

                              const SizedBox(height: 30),
                              _UpcomingSessionsCard(branchId: effectiveBranchId),
                            ],
                          ),
                        ),

                        // Always-visible bell tab when drawer is closed
                        if (!_notifOpen)
                          Positioned(
                            top: 20, // below top bar
                            right: 0,
                            child: _BellTab(onTap: () => setState(() => _notifOpen = true)),
                          ),

                        // Right Notifications Drawer (slides over content)
                        AnimatedPositioned(
                          duration: const Duration(milliseconds: 240),
                          curve: Curves.easeOutCubic,
                          top: 16, // keep clear of top bar
                          right: _notifOpen ? openRight : closedRight,
                          bottom: 16,
                          width: drawerWidth,
                          child: _RightNotifDrawer(
                            onClose: () => setState(() => _notifOpen = false),
                            userId: user.uid,
                            branchId: effectiveBranchId,
                            branchName: selectedBranchName,
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
    );
  }
}

// ───────────────────────── generic stat card ─────────────────────────
class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  const _StatCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 22,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _BranchesStatCard extends StatelessWidget {
  const _BranchesStatCard();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('branches').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return const _StatCard(title: 'Total Branches', value: '—');
        }
        final count = snap.data?.docs.length ?? 0;
        return _StatCard(title: 'Total Branches', value: '$count');
      },
    );
  }
}

// ───────────────────────── TODAY sessions stats ─────────────────────────
class _TodayStatsCards extends StatelessWidget {
  final String selectedBranchId;
  const _TodayStatsCards({required this.selectedBranchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();

    final sessionsTodayRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(selectedBranchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
        .where('startTime', isLessThan: range.endUtc);

    return StreamBuilder<QuerySnapshot>(
      stream: sessionsTodayRef.snapshots(),
      builder: (context, todaySnap) {
        int todaysBookings = 0;
        int activeNow = 0;

        if (todaySnap.hasData) {
          final now = DateTime.now();
          final docs = todaySnap.data!.docs;
          todaysBookings = docs.length;
          activeNow = docs.where((d) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            return _isActiveNow(m, now);
          }).length;
        }

        return Wrap(
          spacing: 16,
          runSpacing: 16,
          children: [
            _StatCard(
              title: 'Today’s Bookings',
              value: todaySnap.hasError ? '—' : '$todaysBookings',
            ),
            _StatCard(
              title: 'Active Bookings',
              value: todaySnap.hasError ? '—' : '$activeNow',
            ),
          ],
        );
      },
    );
  }
}

// ───────────────────────── TODAY invoices stats ─────────────────────────
class _TodayInvoiceStatsCards extends StatelessWidget {
  final String selectedBranchId;
  const _TodayInvoiceStatsCards({required this.selectedBranchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();

    final invoicesRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(selectedBranchId)
        .collection('invoices')
        .where('createdAt', isGreaterThanOrEqualTo: range.startUtc)
        .where('createdAt', isLessThan: range.endUtc);

    return StreamBuilder<QuerySnapshot>(
      stream: invoicesRef.snapshots(),
      builder: (context, invSnap) {
        final needsFallback =
            invSnap.hasError || !(invSnap.hasData && invSnap.data!.docs.isNotEmpty);

        if (!needsFallback) {
          return _buildInvoiceCardsFromSnapshot(invSnap, range, alreadyDateFiltered: true);
        }

        final sessionsRef = FirebaseFirestore.instance
            .collection('branches')
            .doc(selectedBranchId)
            .collection('sessions')
            .where('closedAt', isGreaterThanOrEqualTo: range.startUtc)
            .where('closedAt', isLessThan: range.endUtc);

        return StreamBuilder<QuerySnapshot>(
          stream: sessionsRef.snapshots(),
          builder: (context, sesSnap) {
            if (!sesSnap.hasData) {
              return Wrap(
                spacing: 16,
                runSpacing: 16,
                children: const [
                  _StatCard(title: 'Today Revenue', value: '₹—'),
                  _StatCard(title: 'Pending Payments', value: '₹—'),
                ],
              );
            }

            double revenue = 0.0;
            double pending = 0.0;

            for (final d in sesSnap.data!.docs) {
              final m = d.data() as Map<String, dynamic>? ?? {};

              final status = _statusOf(m);
              final pay = _readPaymentStatus(m);
              final amount = _readInvoiceAmount(m);

              if (status == 'completed' && pay == 'paid') {
                revenue += amount;
              } else if (status == 'completed' && pay == 'pending') {
                pending += amount;
              }
            }

            return Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                _StatCard(title: 'Today Revenue', value: '₹${revenue.toStringAsFixed(0)}'),
                _StatCard(title: 'Pending Payments', value: '₹${pending.toStringAsFixed(0)}'),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildInvoiceCardsFromSnapshot(
    AsyncSnapshot<QuerySnapshot> snap,
    _DayRangeUtc range, {
    bool alreadyDateFiltered = false,
  }) {
    if (!snap.hasData) {
      return Wrap(
        spacing: 16,
        runSpacing: 16,
        children: const [
          _StatCard(title: 'Today Revenue', value: '₹—'),
          _StatCard(title: 'Pending Payments', value: '₹—'),
        ],
      );
    }

    double revenue = 0.0;
    double pending = 0.0;

    for (final d in snap.data!.docs) {
      final m = d.data() as Map<String, dynamic>? ?? {};
      if (!alreadyDateFiltered && !_isInTodayUtcWindow(m, range)) continue;

      final amount = _readInvoiceAmount(m);
      final pay = _readPaymentStatus(m);

      if (pay == 'paid') {
        revenue += amount;
      } else if (pay == 'pending') {
        pending += amount;
      }
    }

    return Wrap(
      spacing: 16,
      runSpacing: 16,
      children: [
        _StatCard(title: 'Today Revenue', value: '₹${revenue.toStringAsFixed(0)}'),
        _StatCard(title: 'Pending Payments', value: '₹${pending.toStringAsFixed(0)}'),
      ],
    );
  }
}

// ───────────────────────── QUICK ACTIONS ─────────────────────────
class _QuickActionsRow extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  final String selectedBranchId;
  const _QuickActionsRow({
    required this.role,
    required this.allowedBranchIds,
    required this.selectedBranchId,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        _QuickActionButton(
          icon: Icons.person_add_alt_1,
          label: 'New Walk-in',
          onTap: () async {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => AddBookingDialog(
                allowedBranchIds: allowedBranchIds,
                initialBranchId: selectedBranchId,
              ),
            );
          },
        ),
        _QuickActionButton(
          icon: Icons.event_note_outlined,
          label: 'View Bookings',
          onTap: () {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            showDialog(context: context, builder: (_) => _TodaysBookingsDialog(branchId: selectedBranchId));
          },
        ),
        _QuickActionButton(
          icon: Icons.fastfood_outlined,
          label: 'Add F&B Order',
          onTap: () async {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            await _openSessionPickerAndThen(
              context: context,
              branchId: selectedBranchId,
              onSessionSelected: (branchId, sessionId, data) {
                showDialog(context: context, builder: (_) => BookingActionsDialog(branchId: branchId, sessionId: sessionId, data: data));
              },
            );
          },
        ),
        _QuickActionButton(
          icon: Icons.payments_outlined,
          label: 'Quick Checkout',
          onTap: () async {
            if (selectedBranchId.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a branch first')),
              );
              return;
            }
            await _openSessionPickerAndThen(
              context: context,
              branchId: selectedBranchId,
              onSessionSelected: (branchId, sessionId, data) {
                showDialog(context: context, builder: (_) => BookingCloseBillDialog(branchId: branchId, sessionId: sessionId, data: data));
              },
            );
          },
        ),
      ],
    );
  }

  Future<void> _openSessionPickerAndThen({
    required BuildContext context,
    required String branchId,
    required void Function(String branchId, String sessionId, Map<String, dynamic> data) onSessionSelected,
  }) async {
    final range = _todayIstToUtc();
    final now = DateTime.now();

    final sessionsSnap = await FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
        .where('startTime', isLessThan: range.endUtc)
        .get();

    final activeDocs = sessionsSnap.docs.where((doc) {
      final data = (doc.data() as Map<String, dynamic>?) ?? {};
      return _isActiveNow(data, now);
    }).toList();

    if (activeDocs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No active sessions for this branch')));
      return;
    }

    if (activeDocs.length == 1) {
      final s = activeDocs.first;
      final data = (s.data() as Map<String, dynamic>?) ?? {};
      onSessionSelected(branchId, s.id, data);
      return;
    }

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF111827),
        child: Container(
          width: 400,
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Select session', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16, color: Colors.white)),
              const SizedBox(height: 12),
              ...activeDocs.map((doc) {
                final data = (doc.data() as Map<String, dynamic>?) ?? {};
                final customer = data['customerName']?.toString() ?? 'Walk-in';
                final seat = data['seatLabel']?.toString() ?? 'Seat';
                final ts = (data['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}' : '—';
                return ListTile(
                  title: Text(customer, style: const TextStyle(color: Colors.white)),
                  subtitle: Text('Console: $seat | Start: $timeString', style: const TextStyle(color: Colors.white70)),
                  onTap: () {
                    Navigator.of(context).pop();
                    onSessionSelected(branchId, doc.id, data);
                  },
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickActionButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2937),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 32,
              width: 32,
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── console map ─────────────────────────
class _SeatSession {
  final String id;
  final String status;
  final String customerName;
  final DateTime? start;
  final DateTime? end;

  _SeatSession({required this.id, required this.status, required this.customerName, required this.start, required this.end});
}

class _ConsoleMapCard extends StatelessWidget {
  final String branchId;
  const _ConsoleMapCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF1F2937), borderRadius: BorderRadius.circular(20)),
      child: _BranchConsoleGrid(branchId: branchId),
    );
  }
}

class _BranchConsoleGrid extends StatelessWidget {
  final String branchId;
  const _BranchConsoleGrid({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final seatsRef = FirebaseFirestore.instance.collection('branches').doc(branchId).collection('seats');
    final sessionsRef = FirebaseFirestore.instance.collection('branches').doc(branchId).collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: seatsRef.snapshots(),
      builder: (context, seatsSnap) {
        final seats = seatsSnap.data?.docs ?? [];

        return StreamBuilder<QuerySnapshot>(
          stream: sessionsRef.snapshots(),
          builder: (context, sessionsSnap) {
            if ((seatsSnap.connectionState == ConnectionState.waiting && seatsSnap.data == null)) {
              return const Padding(padding: EdgeInsets.all(16), child: LinearProgressIndicator(color: Colors.white));
            }
            if (seatsSnap.hasError || sessionsSnap.hasError) {
              return const Text('Failed to load consoles.', style: TextStyle(color: Colors.white70));
            }
            if (seats.isEmpty) {
              return const Text('No consoles/seats found for this branch.', style: TextStyle(color: Colors.white70));
            }

            final sessions = sessionsSnap.data?.docs ?? [];
            final Map<String, List<_SeatSession>> sessionsBySeat = {};
            for (final s in sessions) {
              final sData = s.data() as Map<String, dynamic>? ?? {};
              final seatId = sData['seatId']?.toString();
              if (seatId == null) continue;

              final statusRaw = sData['status']?.toString() ?? 'active';
              final status = statusRaw.toLowerCase();
              if (status == 'cancelled' || status == 'completed') continue;

              final start = (sData['startTime'] as Timestamp?)?.toDate();
              final dur = (sData['durationMinutes'] as num?)?.toInt() ?? 60;
              final end = start != null ? start.add(Duration(minutes: dur)) : null;

              sessionsBySeat.putIfAbsent(seatId, () => []).add(
                    _SeatSession(
                      id: s.id,
                      status: statusRaw,
                      customerName: sData['customerName']?.toString() ?? 'Walk-in',
                      start: start,
                      end: end,
                    ),
                  );
            }

            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: seats.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 6,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.15,
              ),
              itemBuilder: (context, index) {
                final seatDoc = seats[index];
                final seatId = seatDoc.id;
                final data = seatDoc.data() as Map<String, dynamic>? ?? {};
                final label = data['label']?.toString() ?? 'Seat ${index + 1}';
                final type = data['type']?.toString() ?? 'console';
                final isActive = (data['active'] as bool?) ?? true;

                final seatSessions = (sessionsBySeat[seatId] ?? []).toList()
                  ..sort((a, b) {
                    final aStart = a.start ?? DateTime.fromMillisecondsSinceEpoch(0);
                    final bStart = b.start ?? DateTime.fromMillisecondsSinceEpoch(0);
                    return aStart.compareTo(bStart);
                  });

                String status = 'free';
                bool hasActiveNow = false;
                bool hasReservedFuture = false;
                bool hasFutureAny = false;

                for (final s in seatSessions) {
                  final start = s.start;
                  final end = s.end;
                  if (start == null || end == null) continue;
                  final now = DateTime.now();
                  if (now.isAfter(start) && now.isBefore(end)) hasActiveNow = true;
                  if (s.status.toLowerCase() == 'reserved' && start.isAfter(now)) hasReservedFuture = true;
                  if (start.isAfter(now)) hasFutureAny = true;
                }

                if (hasActiveNow) {
                  status = 'in_use';
                } else if (hasReservedFuture) {
                  status = 'reserved';
                } else if (hasFutureAny) {
                  status = 'booked';
                }

                bool hasOverlap = false;
                for (var i = 0; i < seatSessions.length; i++) {
                  final a = seatSessions[i];
                  if (a.start == null || a.end == null) continue;
                  for (var j = i + 1; j < seatSessions.length; j++) {
                    final b = seatSessions[j];
                    if (b.start == null || b.end == null) continue;
                    final overlap = a.start!.isBefore(b.end!) && b.start!.isBefore(a.end!);
                    if (overlap) {
                      hasOverlap = true;
                      break;
                    }
                  }
                  if (hasOverlap) break;
                }

                return _ConsoleTile(
                  label: label,
                  type: type,
                  isActive: isActive,
                  status: status,
                  sessions: seatSessions,
                  hasOverlap: hasOverlap,
                );
              },
            );
          },
        );
      },
    );
  }
}

class _ConsoleTile extends StatelessWidget {
  final String label;
  final String type;
  final bool isActive;
  final String status;
  final List<_SeatSession> sessions;
  final bool hasOverlap;

  const _ConsoleTile({
    required this.label,
    required this.type,
    required this.isActive,
    required this.status,
    required this.sessions,
    required this.hasOverlap,
  });

  Color _statusColor() {
    switch (status) {
      case 'in_use':
        return Colors.grey.shade300;
      case 'booked':
        return Colors.amberAccent;
      case 'reserved':
        return Colors.orangeAccent;
      default:
        return Colors.greenAccent;
    }
  }

  Color _statusBg() {
    switch (status) {
      case 'in_use':
        return const Color(0xFF374151);
      case 'booked':
        return const Color(0xFF3B2F0B);
      case 'reserved':
        return const Color(0xFF4A1F1A);
      default:
        return const Color(0xFF064E3B);
    }
  }

  String _statusText() {
    switch (status) {
      case 'in_use':
        return 'In use';
      case 'booked':
        return 'Booked';
      case 'reserved':
        return 'Reserved';
      default:
        return 'Free';
    }
  }

  IconData _iconForType() {
    final lower = type.toLowerCase();
    if (lower.contains('pc')) return Icons.computer;
    if (lower.contains('console')) return Icons.sports_esports;
    if (lower.contains('recliner')) return Icons.chair_alt;
    return Icons.chair;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: sessions.isEmpty
          ? null
          : () {
              showDialog(
                context: context,
                builder: (_) => Dialog(
                  backgroundColor: const Color(0xFF111827),
                  child: DefaultTextStyle(
                    style: const TextStyle(color: Colors.white),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      width: 360,
                      color: const Color(0xFF111827),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                          const SizedBox(height: 8),
                          Text('Status: ${_statusText()}'),
                          if (!isActive)
                            const Text('Console is marked inactive', style: TextStyle(color: Colors.redAccent, fontSize: 12)),
                          const SizedBox(height: 12),
                          if (hasOverlap)
                            const Padding(
                              padding: EdgeInsets.only(bottom: 8.0),
                              child: Text('⚠ Overlapping bookings detected on this console.',
                                  style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w600)),
                            ),
                          const Text('Bookings for this console', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                          const SizedBox(height: 8),
                          if (sessions.isEmpty)
                            const Text('No bookings found.', style: TextStyle(color: Colors.white70)),
                          if (sessions.isNotEmpty)
                            ...sessions.map((s) {
                              final st = s.start;
                              final et = s.end;
                              final stStr = st != null ? '${st.hour.toString().padLeft(2, '0')}:${st.minute.toString().padLeft(2, '0')}' : '—';
                              final etStr = et != null ? '${et.hour.toString().padLeft(2, '0')}:${et.minute.toString().padLeft(2, '0')}' : '—';
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4.0),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(999)),
                                      child: Text(s.status, style: const TextStyle(fontSize: 10)),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(child: Text(s.customerName, style: const TextStyle(fontSize: 13, color: Colors.white))),
                                    const SizedBox(width: 8),
                                    Text('$stStr–$etStr', style: const TextStyle(fontSize: 12, color: Colors.white70)),
                                  ],
                                ),
                              );
                            }),
                          const SizedBox(height: 12),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () => Navigator.of(context).pop(),
                              child: const Text('Close', style: TextStyle(color: Colors.white70)),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
      child: Container(
        decoration: BoxDecoration(
          color: _statusBg(),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _statusColor(), width: 3),
        ),
        padding: const EdgeInsets.all(10),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(_iconForType(), color: Colors.white, size: 30),
                const SizedBox(height: 8),
                Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text(isActive ? type : '$type (inactive)', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                if (sessions.length > 1)
                  const Padding(
                    padding: EdgeInsets.only(top: 4.0),
                    child: Text('Multiple bookings', style: TextStyle(color: Colors.white70, fontSize: 10)),
                  ),
              ],
            ),
            Positioned(
              right: 0,
              top: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _statusColor().withOpacity(0.2),
                  border: Border.all(color: _statusColor()),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(_statusText(), style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w500)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── Active / Upcoming sections ─────────────────────────
class _TodayActiveSessionsCard extends StatelessWidget {
  final String branchId;
  const _TodayActiveSessionsCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();

    final sessionsRef = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
        .where('startTime', isLessThan: range.endUtc);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF1F2937), borderRadius: BorderRadius.circular(20)),
      child: StreamBuilder<QuerySnapshot>(
        stream: sessionsRef.snapshots(),
        builder: (context, sessionSnap) {
          if (sessionSnap.connectionState == ConnectionState.waiting) {
            return const LinearProgressIndicator(color: Colors.white);
          }
          if (sessionSnap.hasError) {
            return const Text('Failed to load sessions.', style: TextStyle(color: Colors.white70));
          }
          final docs = sessionSnap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Text('No sessions for today.', style: TextStyle(color: Colors.white70));
          }

          final now = DateTime.now();
          final active = <QueryDocumentSnapshot>[];
          final overdue = <QueryDocumentSnapshot>[];

          for (final doc in docs) {
            final data = doc.data() as Map<String, dynamic>? ?? {};
            if (_isActiveNow(data, now)) {
              active.add(doc);
            } else if (_isOverdueNow(data, now)) {
              overdue.add(doc);
            }
          }

          if (active.isEmpty && overdue.isEmpty) {
            return const Text('No active sessions right now.', style: TextStyle(color: Colors.white70));
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ...active.map((doc) {
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final customer = data['customerName']?.toString() ?? 'Walk-in';
                final seatLabel = data['seatLabel']?.toString() ?? 'Seat';
                final ts = (data['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}' : '—';
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(backgroundColor: Colors.black, child: Icon(Icons.chair_outlined, color: Colors.white)),
                  title: Text(customer, style: const TextStyle(color: Colors.white)),
                  subtitle: Text('Console: $seatLabel | Started: $timeString', style: TextStyle(color: Colors.grey.shade400)),
                  trailing: ElevatedButton(
                    onPressed: () {
                      showDialog(context: context, builder: (_) => BookingActionsDialog(branchId: branchId, sessionId: doc.id, data: data));
                    },
                    child: const Text('View'),
                  ),
                );
              }).toList(),
              if (overdue.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text('Overdue sessions', style: TextStyle(color: Colors.redAccent.shade100, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                ...overdue.map((doc) {
                  final data = doc.data() as Map<String, dynamic>? ?? {};
                  final customer = data['customerName']?.toString() ?? 'Walk-in';
                  final seatLabel = data['seatLabel']?.toString() ?? 'Seat';
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(backgroundColor: Colors.redAccent, child: Icon(Icons.warning_amber, color: Colors.white)),
                    title: Text(customer, style: const TextStyle(color: Colors.white)),
                    subtitle: const Text('Should be closed', style: TextStyle(color: Colors.white70)),
                    trailing: ElevatedButton(
                      onPressed: () {
                        showDialog(context: context, builder: (_) => BookingActionsDialog(branchId: branchId, sessionId: doc.id, data: data));
                      },
                      child: const Text('Close now'),
                    ),
                  );
                }).toList(),
              ]
            ],
          );
        },
      ),
    );
  }
}

class _DashboardTimelineCard extends StatelessWidget {
  final String branchId;
  const _DashboardTimelineCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();
    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
        .where('startTime', isLessThan: range.endUtc);

    return Container(
      height: 420,
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white10),
      ),
      padding: const EdgeInsets.all(12),
      child: StreamBuilder<QuerySnapshot>(
        stream: sessionsRef.snapshots(),
        builder: (context, snap) {
          final docs = snap.data?.docs ?? const <QueryDocumentSnapshot>[];
          return BookingTimelineView(
            bookings: docs,
            date: DateTime.now(),
            branchId: branchId,
          );
        },
      ),
    );
  }
}

class _UpcomingSessionsCard extends StatefulWidget {
  final String branchId;
  const _UpcomingSessionsCard({required this.branchId});
  @override
  State<_UpcomingSessionsCard> createState() => _UpcomingSessionsCardState();
}

class _UpcomingSessionsCardState extends State<_UpcomingSessionsCard> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final now = DateTime.now().toUtc();
      final inOneHour = now.add(const Duration(minutes: 60));
      final snap = await FirebaseFirestore.instance
          .collection('branches').doc(widget.branchId)
          .collection('sessions')
          .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
          .where('startTime', isLessThanOrEqualTo: Timestamp.fromDate(inOneHour))
          .get();

      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] as String?) ?? '';
        return status == 'reserved';
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0);
          return ta.compareTo(tb);
        });

      setState(() {
        _docs = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load upcoming bookings.';
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF1F2937), borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('Upcoming in next 60 minutes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              IconButton(tooltip: 'Refresh', onPressed: _load, icon: const Icon(Icons.refresh, color: Colors.white70)),
            ],
          ),
          const SizedBox(height: 8),
          if (_loading)
            const Text('Loading upcoming bookings...', style: TextStyle(color: Colors.white70))
          else if (_error != null)
            const Text('Failed to load upcoming bookings.', style: TextStyle(color: Colors.redAccent))
          else if (_docs.isEmpty)
            const Text('No upcoming bookings in the next 60 minutes.', style: TextStyle(color: Colors.white70))
          else
            Column(
              children: _docs.map((doc) {
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final customer = data['customerName']?.toString() ?? 'Walk-in';
                final seat = data['seatLabel']?.toString() ?? 'Seat';
                final ts = (data['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}' : '—';
                final branchName = data['branchName']?.toString() ?? '';
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(backgroundColor: Colors.deepOrange, child: Icon(Icons.timer, color: Colors.white)),
                  title: Text(customer, style: const TextStyle(color: Colors.white)),
                  subtitle: Text('$branchName • Console: $seat • Starts at: $timeString • Yet to start', style: TextStyle(color: Colors.grey.shade400)),
                  trailing: TextButton(
                    onPressed: () {
                      showDialog(context: context, builder: (_) => BookingActionsDialog(branchId: widget.branchId, sessionId: doc.id, data: data));
                    },
                    child: const Text('Manage'),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}

class _TodaysBookingsDialog extends StatefulWidget {
  final String branchId;
  const _TodaysBookingsDialog({required this.branchId});
  @override
  State<_TodaysBookingsDialog> createState() => _TodaysBookingsDialogState();
}

class _TodaysBookingsDialogState extends State<_TodaysBookingsDialog> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final range = _todayIstToUtc();
      final snap = await FirebaseFirestore.instance
          .collection('branches').doc(widget.branchId)
          .collection('sessions')
          .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
          .where('startTime', isLessThan: range.endUtc)
          .get();

      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] as String?) ?? '';
        return status != 'cancelled';
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ?? DateTime.fromMillisecondsSinceEpoch(0);
          return ta.compareTo(tb);
        });

      setState(() {
        _docs = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load bookings.';
        _loading = false;
      });
    }
  }

  @override
  void initState() { super.initState(); _load(); }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF111827),
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(16),
        color: const Color(0xFF111827),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(child: Text('Today’s Bookings', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white))),
                IconButton(tooltip: 'Refresh', onPressed: _load, icon: const Icon(Icons.refresh, color: Colors.white70)),
              ],
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Text('Loading...', style: TextStyle(color: Colors.white70))
            else if (_error != null)
              const Text('Failed to load bookings.', style: TextStyle(color: Colors.redAccent))
            else if (_docs.isEmpty)
              const Text('No bookings today.', style: TextStyle(color: Colors.white70))
            else
              SizedBox(
                height: 380,
                child: ListView.separated(
                  itemCount: _docs.length,
                  separatorBuilder: (_, __) => const Divider(color: Colors.white12, height: 12),
                  itemBuilder: (context, i) {
                    final d = _docs[i];
                    final m = d.data() as Map<String, dynamic>? ?? {};
                    final name = m['customerName']?.toString() ?? 'Walk-in';
                    final seat = m['seatLabel']?.toString() ?? '-';
                    final branch = m['branchName']?.toString() ?? '';
                    final ts = (m['startTime'] as Timestamp?)?.toDate();
                    final timeStr = ts != null ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}' : '—';
                    final status = (m['status'] as String?) ?? '';
                    return ListTile(
                      leading: const Icon(Icons.event, color: Colors.white70),
                      title: Text(name, style: const TextStyle(color: Colors.white)),
                      subtitle: Text('$branch • Seat $seat • $status', style: const TextStyle(color: Colors.white60)),
                      trailing: Text(timeStr, style: const TextStyle(color: Colors.white70)),
                    );
                  },
                ),
              ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close', style: TextStyle(color: Colors.white70))),
            )
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── Right Drawer + Bell Tab ─────────────────────────

class _BellTab extends StatelessWidget {
  final VoidCallback onTap;
  const _BellTab({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF111827),
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(14),
        bottomLeft: Radius.circular(14),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(14),
          bottomLeft: Radius.circular(14),
        ),
        child: Container(
          width: 44,
          height: 120,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.white12),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              bottomLeft: Radius.circular(14),
            ),
          ),
          child: const Center(
            child: RotatedBox(
              quarterTurns: 1,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.notifications_none, color: Colors.white70, size: 18),
                  SizedBox(width: 8),
                  Text('Notifications', style: TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RightNotifDrawer extends StatelessWidget {
  final VoidCallback onClose;
  final String userId;
  final String branchId;
  final String branchName;

  const _RightNotifDrawer({
    required this.onClose,
    required this.userId,
    required this.branchId,
    required this.branchName,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          border: Border.all(color: Colors.white12),
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(12),
        child: _NotificationsPanel(
          userId: userId,
          branchId: branchId,
          branchName: branchName,
          onRequestClose: onClose,
        ),
      ),
    );
  }
}

// ───────────────────────── Notifications Panel (overlay, in-file) ─────────────────────────

class _NotificationsPanel extends StatefulWidget {
  final String userId;
  final String branchId;
  final String branchName;
  final VoidCallback onRequestClose;

  const _NotificationsPanel({
    required this.userId,
    required this.branchId,
    required this.branchName,
    required this.onRequestClose,
  });

  @override
  State<_NotificationsPanel> createState() => _NotificationsPanelState();
}

class _NotificationsPanelState extends State<_NotificationsPanel> {
  // default prefs (used if field missing)
  Map<String, bool> _defaults = const {
    'endingSoon': true,
    'upcoming': true,
    'overdue': true,
    'lowStock': true,
    'pendingDues': true,
    'newBookings': true,
  };

  @override
  Widget build(BuildContext context) {
    final userDoc = FirebaseFirestore.instance.collection('users').doc(widget.userId);

    return StreamBuilder<DocumentSnapshot>(
      stream: userDoc.snapshots(),
      builder: (context, snap) {
        Map<String, dynamic> data = {};
        if (snap.hasData && snap.data?.data() != null) {
          data = snap.data!.data() as Map<String, dynamic>;
        }
        final prefsDyn = (data['notificationPrefs'] as Map?) ?? {};
        final prefs = <String, bool>{..._defaults, ...prefsDyn.map((k, v) => MapEntry(k.toString(), v == true))};

        return Column(
          children: [
            Row(
              children: [
                const Icon(Icons.notifications_active_outlined, color: Colors.white),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('Notifications',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                ),
                IconButton(
                  tooltip: 'Preferences',
                  onPressed: () => showDialog(
                    context: context,
                    builder: (_) => Dialog(
                      backgroundColor: const Color(0xFF111827),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: _PrefsEditor(
                          userId: widget.userId,
                          initialPrefs: prefs,
                        ),
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.tune, color: Colors.white70),
                ),
                IconButton(
                  tooltip: 'Close',
                  onPressed: widget.onRequestClose,
                  icon: const Icon(Icons.chevron_right, color: Colors.white70),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                children: [
                  if (prefs['endingSoon'] == true)
                    _EndingSoonListTile(branchId: widget.branchId),
                  if (prefs['upcoming'] == true)
                    _UpcomingListTile(branchId: widget.branchId),
                  if (prefs['overdue'] == true)
                    _OverdueListTile(branchId: widget.branchId),
                  if (prefs['lowStock'] == true)
                    _LowStockListTile(branchId: widget.branchId),
                  if (prefs['pendingDues'] == true)
                    _PendingDuesListTile(branchId: widget.branchId),
                  if (prefs['newBookings'] == true)
                    _NewBookingsTodayListTile(branchId: widget.branchId),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

// Preferences editor (kept inline for this screen)
class _PrefsEditor extends StatefulWidget {
  final String userId;
  final Map<String, bool> initialPrefs;
  const _PrefsEditor({required this.userId, required this.initialPrefs});

  @override
  State<_PrefsEditor> createState() => _PrefsEditorState();
}

class _PrefsEditorState extends State<_PrefsEditor> {
  late Map<String, bool> _prefs;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _prefs = Map<String, bool>.from(widget.initialPrefs);
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final userDoc = FirebaseFirestore.instance.collection('users').doc(widget.userId);
    await userDoc.set({'notificationPrefs': _prefs}, SetOptions(merge: true));
    if (!mounted) return;
    setState(() => _saving = false);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Notification preferences saved')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style: const TextStyle(color: Colors.white),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('Notification Preferences',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          const SizedBox(height: 12),
          _toggle('Sessions ending in ≤10 mins', 'endingSoon'),
          _toggle('Upcoming reservations in ≤60 mins', 'upcoming'),
          _toggle('Overdue sessions', 'overdue'),
          _toggle('Low stock items', 'lowStock'),
          _toggle('Pending dues (today)', 'pendingDues'),
          _toggle('New bookings (today)', 'newBookings'),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving ? const CircularProgressIndicator() : const Text('Save'),
                ),
              ),
              const SizedBox(width: 12),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _toggle(String label, String key) {
    return SwitchListTile(
      value: _prefs[key] == true,
      onChanged: (v) => setState(() => _prefs[key] = v),
      contentPadding: EdgeInsets.zero,
      activeColor: Colors.white,
      title: Text(label, style: const TextStyle(color: Colors.white)),
    );
  }
}

// ───────────────────────── Notification list tiles ─────────────────────────

class _EndingSoonListTile extends StatelessWidget {
  final String branchId;
  const _EndingSoonListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final now = DateTime.now();
        final soon = now.add(const Duration(minutes: 10));
        int count = 0;
        QueryDocumentSnapshot? example;
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            if ((m['status'] ?? '').toString().toLowerCase() != 'active') continue;
            final st = (m['startTime'] as Timestamp?)?.toDate();
            final dur = (m['durationMinutes'] as num?)?.toInt() ?? 0;
            if (st == null) continue;
            final end = st.add(Duration(minutes: dur));
            if (end.isAfter(now) && !end.isAfter(soon)) {
              count++;
              example ??= d;
            }
          }
        }
        return _panelTile(
          icon: Icons.hourglass_bottom,
          title: 'Ending soon (≤10m)',
          badge: '$count',
          onTap: example == null
              ? null
              : () {
                  final m = example!.data() as Map<String, dynamic>? ?? {};
                  showDialog(
                    context: context,
                    builder: (_) => BookingActionsDialog(
                      branchId: branchId,
                      sessionId: example!.id,
                      data: m,
                    ),
                  );
                },
        );
      },
    );
  }
}

class _UpcomingListTile extends StatelessWidget {
  final String branchId;
  const _UpcomingListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final inOneHour = now.add(const Duration(minutes: 60));
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
        .where('startTime', isLessThanOrEqualTo: Timestamp.fromDate(inOneHour))
        .where('status', isEqualTo: 'reserved');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _panelTile(
          icon: Icons.schedule, // safe cross-SDK icon
          title: 'Upcoming (≤60m)',
          badge: '$count',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Open "Upcoming in next 60 minutes" section on the left.')),
            );
          },
        );
      },
    );
  }
}

class _OverdueListTile extends StatelessWidget {
  final String branchId;
  const _OverdueListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        int count = 0;
        QueryDocumentSnapshot? example;
        if (snap.hasData) {
          final now = DateTime.now();
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            if (_isOverdueNow(m, now)) {
              count++;
              example ??= d;
            }
          }
        }
        return _panelTile(
          icon: Icons.warning_amber_outlined,
          title: 'Overdue',
          badge: '$count',
          onTap: example == null
              ? null
              : () {
                  final m = example!.data() as Map<String, dynamic>? ?? {};
                  showDialog(
                    context: context,
                    builder: (_) => BookingActionsDialog(
                      branchId: branchId,
                      sessionId: example!.id,
                      data: m,
                    ),
                  );
                },
        );
      },
    );
  }
}

class _LowStockListTile extends StatelessWidget {
  final String branchId;
  const _LowStockListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('inventory');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        int low = 0;
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final active = (m['active'] as bool?) ?? true;
            final qty = (m['stockQty'] as num?)?.toDouble() ?? 0;
            final thr = (m['reorderThreshold'] as num?)?.toDouble() ?? -1;
            if (active && thr >= 0 && qty <= thr) low++;
          }
        }
        return _panelTile(
          icon: Icons.inventory_2_outlined,
          title: 'Low stock',
          badge: '$low',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Open Inventory to adjust or reorder.')),
            );
          },
        );
      },
    );
  }
}

class _PendingDuesListTile extends StatelessWidget {
  final String branchId;
  const _PendingDuesListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('closedAt', isGreaterThanOrEqualTo: range.startUtc)
        .where('closedAt', isLessThan: range.endUtc);

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        int pending = 0;
        if (snap.hasData) {
          for (final d in snap.data!.docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            if ((_statusOf(m) == 'completed') && (_readPaymentStatus(m) == 'pending')) {
              pending++;
            }
          }
        }
        return _panelTile(
          icon: Icons.payments_outlined,
          title: 'Pending dues (today)',
          badge: '$pending',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Use Invoices or Today stats to settle pending payments.')),
            );
          },
        );
      },
    );
  }
}

class _NewBookingsTodayListTile extends StatelessWidget {
  final String branchId;
  const _NewBookingsTodayListTile({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final range = _todayIstToUtc();
    // If createdAt isn’t present, we’ll count by startTime (approximate “today’s bookings”).
    final col = FirebaseFirestore.instance
        .collection('branches').doc(branchId)
        .collection('sessions')
        .where('startTime', isGreaterThanOrEqualTo: range.startUtc)
        .where('startTime', isLessThan: range.endUtc)
        .where('status', isNotEqualTo: 'cancelled');

    return StreamBuilder<QuerySnapshot>(
      stream: col.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _panelTile(
          icon: Icons.add_alert_outlined,
          title: 'New bookings (today)',
          badge: '$count',
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Open “Today’s Bookings” from Quick Actions.')),
            );
          },
        );
      },
    );
  }
}

// Small helper widget for panel rows
Widget _panelTile({
  required IconData icon,
  required String title,
  required String badge,
  VoidCallback? onTap,
}) {
  return ListTile(
    leading: Icon(icon, color: Colors.white70),
    title: Text(title, style: const TextStyle(color: Colors.white)),
    trailing: Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white12,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white24),
      ),
      child: Text(badge, style: const TextStyle(color: Colors.white)),
    ),
    onTap: onTap,
  );
}
