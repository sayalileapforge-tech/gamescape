// lib/features/bookings/booking_actions_dialog.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'add_order_dialog.dart';
import 'booking_move_seat_dialog.dart';
import 'booking_close_bill_dialog.dart';

enum SessionState {
  activeLive,
  activeOverdue,
  reservedFuture,
  reservedPast,
  completed,
  cancelled,
}

DateTime _tsUtc(dynamic ts) =>
    (ts is Timestamp ? ts.toDate() : (ts as DateTime?))?.toUtc() ??
    DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);

SessionState _stateOf(Map<String, dynamic> s) {
  final now = DateTime.now().toUtc();
  final status = (s['status'] as String?) ?? 'reserved';
  final start = _tsUtc(s['startTime']);
  final durationMins = (s['durationMinutes'] as num?)?.toInt() ?? 0;
  final endAt = start.add(Duration(minutes: durationMins));

  if (status == 'completed') return SessionState.completed;
  if (status == 'cancelled') return SessionState.cancelled;

  if (status == 'active') {
    return now.isBefore(endAt)
        ? SessionState.activeLive
        : SessionState.activeOverdue;
  }

  if (status == 'reserved') {
    return start.isAfter(now)
        ? SessionState.reservedFuture
        : SessionState.reservedPast;
  }

  return SessionState.cancelled;
}

class BookingActionsDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingActionsDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingActionsDialog> createState() => _BookingActionsDialogState();
}

class _BookingActionsDialogState extends State<BookingActionsDialog> {
  bool _busy = false;

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _extendBy(int minutes) async {
    setState(() => _busy = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      final current = (snap.data() ?? {}) as Map<String, dynamic>;
      final currentDuration =
          (current['durationMinutes'] as num?)?.toInt() ?? 0;
      tx.update(docRef, {
        'durationMinutes': currentDuration + minutes,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });

    if (mounted) {
      setState(() => _busy = false);
      _toast('Extended by $minutes minutes');
    }
  }

  Future<void> _startNow() async {
    setState(() => _busy = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await docRef.update({
      'status': 'active',
      'startTime': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      setState(() => _busy = false);
      Navigator.of(context).pop();
      _toast('Session started');
    }
  }

  Future<void> _cancelReservation() async {
    setState(() => _busy = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await docRef.update({
      'status': 'cancelled',
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      setState(() => _busy = false);
      Navigator.of(context).pop();
      _toast('Reservation cancelled');
    }
  }

  // ---------------- SMART CLOSE ----------------
  Future<void> _smartCloseOrOpenDialog() async {
    try {
      setState(() => _busy = true);

      final fs = FirebaseFirestore.instance;
      final sessRef = fs
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .doc(widget.sessionId);

      final snap = await sessRef.get();
      final s = (snap.data() ?? {}) as Map<String, dynamic>;

      final paymentType = (s['paymentType'] ?? 'postpaid').toString();
      final seatId = (s['seatId'] ?? '').toString();
      final duration = (s['durationMinutes'] as num?)?.toInt() ?? 0;
      final start = (s['startTime'] as Timestamp?)?.toDate();
      final status = (s['status'] ?? '').toString();

      // stale / not active: show full dialog
      if (start == null || status != 'active') {
        setState(() => _busy = false);
        await _openCloseDialog();
        return;
      }

      final ordersAny = await sessRef.collection('orders').limit(1).get();
      final hasOrders = ordersAny.docs.isNotEmpty;

      final now = DateTime.now();
      final played = now.difference(start).inMinutes;
      final playedMinutes =
          played < 0 ? 0 : (played > duration ? duration : played);

      final isQuickPath = paymentType == 'postpaid' && !hasOrders;

      if (!isQuickPath) {
        setState(() => _busy = false);
        await _openCloseDialog();
        return;
      }

      // Compute quick bill
      num ratePerHour = 0;
      if (seatId.isNotEmpty) {
        final seatSnap = await fs
            .collection('branches')
            .doc(widget.branchId)
            .collection('seats')
            .doc(seatId)
            .get();
        ratePerHour = (seatSnap.data()?['ratePerHour'] ?? 0) as num;
      }
      final subtotal = ratePerHour * (playedMinutes / 60);
      final billAmount = subtotal;

      final nowDt = DateTime.now();
      final invoiceNumber =
          'INV-${nowDt.year}${nowDt.month.toString().padLeft(2, '0')}${nowDt.day.toString().padLeft(2, '0')}-${(nowDt.millisecondsSinceEpoch % 100000).toString().padLeft(5, '0')}';

      final currentUser = FirebaseAuth.instance.currentUser;
      String? closedByName;
      if (currentUser != null) {
        final userDoc = await fs.collection('users').doc(currentUser.uid).get();
        if (userDoc.exists) {
          closedByName =
              (userDoc.data()?['name'] as String?) ?? currentUser.email;
        }
      }

      final batch = fs.batch();
      batch.update(sessRef, {
        'status': 'completed',
        'paymentStatus': 'pending',
        'closedAt': FieldValue.serverTimestamp(),
        'billAmount': billAmount,
        'subtotal': subtotal,
        'taxPercent': 0,
        'taxAmount': 0,
        'discount': 0,
        'playedMinutes': playedMinutes,
        'invoiceNumber': invoiceNumber,
        if (currentUser != null) 'closedBy': currentUser.uid,
        if (closedByName != null) 'closedByName': closedByName,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      if (seatId.isNotEmpty) {
        final seatRef = fs
            .collection('branches')
            .doc(widget.branchId)
            .collection('seats')
            .doc(seatId);
        batch.update(seatRef, {
          'status': 'free',
          'currentSessionId': null,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();

      // minimal customer aggregate
      final custName = (s['customerName'] ?? '').toString().trim();
      final custPhone = (s['customerPhone'] ?? '').toString().trim();
      if (custName.isNotEmpty || custPhone.isNotEmpty) {
        final custId =
            custPhone.isNotEmpty ? 'phone:$custPhone' : 'name:$custName';
        final custRef = fs.collection('customers').doc(custId);
        await fs.runTransaction((tx) async {
          final cs = await tx.get(custRef);
          final existing = cs.data() ?? {};
          final num prevSpend = (existing['lifetimeSpend'] ?? 0) as num;
          final int prevVisits = (existing['lifetimeVisits'] ?? 0) as int;
          final num prevSpend90 = (existing['spendLast90d'] ?? 0) as num;

          final lifetimeSpend = prevSpend + billAmount;
          final lifetimeVisits = prevVisits + 1;

          tx.set(
            custRef,
            {
              'name': custName,
              'phone': custPhone,
              'lifetimeSpend': lifetimeSpend,
              'lifetimeVisits': lifetimeVisits,
              'avgSpend':
                  lifetimeSpend / (lifetimeVisits == 0 ? 1 : lifetimeVisits),
              'spendLast90d': prevSpend90 + billAmount,
              'lastVisitAt': FieldValue.serverTimestamp(),
              'firstVisitAt':
                  existing['firstVisitAt'] ?? FieldValue.serverTimestamp(),
              'hasPendingDue': true,
              'updatedAt': FieldValue.serverTimestamp(),
            },
            SetOptions(merge: true),
          );
        });
      }

      if (!mounted) return;
      setState(() => _busy = false);
      Navigator.of(context).pop(); // close Actions dialog
      _toast('Session closed. Pending invoice created.');
    } catch (_) {
      if (!mounted) return;
      setState(() => _busy = false);
      // fallback to full dialog
      await _openCloseDialog();
    }
  }

  Future<void> _openCloseDialog() async {
    final res = await showDialog<bool>(
      context: context,
      builder: (_) => BookingCloseBillDialog(
        branchId: widget.branchId,
        sessionId: widget.sessionId,
        data: widget.data,
      ),
    );
    if (res == true && mounted) {
      Navigator.of(context).pop(); // also close Actions dialog
      _toast('Session closed. Pending invoice created.');
    }
  }
  // ---------------- /SMART CLOSE ----------------

  @override
  Widget build(BuildContext context) {
    final cust = widget.data['customerName'] ?? '';
    final seatId = widget.data['seatId'] ?? '';
    final seat = widget.data['seatLabel'] ?? '';
    final duration = (widget.data['durationMinutes'] as num?)?.toInt() ?? 0;
    final state = _stateOf(widget.data);

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      insetPadding: const EdgeInsets.all(20),
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Booking Actions',
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Colors.white),
              ),
              const SizedBox(height: 10),
              Text('Customer: $cust', style: const TextStyle(color: Colors.white)),
              Text('Seat: $seat', style: const TextStyle(color: Colors.white70)),
              Text('Duration: $duration mins', style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 16),

              if (state == SessionState.activeLive) ...[
                _actionBtn(
                  icon: Icons.add_alarm,
                  label: _busy ? 'Extending...' : 'Extend by 30 mins',
                  onTap: _busy ? null : () => _extendBy(30),
                ),
                const SizedBox(height: 10),
                _actionBtn(
                  icon: Icons.add_shopping_cart_outlined,
                  label: 'Add Order',
                  onTap: () => showDialog(
                    context: context,
                    builder: (_) => AddOrderDialog(
                      branchId: widget.branchId,
                      sessionId: widget.sessionId,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                _actionBtn(
                  icon: Icons.chair_outlined,
                  label: 'Move Seat',
                  onTap: () => showDialog(
                    context: context,
                    builder: (_) => BookingMoveSeatDialog(
                      branchId: widget.branchId,
                      sessionId: widget.sessionId,
                      currentSeatId: seatId.toString(),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                _actionBtn(
                  icon: Icons.payments_outlined,
                  label: _busy ? 'Closing...' : 'Close & Bill',
                  onTap: _busy ? null : _smartCloseOrOpenDialog,
                ),
              ] else if (state == SessionState.activeOverdue) ...[
                _actionBtn(
                  icon: Icons.add_alarm,
                  label: _busy ? 'Extending...' : 'Extend by 30 mins',
                  onTap: _busy ? null : () => _extendBy(30),
                ),
                const SizedBox(height: 10),
                _actionBtn(
                  icon: Icons.payments_outlined,
                  label: _busy ? 'Closing...' : 'Close (Overdue)',
                  onTap: _busy ? null : _smartCloseOrOpenDialog,
                ),
              ] else if (state == SessionState.reservedFuture) ...[
                _actionBtn(
                  icon: Icons.play_circle_outline,
                  label: _busy ? 'Starting...' : 'Start Now',
                  onTap: _busy ? null : _startNow,
                ),
                const SizedBox(height: 10),
                _actionBtn(
                  icon: Icons.event,
                  label: 'Reschedule',
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) => _EditBookingDetailsDialog(
                        branchId: widget.branchId,
                        sessionId: widget.sessionId,
                        initialData: widget.data,
                        enableReschedule: true, // NEW
                      ),
                    );
                  },
                ),
                const SizedBox(height: 10),
                _actionBtn(
                  icon: Icons.cancel_outlined,
                  label: _busy ? 'Cancelling...' : 'Cancel Reservation',
                  onTap: _busy ? null : _cancelReservation,
                ),
              ] else ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white10,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: const Text(
                    'No actions available for this session state.',
                    style: TextStyle(color: Colors.white70),
                  ),
                ),
              ],

              const SizedBox(height: 16),
              _actionBtn(
                icon: Icons.info_outline,
                label: 'View / Edit details',
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (_) => _EditBookingDetailsDialog(
                      branchId: widget.branchId,
                      sessionId: widget.sessionId,
                      initialData: widget.data,
                      enableReschedule: false, // basic edit
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),
              const Text(
                'Smart close: postpaid sessions without orders are auto-closed to Pending.',
                style: TextStyle(fontSize: 11, color: Colors.white38),
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Close'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 42,
      child: ElevatedButton.icon(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF111827),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
          elevation: 0,
        ),
        icon: Icon(icon, size: 18),
        label: Text(label),
      ),
    );
  }
}

// ---------------- EDIT BOOKING DETAILS ----------------
class _EditBookingDetailsDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> initialData;
  final bool enableReschedule; // NEW

  const _EditBookingDetailsDialog({
    required this.branchId,
    required this.sessionId,
    required this.initialData,
    required this.enableReschedule,
  });

  @override
  State<_EditBookingDetailsDialog> createState() =>
      _EditBookingDetailsDialogState();
}

class _EditBookingDetailsDialogState
    extends State<_EditBookingDetailsDialog> {
  late TextEditingController _nameCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _paxCtrl;
  late TextEditingController _gamePrefCtrl;
  late TextEditingController _notesCtrl;

  String _paymentType = 'postpaid';
  int _durationMinutes = 60;
  bool _saving = false;

  // Reschedule (date/time) — shown only when enableReschedule == true
  late DateTime _date;
  late TimeOfDay _time;

  final List<int> _durationOptions = [30, 60, 90, 120, 150, 180, 240, 300];

  @override
  void initState() {
    super.initState();
    final d = widget.initialData;

    _nameCtrl =
        TextEditingController(text: (d['customerName'] ?? '').toString());
    _phoneCtrl =
        TextEditingController(text: (d['customerPhone'] ?? '').toString());
    _paxCtrl =
        TextEditingController(text: d['pax'] != null ? d['pax'].toString() : '');
    _gamePrefCtrl =
        TextEditingController(text: (d['gamePreference'] ?? '').toString());
    _notesCtrl = TextEditingController(text: (d['notes'] ?? '').toString());

    _paymentType = (d['paymentType'] ?? 'postpaid').toString();
    _durationMinutes =
        (d['durationMinutes'] as num?)?.toInt() ?? _durationMinutes;

    // init reschedule fields
    final DateTime start =
        (d['startTime'] as Timestamp?)?.toDate() ?? DateTime.now();
    _date = DateTime(start.year, start.month, start.day);
    _time = TimeOfDay(hour: start.hour, minute: start.minute);

    if (!_durationOptions.contains(_durationMinutes)) {
      _durationOptions.add(_durationMinutes);
      _durationOptions.sort();
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _paxCtrl.dispose();
    _gamePrefCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canReschedule = widget.enableReschedule;

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(18),
        child: SingleChildScrollView(
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Booking Details',
                  style:
                      TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                ),
                const SizedBox(height: 12),

                // Customer meta
                TextField(
                  controller: _nameCtrl,
                  decoration: _darkInput('Customer name'),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _phoneCtrl,
                  decoration: _darkInput('Customer phone'),
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _paxCtrl,
                  decoration: _darkInput('Pax (optional)'),
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _gamePrefCtrl,
                  decoration:
                      _darkInput('Game preference (optional)'),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 10),

                // Billing meta
                DropdownButtonFormField<String>(
                  value: _paymentType,
                  dropdownColor: const Color(0xFF111827),
                  style: const TextStyle(color: Colors.white),
                  decoration: _darkInput('Payment type'),
                  items: const [
                    DropdownMenuItem(
                        value: 'prepaid', child: Text('Prepaid')),
                    DropdownMenuItem(
                        value: 'postpaid', child: Text('Postpaid')),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _paymentType = v);
                  },
                ),
                const SizedBox(height: 10),

                // Duration (always editable)
                DropdownButtonFormField<int>(
                  value: _durationMinutes,
                  dropdownColor: const Color(0xFF111827),
                  style: const TextStyle(color: Colors.white),
                  decoration: _darkInput('Duration'),
                  items: _durationOptions
                      .map((m) => DropdownMenuItem(
                            value: m,
                            child: Text('$m minutes'),
                          ))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _durationMinutes = v);
                  },
                ),
                const SizedBox(height: 10),

                // Reschedule block (only for future reserved)
                if (canReschedule) ...[
                  Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: _pickDate,
                          child: InputDecorator(
                            decoration: _darkInput('New date'),
                            child: Text(
                              '${_date.year}-${_date.month.toString().padLeft(2, '0')}-${_date.day.toString().padLeft(2, '0')}',
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: InkWell(
                          onTap: _pickTime,
                          child: InputDecorator(
                            decoration: _darkInput('New time'),
                            child: Text(_time.format(context)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: const Text(
                      'Reschedule updates the start time & duration for this reservation. '
                      'We’ll block overlaps on the current seat.',
                      style: TextStyle(fontSize: 12, color: Colors.white70),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],

                TextField(
                  controller: _notesCtrl,
                  decoration: _darkInput('Notes'),
                  style: const TextStyle(color: Colors.white),
                  maxLines: 2,
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 42,
                        child: ElevatedButton(
                          onPressed: _saving ? null : _save,
                          child: _saving
                              ? const CircularProgressIndicator()
                              : Text(canReschedule ? 'Save & Reschedule' : 'Save changes'),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _darkInput(String label) {
    return const InputDecoration(
      labelText: null,
      border: OutlineInputBorder(),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white24),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
    ).copyWith(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 30)),
      initialDate: _date,
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _time,
    );
    if (picked != null) setState(() => _time = picked);
  }

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty) return;

    setState(() => _saving = true);

    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    int? pax;
    if (_paxCtrl.text.trim().isNotEmpty) {
      pax = int.tryParse(_paxCtrl.text.trim());
    }

    // base updates
    final baseUpdate = {
      'customerName': _nameCtrl.text.trim(),
      'customerPhone': _phoneCtrl.text.trim(),
      'pax': pax,
      'gamePreference': _gamePrefCtrl.text.trim(),
      'notes': _notesCtrl.text.trim(),
      'paymentType': _paymentType,
      'durationMinutes': _durationMinutes,
      'updatedAt': FieldValue.serverTimestamp(),
    };

    // If rescheduling, ensure no overlap on the same seat
    if (widget.enableReschedule) {
      final start = DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute);
      final end = start.add(Duration(minutes: _durationMinutes));

      // fetch current session to know seatId
      final currentSnap = await docRef.get();
      final current = (currentSnap.data() ?? {}) as Map<String, dynamic>;
      final seatId = (current['seatId'] ?? '').toString();

      if (seatId.isNotEmpty) {
        final fs = FirebaseFirestore.instance;
        final sessionsCol = fs.collection('branches').doc(widget.branchId).collection('sessions');

        final seatSessionsSnap = await sessionsCol
            .where('seatId', isEqualTo: seatId)
            .get();

        bool hasOverlap = false;
        for (final doc in seatSessionsSnap.docs) {
          if (doc.id == widget.sessionId) continue; // ignore self
          final data = doc.data() as Map<String, dynamic>;
          final status = (data['status'] ?? '').toString();
          if (status != 'active' && status != 'reserved') continue;

          final otherStart = (data['startTime'] as Timestamp?)?.toDate();
          final otherDur = (data['durationMinutes'] as num?)?.toInt() ?? 0;
          if (otherStart == null) continue;

          final otherEnd = otherStart.add(Duration(minutes: otherDur));
          final overlaps = otherStart.isBefore(end) && otherEnd.isAfter(start);
          if (overlaps) {
            hasOverlap = true;
            break;
          }
        }

        if (hasOverlap) {
          if (mounted) {
            setState(() => _saving = false);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Overlap detected with another booking on this seat.')),
            );
          }
          return;
        }
      }

      baseUpdate['startTime'] = Timestamp.fromDate(start);
      baseUpdate['status'] = 'reserved'; // keep as reservation
    }

    await docRef.update(baseUpdate);

    if (!mounted) return;
    setState(() => _saving = false);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(widget.enableReschedule ? 'Reservation rescheduled' : 'Booking details updated')),
    );
  }
}
