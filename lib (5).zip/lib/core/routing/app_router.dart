import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../features/auth/login_screen.dart';
import '../../features/auth/bootstrap_superadmin_screen.dart';
import '../../features/auth/change_password_screen.dart'; // <-- add this
import '../../features/dashboard/admin_dashboard_screen.dart';
import '../../features/branches/branches_screen.dart';
import '../../features/bookings/bookings_screen.dart';
import '../../features/inventory/inventory_screen.dart';
import '../../features/reports/reports_screen.dart';
import '../../features/billing/invoices_screen.dart';
import '../../features/user/user_management_screen.dart';
import '../../features/sessions/live_sessions_screen.dart';
import '../../features/customers/customers_screen.dart';
import '../../features/inventory/inventory_logs_screen.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/login',
    redirect: (context, state) async {
      final user = FirebaseAuth.instance.currentUser;
      final path = state.matchedLocation;

      final loggingIn = path == '/login';
      final bootstrapping = path == '/bootstrap-admin';
      final changingPassword = path == '/change-password';

      // 1) not logged in → only /login or /bootstrap-admin allowed
      if (user == null && !loggingIn && !bootstrapping) {
        return '/login';
      }

      // 2) logged in but trying to go to /login → send to dashboard
      if (user != null && loggingIn) {
        // we may still force them to change password though
        // but handle that below after we fetch user doc
      }

      // we'll need the user doc for role + mustChangePassword
      Map<String, dynamic>? userData;
      String role = 'staff';
      bool mustChangePassword = false;

      if (user != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        userData = userDoc.data();
        role = (userData?['role'] ?? 'staff').toString();
        mustChangePassword = (userData?['mustChangePassword'] == true);
      }

      // 3) force "must change password"
      // user is logged in, their doc says mustChangePassword == true,
      // and they are not already on /change-password --> send there
      if (user != null && mustChangePassword && !changingPassword) {
        return '/change-password';
      }

      // if they are on /change-password and mustChangePassword is true → allow
      if (user != null && mustChangePassword && changingPassword) {
        return null;
      }

      // 4) logged in but visiting /login → now we can safely send to /dashboard
      if (user != null && loggingIn) {
        return '/dashboard';
      }

      // 5) role-based route guard for admin-only routes
      const adminOnlyPaths = <String>{
        '/branches',
        '/inventory',
        '/inventory-logs',
        '/reports',
        '/users',
        '/invoices',
      };

      if (user != null && adminOnlyPaths.contains(path)) {
        // allow admins/managers/superadmin
        if (role == 'admin' || role == 'manager' || role == 'superadmin') {
          return null;
        }
        // staff trying to access admin route -> push to dashboard
        return '/dashboard';
      }

      return null;
    },
    routes: [
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/bootstrap-admin',
        name: 'bootstrap-admin',
        builder: (context, state) => const BootstrapSuperAdminScreen(),
      ),
      GoRoute(
        path: '/change-password',
        name: 'change-password',
        builder: (context, state) => const ChangePasswordScreen(),
      ),
      GoRoute(
        path: '/dashboard',
        name: 'dashboard',
        builder: (context, state) => const AdminDashboardScreen(),
      ),
      GoRoute(
        path: '/branches',
        name: 'branches',
        builder: (context, state) => const BranchesScreen(),
      ),
      GoRoute(
        path: '/bookings',
        name: 'bookings',
        builder: (context, state) => const BookingsScreen(),
      ),
      GoRoute(
        path: '/live-sessions',
        name: 'live-sessions',
        builder: (context, state) => const LiveSessionsScreen(),
      ),
      GoRoute(
        path: '/customers',
        name: 'customers',
        builder: (context, state) => const CustomersScreen(),
      ),
      GoRoute(
        path: '/inventory',
        name: 'inventory',
        builder: (context, state) => const InventoryScreen(),
      ),
      GoRoute(
        path: '/inventory-logs',
        name: 'inventory-logs',
        builder: (context, state) => const InventoryLogsScreen(),
      ),
      GoRoute(
        path: '/reports',
        name: 'reports',
        builder: (context, state) => const ReportsScreen(),
      ),
      GoRoute(
        path: '/invoices',
        name: 'invoices',
        builder: (context, state) => const InvoicesScreen(),
      ),
      GoRoute(
        path: '/users',
        name: 'users',
        builder: (context, state) => const UserManagementScreen(),
      ),
    ],
  );
}
