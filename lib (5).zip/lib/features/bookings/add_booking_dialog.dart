import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AddBookingDialog extends StatefulWidget {
  const AddBookingDialog({super.key});

  @override
  State<AddBookingDialog> createState() => _AddBookingDialogState();
}

class _AddBookingDialogState extends State<AddBookingDialog> {
  String? _selectedBranchId;
  String? _selectedBranchName;
  String? _selectedSeatId;
  String? _selectedSeatLabel;

  final _customerNameCtrl = TextEditingController();
  final _customerPhoneCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  // NEW
  final _paxCtrl = TextEditingController();
  final _gamePrefCtrl = TextEditingController();
  String _paymentType = 'postpaid'; // prepaid | postpaid

  final List<int> _durationOptions =
      const [30, 60, 90, 120, 150, 180, 240, 300];
  int _selectedDuration = 60;

  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _saving = false;

  @override
  Widget build(BuildContext context) {
    final branchesCol = FirebaseFirestore.instance.collection('branches');

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(18),
        child: SingleChildScrollView(
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Create Booking',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                ),
                const SizedBox(height: 14),
                // branch
                StreamBuilder<QuerySnapshot>(
                  stream: branchesCol.snapshots(),
                  builder: (context, snapshot) {
                    final items = snapshot.hasData
                        ? snapshot.data!.docs
                        : <QueryDocumentSnapshot>[];
                    return DropdownButtonFormField<String>(
                      value: _selectedBranchId,
                      dropdownColor: const Color(0xFF111827),
                      style: const TextStyle(color: Colors.white),
                      decoration: _darkInput('Select branch'),
                      items: items.map((d) {
                        return DropdownMenuItem(
                          value: d.id,
                          child: Text(d['name'] ?? 'Branch'),
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          _selectedBranchId = v;
                          if (v != null) {
                            final doc = items.firstWhere((e) => e.id == v);
                            _selectedBranchName = doc['name'] ?? '';
                          } else {
                            _selectedBranchName = null;
                          }
                          _selectedSeatId = null;
                          _selectedSeatLabel = null;
                        });
                      },
                    );
                  },
                ),
                const SizedBox(height: 10),
                // seat
                if (_selectedBranchId != null)
                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('branches')
                        .doc(_selectedBranchId)
                        .collection('seats')
                        .where('active', isEqualTo: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      final seatDocs = snapshot.hasData
                          ? snapshot.data!.docs
                          : <QueryDocumentSnapshot>[];
                      return DropdownButtonFormField<String>(
                        value: _selectedSeatId,
                        dropdownColor: const Color(0xFF111827),
                        style: const TextStyle(color: Colors.white),
                        decoration: _darkInput('Select seat'),
                        items: seatDocs.map((d) {
                          return DropdownMenuItem(
                            value: d.id,
                            child:
                                Text('${d['label']} • ₹${d['ratePerHour']}/hr'),
                          );
                        }).toList(),
                        onChanged: (v) {
                          setState(() {
                            _selectedSeatId = v;
                            final doc = seatDocs.firstWhere((e) => e.id == v);
                            _selectedSeatLabel = doc['label'] ?? '';
                          });
                        },
                      );
                    },
                  ),
                const SizedBox(height: 10),
                TextField(
                  controller: _customerNameCtrl,
                  decoration: _darkTextField('Customer name'),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _customerPhoneCtrl,
                  decoration: _darkTextField('Customer phone (optional)'),
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _paxCtrl,
                  decoration: _darkTextField('Pax (optional)'),
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _gamePrefCtrl,
                  decoration: _darkTextField('Game preference (optional)'),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: _paymentType,
                  dropdownColor: const Color(0xFF111827),
                  style: const TextStyle(color: Colors.white),
                  decoration: _darkInput('Payment type'),
                  items: const [
                    DropdownMenuItem(value: 'prepaid', child: Text('Prepaid')),
                    DropdownMenuItem(
                        value: 'postpaid', child: Text('Postpaid')),
                  ],
                  onChanged: (v) {
                    if (v != null) {
                      setState(() => _paymentType = v);
                    }
                  },
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: _pickDate,
                        child: InputDecorator(
                          decoration: _darkInput('Date'),
                          child: Text(
                            '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: InkWell(
                        onTap: _pickTime,
                        child: InputDecorator(
                          decoration: _darkInput('Time'),
                          child: Text(_selectedTime.format(context)),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<int>(
                  value: _selectedDuration,
                  dropdownColor: const Color(0xFF111827),
                  style: const TextStyle(color: Colors.white),
                  decoration: _darkInput('Duration'),
                  items: _durationOptions
                      .map((m) =>
                          DropdownMenuItem(value: m, child: Text('$m minutes')))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() => _selectedDuration = v);
                    }
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _notesCtrl,
                  decoration: _darkTextField('Notes'),
                  style: const TextStyle(color: Colors.white),
                  maxLines: 2,
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 42,
                  child: ElevatedButton(
                    onPressed: _saving ? null : _save,
                    child: _saving
                        ? const CircularProgressIndicator()
                        : const Text('Create'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _darkInput(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      border: const OutlineInputBorder(),
      enabledBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white24),
      ),
      focusedBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.white),
      ),
    );
  }

  InputDecoration _darkTextField(String label) => _darkInput(label);

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 30)),
      initialDate: _selectedDate,
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null) {
      setState(() => _selectedTime = picked);
    }
  }

  Future<void> _save() async {
    if (_selectedBranchId == null || _selectedSeatId == null) return;
    if (_customerNameCtrl.text.trim().isEmpty) return;

    setState(() => _saving = true);

    // combine date + time
    final start = DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      _selectedTime.hour,
      _selectedTime.minute,
    );
    final end = start.add(Duration(minutes: _selectedDuration));

    final sessionsCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(_selectedBranchId)
        .collection('sessions');

    // OVERLAP CHECK
    final activeSnap = await sessionsCol
        .where('status', isEqualTo: 'active')
        .where('seatId', isEqualTo: _selectedSeatId)
        .get();

    bool hasOverlap = false;
    for (final doc in activeSnap.docs) {
      final data = doc.data();
      final otherStart = (data['startTime'] as Timestamp?)?.toDate();
      final otherDuration = (data['durationMinutes'] ?? 0) as int;
      if (otherStart == null) continue;
      final otherEnd = otherStart.add(Duration(minutes: otherDuration));

      final overlaps = otherStart.isBefore(end) && otherEnd.isAfter(start);
      if (overlaps) {
        hasOverlap = true;
        break;
      }
    }

    if (hasOverlap) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Seat already booked in that time slot')),
        );
      }
      return;
    }

    final now = DateTime.now();
    final isFuture = start.isAfter(now);

    // NEW: get staff (current user)
    final currentUser = FirebaseAuth.instance.currentUser;
    String? createdByName;

    if (currentUser != null) {
      // try get from users collection
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      if (userDoc.exists) {
        createdByName =
            (userDoc.data() as Map<String, dynamic>?)?['name']?.toString();
      }
    }

    await sessionsCol.add({
      'customerName': _customerNameCtrl.text.trim(),
      'customerPhone': _customerPhoneCtrl.text.trim(),
      'branchId': _selectedBranchId,
      'branchName': _selectedBranchName,
      'seatId': _selectedSeatId,
      'seatLabel': _selectedSeatLabel,
      'startTime': Timestamp.fromDate(start),
      'durationMinutes': _selectedDuration,
      'pax': _paxCtrl.text.trim().isEmpty
          ? null
          : int.tryParse(_paxCtrl.text.trim()),
      'gamePreference': _gamePrefCtrl.text.trim(),
      'paymentType': _paymentType,
      'status': isFuture ? 'reserved' : 'active',
      'notes': _notesCtrl.text.trim(),
      // staff tracking
      if (currentUser != null) 'createdBy': currentUser.uid,
      if (createdByName != null) 'createdByName': createdByName,
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) Navigator.of(context).pop();
  }
}
