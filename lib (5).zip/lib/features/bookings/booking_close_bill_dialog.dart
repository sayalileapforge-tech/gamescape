import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class BookingCloseBillDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingCloseBillDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingCloseBillDialog> createState() => _BookingCloseBillDialogState();
}

class _BookingCloseBillDialogState extends State<BookingCloseBillDialog> {
  bool _loading = true;
  num _ordersTotal = 0;
  num _sessionTotal = 0;
  num _grandTotal = 0;
  int _playedMinutes = 0;
  List<Map<String, dynamic>> _orders = [];
  List<Map<String, dynamic>> _segments = [];

  final TextEditingController _discountCtrl = TextEditingController(text: '0');
  final TextEditingController _taxPercentCtrl = TextEditingController(text: '0');

  List<_PaymentLine> _payments = [];

  @override
  void initState() {
    super.initState();
    _loadBill();
  }

  Future<void> _loadBill() async {
    final sessionData = widget.data;
    final branchId = widget.branchId;
    final startTime = (sessionData['startTime'] as Timestamp?)?.toDate();
    final currentSeatId = sessionData['seatId'] as String?;

    final ordersSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('orders')
        .get();
    num ordersTotal = 0;
    final ordersList = <Map<String, dynamic>>[];
    for (final doc in ordersSnap.docs) {
      final d = doc.data();
      ordersTotal += (d['total'] ?? 0) as num;
      ordersList.add(d);
    }

    final seatChangesSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .collection('seat_changes')
        .orderBy('changedAt')
        .get();

    final now = DateTime.now();
    final segments = <Map<String, dynamic>>[];

    if (startTime != null) {
      DateTime lastFrom = startTime;
      String? lastSeat = currentSeatId;

      if (seatChangesSnap.docs.isEmpty) {
        segments.add({'seatId': currentSeatId, 'from': startTime, 'to': now});
      } else {
        for (final sc in seatChangesSnap.docs) {
          final data = sc.data();
          final changedAt = (data['changedAt'] as Timestamp?)?.toDate();
          final toSeatId = data['toSeatId'] as String?;
          if (changedAt != null) {
            segments.add({
              'seatId': lastSeat,
              'from': lastFrom,
              'to': changedAt,
            });
            lastFrom = changedAt;
            lastSeat = toSeatId;
          }
        }
        segments.add({'seatId': lastSeat, 'from': lastFrom, 'to': now});
      }
    }

    num sessionTotal = 0;
    int totalPlayed = 0;
    final computedSegments = <Map<String, dynamic>>[];

    for (final seg in segments) {
      final seatId = seg['seatId'] as String?;
      final from = seg['from'] as DateTime;
      final to = seg['to'] as DateTime;
      final mins = to.difference(from).inMinutes.clamp(0, 9999);
      totalPlayed += mins;

      num ratePerHour = 0;
      if (seatId != null) {
        final seatSnap = await FirebaseFirestore.instance
            .collection('branches')
            .doc(branchId)
            .collection('seats')
            .doc(seatId)
            .get();
        ratePerHour = (seatSnap.data()?['ratePerHour'] ?? 0) as num;
      }

      final segTotal = ratePerHour * (mins / 60);
      sessionTotal += segTotal;
      computedSegments.add({
        'seatId': seatId,
        'minutes': mins,
        'ratePerHour': ratePerHour,
        'total': segTotal,
      });
    }

    final baseTotal = ordersTotal + sessionTotal;

    setState(() {
      _ordersTotal = ordersTotal;
      _sessionTotal = sessionTotal;
      _segments = computedSegments;
      _playedMinutes = totalPlayed;
      _orders = ordersList;
      _loading = false;
      _payments = [
        _PaymentLine(mode: 'Cash', amount: baseTotal.toDouble()),
      ];
      _grandTotal = baseTotal;
    });
  }

  num _calcGrandTotal() {
    final discount = num.tryParse(_discountCtrl.text.trim()) ?? 0;
    final taxPercent = num.tryParse(_taxPercentCtrl.text.trim()) ?? 0;

    final subTotal = _ordersTotal + _sessionTotal;
    final afterDiscount = (subTotal - discount).clamp(0, 999999);
    final taxAmount = afterDiscount * (taxPercent / 100);
    return afterDiscount + taxAmount;
  }

  void _recalcAndFixPayment() {
    final newGrand = _calcGrandTotal();
    setState(() {
      _grandTotal = newGrand;
      final currentSum =
          _payments.fold<double>(0, (prev, e) => prev + (e.amount ?? 0));
      if (currentSum == 0 && _payments.isNotEmpty) {
        _payments[0] = _payments[0].copyWith(amount: newGrand.toDouble());
      }
    });
  }

  Future<void> _closeSession() async {
    final discount = num.tryParse(_discountCtrl.text.trim()) ?? 0;
    final taxPercent = num.tryParse(_taxPercentCtrl.text.trim()) ?? 0;
    final subTotal = (_ordersTotal + _sessionTotal) - discount;
    final fixedSubTotal = subTotal < 0 ? 0 : subTotal;
    final taxAmount = fixedSubTotal * (taxPercent / 100);
    final grandTotal = fixedSubTotal + taxAmount;

    final invoiceNumber =
        'GS-INV-${DateTime.now().year}-${DateTime.now().millisecondsSinceEpoch}';

    final paymentsJson = _payments
        .where((p) => (p.amount ?? 0) > 0)
        .map((p) => {
              'mode': p.mode,
              'amount': p.amount,
            })
        .toList();

    final totalPaid = paymentsJson.fold<num>(
        0, (prev, e) => prev + ((e['amount'] as num?) ?? 0));
    final paymentStatus =
        totalPaid >= grandTotal ? 'paid' : 'pending';

    final currentUser = FirebaseAuth.instance.currentUser;
    String? closedByName;
    if (currentUser != null) {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      if (userDoc.exists) {
        closedByName =
            (userDoc.data()?['name'] as String?) ?? currentUser.email;
      }
    }

    await FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId)
        .update({
      'status': 'completed',
      'paymentStatus': paymentStatus,
      'closedAt': FieldValue.serverTimestamp(),
      'billAmount': grandTotal,
      'subtotal': fixedSubTotal,
      'taxPercent': taxPercent,
      'taxAmount': taxAmount,
      'playedMinutes': _playedMinutes,
      'invoiceNumber': invoiceNumber,
      'discount': discount,
      'payments': paymentsJson,
      if (currentUser != null) 'closedBy': currentUser.uid,
      if (closedByName != null) 'closedByName': closedByName,
    });

    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      child: Container(
        width: 480,
        padding: const EdgeInsets.all(18),
        child: _loading
            ? const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              )
            : SingleChildScrollView(
                child: DefaultTextStyle(
                  style: const TextStyle(color: Colors.white),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Close & Bill',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text('Played: $_playedMinutes minutes'),
                      const SizedBox(height: 8),
                      const Text('Session segments:'),
                      if (_segments.isEmpty)
                        const Text('• Single seat session'),
                      ..._segments.map((s) {
                        final seatId = s['seatId'] ?? 'Seat';
                        final mins = s['minutes'];
                        final rate = s['ratePerHour'];
                        final total =
                            (s['total'] as num).toStringAsFixed(2);
                        return Text(
                            '• $seatId : $mins mins × ₹$rate/hr = ₹$total');
                      }),
                      const SizedBox(height: 8),
                      Text(
                        'Session total: ₹${_sessionTotal.toStringAsFixed(2)}',
                      ),
                      const SizedBox(height: 8),
                      const Text('Orders:'),
                      if (_orders.isEmpty) const Text('• No orders added'),
                      if (_orders.isNotEmpty)
                        ..._orders.map((o) {
                          final name = o['itemName'] ?? '';
                          final qty = o['qty'] ?? 0;
                          final total = o['total'] ?? 0;
                          return Text('• $name x$qty → ₹$total');
                        }),
                      const SizedBox(height: 8),
                      Text('Orders total: ₹${_ordersTotal.toStringAsFixed(2)}'),
                      const Divider(color: Colors.white30),
                      const Text(
                        'Adjustments',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _discountCtrl,
                              onChanged: (_) => _recalcAndFixPayment(),
                              decoration: const InputDecoration(
                                labelText: 'Discount (₹)',
                                labelStyle: TextStyle(color: Colors.white70),
                                enabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.white24),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                ),
                              ),
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: _taxPercentCtrl,
                              onChanged: (_) => _recalcAndFixPayment(),
                              decoration: const InputDecoration(
                                labelText: 'Tax %',
                                labelStyle: TextStyle(color: Colors.white70),
                                enabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.white24),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white),
                                ),
                              ),
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Payments',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      ..._payments.asMap().entries.map((entry) {
                        final idx = entry.key;
                        final line = entry.value;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 110,
                                child: DropdownButtonFormField<String>(
                                  value: line.mode,
                                  dropdownColor: const Color(0xFF111827),
                                  style: const TextStyle(color: Colors.white),
                                  decoration: const InputDecoration(
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white24),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.white),
                                    ),
                                  ),
                                  items: const [
                                    DropdownMenuItem(
                                        value: 'Cash', child: Text('Cash')),
                                    DropdownMenuItem(
                                        value: 'UPI', child: Text('UPI')),
                                    DropdownMenuItem(
                                        value: 'Card', child: Text('Card')),
                                    DropdownMenuItem(
                                        value: 'Other', child: Text('Other')),
                                  ],
                                  onChanged: (v) {
                                    if (v == null) return;
                                    setState(() {
                                      _payments[idx] =
                                          line.copyWith(mode: v);
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: TextField(
                                  controller: line.amountController,
                                  onChanged: (txt) {
                                    final val = double.tryParse(txt) ?? 0;
                                    setState(() {
                                      _payments[idx] =
                                          line.copyWith(amount: val);
                                    });
                                  },
                                  decoration: const InputDecoration(
                                    labelText: 'Amount',
                                    labelStyle:
                                        TextStyle(color: Colors.white70),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white24),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.white),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  keyboardType: TextInputType.number,
                                ),
                              ),
                              const SizedBox(width: 6),
                              if (_payments.length > 1)
                                IconButton(
                                  onPressed: () {
                                    setState(() {
                                      _payments.removeAt(idx);
                                    });
                                  },
                                  icon: const Icon(Icons.delete,
                                      color: Colors.redAccent),
                                ),
                            ],
                          ),
                        );
                      }),
                      const SizedBox(height: 6),
                      TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _payments.add(
                                _PaymentLine(mode: 'Cash', amount: 0));
                          });
                        },
                        icon: const Icon(Icons.add, color: Colors.white),
                        label: const Text('Add payment line'),
                      ),
                      const Divider(color: Colors.white30),
                      Text(
                        'Grand total: ₹${_grandTotal.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _closeSession,
                          child: const Text('Close session'),
                        ),
                      ),
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Cancel'),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class _PaymentLine {
  final String mode;
  final double? amount;
  final TextEditingController amountController;

  _PaymentLine({
    required this.mode,
    double? amount,
  })  : amount = amount,
        amountController = TextEditingController(
          text: amount != null ? amount.toStringAsFixed(2) : '',
        );

  _PaymentLine copyWith({
    String? mode,
    double? amount,
  }) {
    return _PaymentLine(
      mode: mode ?? this.mode,
      amount: amount ?? this.amount,
    );
  }
}
