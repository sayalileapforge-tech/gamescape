import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SideNav extends StatefulWidget {
  const SideNav({super.key});

  @override
  State<SideNav> createState() => _SideNavState();
}

class _SideNavState extends State<SideNav> {
  bool _isExpanded = false;

  void _toggleExpanded() {
    setState(() => _isExpanded = !_isExpanded);
  }

  @override
  Widget build(BuildContext context) {
    final width = _isExpanded ? 200.0 : 70.0;
    final uid = FirebaseAuth.instance.currentUser?.uid;

    if (uid == null) {
      return _buildBare(width);
    }

    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
      builder: (context, snapshot) {
        final role = snapshot.data?.get('role') as String? ?? 'staff';
        final isAdminLike = role == 'admin' || role == 'manager';

        return AnimatedContainer(
          width: width,
          duration: const Duration(milliseconds: 250),
          color: Colors.black,
          child: Column(
            crossAxisAlignment:
                _isExpanded ? CrossAxisAlignment.start : CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 12),
              Align(
                alignment: _isExpanded ? Alignment.centerRight : Alignment.center,
                child: IconButton(
                  onPressed: _toggleExpanded,
                  icon: Icon(
                    _isExpanded
                        ? Icons.arrow_back_ios_new_rounded
                        : Icons.arrow_forward_ios_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: const Text(
                  'G',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
                ),
              ),
              const SizedBox(height: 26),
              _NavTile(
                icon: Icons.dashboard_outlined,
                label: 'Dashboard',
                expanded: _isExpanded,
                onTap: () => context.go('/dashboard'),
              ),
              if (isAdminLike)
                _NavTile(
                  icon: Icons.home_work_outlined,
                  label: 'Branches',
                  expanded: _isExpanded,
                  onTap: () => context.go('/branches'),
                ),
              _NavTile(
                icon: Icons.chair_outlined,
                label: 'Bookings',
                expanded: _isExpanded,
                onTap: () => context.go('/bookings'),
              ),
              _NavTile(
                icon: Icons.live_tv_outlined,
                label: 'Live Sessions',
                expanded: _isExpanded,
                onTap: () => context.go('/live-sessions'),
              ),
              _NavTile(
                icon: Icons.person_outline,
                label: 'Customers',
                expanded: _isExpanded,
                onTap: () => context.go('/customers'),
              ),
              if (isAdminLike)
                _NavTile(
                  icon: Icons.inventory_2_outlined,
                  label: 'Inventory',
                  expanded: _isExpanded,
                  onTap: () => context.go('/inventory'),
                ),
              if (isAdminLike)
                _NavTile(
                  icon: Icons.list_alt_outlined,
                  label: 'Inventory Logs',
                  expanded: _isExpanded,
                  onTap: () => context.go('/inventory-logs'),
                ),
              if (isAdminLike)
                _NavTile(
                  icon: Icons.group_outlined,
                  label: 'Users',
                  expanded: _isExpanded,
                  onTap: () => context.go('/users'),
                ),
              if (isAdminLike)
                _NavTile(
                  icon: Icons.receipt_long_outlined,
                  label: 'Reports',
                  expanded: _isExpanded,
                  onTap: () => context.go('/reports'),
                ),
              if (isAdminLike)
                _NavTile(
                  icon: Icons.picture_as_pdf_outlined,
                  label: 'Invoices',
                  expanded: _isExpanded,
                  onTap: () => context.go('/invoices'),
                ),
              const Spacer(),
              _NavTile(
                icon: Icons.logout,
                label: 'Logout',
                expanded: _isExpanded,
                onTap: () async {
                  await FirebaseAuth.instance.signOut();
                  if (context.mounted) context.go('/login');
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBare(double width) {
    return AnimatedContainer(
      width: width,
      duration: const Duration(milliseconds: 250),
      color: Colors.black,
      child: Column(
        children: [
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.center,
            child: IconButton(
              onPressed: _toggleExpanded,
              icon: Icon(
                _isExpanded
                    ? Icons.arrow_back_ios_new_rounded
                    : Icons.arrow_forward_ios_rounded,
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool expanded;

  const _NavTile({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.expanded,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: expanded ? 10 : 0),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment:
              expanded ? MainAxisAlignment.start : MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            if (expanded) const SizedBox(width: 10),
            if (expanded)
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
