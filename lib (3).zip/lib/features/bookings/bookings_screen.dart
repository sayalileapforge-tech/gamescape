import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import 'add_booking_dialog.dart';
import 'booking_actions_dialog.dart';
import 'booking_timeline_view.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  String? _selectedBranchId;
  String? _selectedBranchName;
  bool _showTimeline = false;
  String _statusFilter = 'active'; // active | completed | all
  bool _hideOverdue = false;

  @override
  Widget build(BuildContext context) {
    final branchesCol = FirebaseFirestore.instance.collection('branches');

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header + toggle + filter
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Bookings',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
              ),
              Row(
                children: [
                  DropdownButton<String>(
                    value: _statusFilter,
                    dropdownColor: const Color(0xFF111827),
                    style: const TextStyle(color: Colors.white),
                    items: const [
                      DropdownMenuItem(value: 'active', child: Text('Active')),
                      DropdownMenuItem(value: 'completed', child: Text('Completed')),
                      DropdownMenuItem(value: 'all', child: Text('All')),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() => _statusFilter = v);
                    },
                  ),
                  const SizedBox(width: 12),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(
                        value: false,
                        label: Text('List'),
                        icon: Icon(Icons.view_list),
                      ),
                      ButtonSegment(
                        value: true,
                        label: Text('Timeline'),
                        icon: Icon(Icons.timeline),
                      ),
                    ],
                    selected: {_showTimeline},
                    onSelectionChanged: (s) {
                      setState(() {
                        _showTimeline = s.first;
                      });
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          // branch + new booking
          Row(
            children: [
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: branchesCol.snapshots(),
                  builder: (context, snapshot) {
                    final items =
                        snapshot.hasData ? snapshot.data!.docs : <QueryDocumentSnapshot>[];
                    return DropdownButtonFormField<String>(
                      value: _selectedBranchId,
                      dropdownColor: const Color(0xFF111827),
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        labelText: 'Select branch',
                        border: OutlineInputBorder(),
                        labelStyle: TextStyle(color: Colors.white70),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white38),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      items: items.map((d) {
                        return DropdownMenuItem(
                          value: d.id,
                          child: Text(d['name'] ?? 'Branch'),
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          _selectedBranchId = v;
                          if (v != null) {
                            final doc = items.firstWhere((e) => e.id == v);
                            _selectedBranchName = doc['name'] ?? '';
                          } else {
                            _selectedBranchName = null;
                          }
                        });
                      },
                    );
                  },
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (_) => const AddBookingDialog(),
                  );
                },
                icon: const Icon(Icons.add),
                label: const Text('New Booking'),
              ),
              const SizedBox(width: 12),
              Row(
                children: [
                  const Text('Hide overdue', style: TextStyle(color: Colors.white70)),
                  Switch(
                    value: _hideOverdue,
                    onChanged: (v) {
                      setState(() => _hideOverdue = v);
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _selectedBranchId == null
                ? const Center(
                    child: Text(
                      'Select a branch to view bookings',
                      style: TextStyle(color: Colors.white70),
                    ),
                  )
                : StreamBuilder<QuerySnapshot>(
                    stream: _buildSessionsStream(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return const Center(
                            child: Text('No bookings found.',
                                style: TextStyle(color: Colors.white70)));
                      }

                      final docs = snapshot.data!.docs.reversed.toList();

                      if (_showTimeline) {
                        return BookingTimelineView(bookings: docs);
                      }

                      return ListView.separated(
                        itemCount: docs.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final d = docs[index];
                          final data = d.data() as Map<String, dynamic>;
                          final seatLabel = data['seatLabel'] ?? '';
                          final cust = data['customerName'] ?? '';
                          final started = (data['startTime'] as Timestamp?)?.toDate();
                          final durationMins = (data['durationMinutes'] ?? 0) as int;
                          final status = data['status'] ?? 'active';
                          final playedMinutes = data['playedMinutes'] as int?;
                          final paymentType = (data['paymentType'] ?? 'postpaid') as String;

                          bool isOverdue = false;
                          if (status == 'active' && started != null) {
                            final end = started.add(Duration(minutes: durationMins));
                            isOverdue = DateTime.now().isAfter(end);
                          }
                          if (_hideOverdue && isOverdue) {
                            return const SizedBox.shrink();
                          }

                          return Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1F2937),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: Colors.black,
                                  child: Text(
                                    seatLabel.isNotEmpty ? seatLabel[0] : '?',
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              cust,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 15,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                          // payment chip
                                          _PaymentChip(paymentType: paymentType),
                                        ],
                                      ),
                                      if (started != null)
                                        Text(
                                          'Seat: $seatLabel • ${started.toLocal()} • $status',
                                          style: TextStyle(
                                            color: Colors.grey.shade400,
                                          ),
                                        ),
                                      if (status == 'completed' && playedMinutes != null)
                                        Text(
                                          'Played: $playedMinutes minutes',
                                          style: const TextStyle(
                                            color: Colors.greenAccent,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )
                                      else if (started != null)
                                        BookingCountdown(
                                          endTime: started.add(
                                            Duration(minutes: durationMins),
                                          ),
                                        ),
                                      if (isOverdue)
                                        const Text(
                                          'Overdue',
                                          style: TextStyle(
                                            color: Colors.redAccent,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                ElevatedButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (_) => BookingActionsDialog(
                                        branchId: _selectedBranchId!,
                                        sessionId: d.id,
                                        data: data,
                                      ),
                                    );
                                  },
                                  child: const Text('Actions'),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Stream<QuerySnapshot> _buildSessionsStream() {
    Query q = FirebaseFirestore.instance
        .collection('branches')
        .doc(_selectedBranchId)
        .collection('sessions');

    if (_statusFilter == 'active') {
      q = q.where('status', isEqualTo: 'active');
    } else if (_statusFilter == 'completed') {
      q = q.where('status', isEqualTo: 'completed');
    }

    return q.snapshots();
  }
}

class _PaymentChip extends StatelessWidget {
  final String paymentType;
  const _PaymentChip({required this.paymentType});

  @override
  Widget build(BuildContext context) {
    Color bg;
    String label;
    if (paymentType == 'prepaid') {
      bg = Colors.blueAccent.withOpacity(0.2);
      label = 'Prepaid';
    } else {
      bg = Colors.greenAccent.withOpacity(0.2);
      label = 'Postpaid';
    }
    return Container(
      margin: const EdgeInsets.only(left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, fontSize: 11),
      ),
    );
  }
}

class BookingCountdown extends StatefulWidget {
  final DateTime endTime;
  const BookingCountdown({super.key, required this.endTime});

  @override
  State<BookingCountdown> createState() => _BookingCountdownState();
}

class _BookingCountdownState extends State<BookingCountdown> {
  late Timer _timer;
  late Duration _remaining;

  @override
  void initState() {
    super.initState();
    _remaining = widget.endTime.difference(DateTime.now()) +
        const Duration(seconds: 59);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      final diff = widget.endTime.difference(DateTime.now());
      if (diff.isNegative) {
        t.cancel();
      }
      if (mounted) {
        setState(() => _remaining = diff);
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _fmt(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final total = _remaining.isNegative ? Duration.zero : _remaining;
    final h = total.inHours;
    final m = total.inMinutes.remainder(60);
    final s = total.inSeconds.remainder(60);

    return Text(
      'Time left: ${_fmt(h)}:${_fmt(m)}:${_fmt(s)}',
      style: TextStyle(
        color: total.inMinutes < 5 ? Colors.redAccent : Colors.greenAccent,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}
