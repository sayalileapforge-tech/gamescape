import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'side_nav.dart';

class AppShell extends StatelessWidget {
  final Widget child;
  const AppShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    // not logged in – router will usually push /login
    if (currentUser == null) {
      return Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        body: Center(child: child),
      );
    }

    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .snapshots(),
      builder: (context, snap) {
        // 👇 default values while loading
        // IMPORTANT: do NOT default to "staff" here, that’s what was
        // hiding your admin items for a moment.
        String role = 'superadmin';
        String displayName = currentUser.email ?? 'User';

        if (snap.hasData && snap.data!.data() != null) {
          final data = snap.data!.data() as Map<String, dynamic>;
          role = (data['role'] ?? 'superadmin').toString();
          final name = (data['name'] ?? '').toString();
          if (name.isNotEmpty) {
            displayName = name;
          }
        }

        return Scaffold(
          backgroundColor: const Color(0xFF0F172A),
          body: Row(
            children: [
              // 👉 always show a full side nav using whatever role we have right now
              SideNav(role: role),
              Expanded(
                child: Column(
                  children: [
                    // top bar
                    Container(
                      height: 60,
                      color: const Color(0xFF111827),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      alignment: Alignment.centerRight,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'GameScape Admin',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                          ),
                          Row(
                            children: [
                              Text(
                                displayName,
                                style: const TextStyle(color: Colors.white),
                              ),
                              const SizedBox(width: 10),
                              const CircleAvatar(
                                radius: 18,
                                backgroundColor: AppTheme.primaryBlue,
                                child: Icon(Icons.person, color: Colors.white),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    // page content
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: child,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
