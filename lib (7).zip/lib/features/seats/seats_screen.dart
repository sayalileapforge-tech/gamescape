import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../data/models/seat_model.dart';

class SeatsScreen extends StatelessWidget {
  final String branchId;
  final String branchName;
  const SeatsScreen({
    super.key,
    required this.branchId,
    required this.branchName,
  });

  @override
  Widget build(BuildContext context) {
    final seatsCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('seats');

    return Dialog(
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Seats – $branchName',
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 14),
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton.icon(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (_) => AddEditSeatDialog(
                      branchId: branchId,
                    ),
                  );
                },
                icon: const Icon(Icons.add),
                label: const Text('Add Seat'),
              ),
            ),
            const SizedBox(height: 14),
            StreamBuilder<QuerySnapshot>(
              stream: seatsCol.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(20.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(20.0),
                    child: Text('No seats yet.'),
                  );
                }

                final docs = snapshot.data!.docs;

                return SizedBox(
                  height: 400,
                  child: ListView.separated(
                    itemCount: docs.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final d = docs[index];
                      final seat = SeatModel.fromMap(
                        d.id,
                        d.data() as Map<String, dynamic>,
                      );
                      return Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.black,
                              child: Text(
                                seat.label.isNotEmpty
                                    ? seat.label[0].toUpperCase()
                                    : '?',
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    seat.label,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                    ),
                                  ),
                                  Text(
                                    '${seat.type} • ₹${seat.ratePerHour}/hr',
                                    style: TextStyle(
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: seat.active
                                    ? Colors.green.withOpacity(0.1)
                                    : Colors.red.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                seat.active ? 'Active' : 'Inactive',
                                style: TextStyle(
                                  color: seat.active
                                      ? Colors.green.shade700
                                      : Colors.red.shade700,
                                ),
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (_) => AddEditSeatDialog(
                                    branchId: branchId,
                                    existing: seat,
                                  ),
                                );
                              },
                              icon: const Icon(Icons.edit),
                            ),
                            IconButton(
                              onPressed: () async {
                                await seatsCol.doc(seat.id).delete();
                              },
                              icon: const Icon(
                                Icons.delete_outline,
                                color: Colors.red,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class AddEditSeatDialog extends StatefulWidget {
  final String branchId;
  final SeatModel? existing;
  const AddEditSeatDialog({
    super.key,
    required this.branchId,
    this.existing,
  });

  @override
  State<AddEditSeatDialog> createState() => _AddEditSeatDialogState();
}

class _AddEditSeatDialogState extends State<AddEditSeatDialog> {
  final _labelCtrl = TextEditingController();
  final _typeCtrl = TextEditingController(text: 'Standard');
  final _rateCtrl = TextEditingController(text: '0');
  bool _active = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    if (widget.existing != null) {
      _labelCtrl.text = widget.existing!.label;
      _typeCtrl.text = widget.existing!.type;
      _rateCtrl.text = widget.existing!.ratePerHour.toString();
      _active = widget.existing!.active;
    }
  }

  Future<void> _save() async {
    if (_labelCtrl.text.trim().isEmpty) return;
    setState(() => _saving = true);
    final seatsCol = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('seats');

    final rate = num.tryParse(_rateCtrl.text.trim()) ?? 0;

    if (widget.existing == null) {
      await seatsCol.add({
        'label': _labelCtrl.text.trim(),
        'type': _typeCtrl.text.trim(),
        'ratePerHour': rate,
        'active': _active,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      await seatsCol.doc(widget.existing!.id).update({
        'label': _labelCtrl.text.trim(),
        'type': _typeCtrl.text.trim(),
        'ratePerHour': rate,
        'active': _active,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }

    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 380,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              widget.existing == null ? 'Add Seat' : 'Edit Seat',
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _labelCtrl,
              decoration: const InputDecoration(
                labelText: 'Seat label (e.g. PC-01)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _typeCtrl,
              decoration: const InputDecoration(
                labelText: 'Type (e.g. PC / Console / VIP)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _rateCtrl,
              decoration: const InputDecoration(
                labelText: 'Rate per hour (₹)',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 10),
            SwitchListTile(
              value: _active,
              onChanged: (v) => setState(() => _active = v),
              title: const Text('Active'),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 42,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const CircularProgressIndicator()
                    : const Text('Save'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
