import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'add_order_dialog.dart';
import 'booking_move_seat_dialog.dart';
import 'booking_close_bill_dialog.dart';

class BookingActionsDialog extends StatefulWidget {
  final String branchId;
  final String sessionId;
  final Map<String, dynamic> data;

  const BookingActionsDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.data,
  });

  @override
  State<BookingActionsDialog> createState() => _BookingActionsDialogState();
}

class _BookingActionsDialogState extends State<BookingActionsDialog> {
  bool _extending = false;

  Future<void> _extendBy(int minutes) async {
    setState(() => _extending = true);
    final docRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(widget.branchId)
        .collection('sessions')
        .doc(widget.sessionId);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      final current = snap.data() as Map<String, dynamic>;
      final currentDuration = (current['durationMinutes'] ?? 0) as int;
      tx.update(docRef, {
        'durationMinutes': currentDuration + minutes,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });

    if (mounted) {
      setState(() => _extending = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Extended by $minutes minutes')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cust = widget.data['customerName'] ?? '';
    final seatId = widget.data['seatId'] ?? '';
    final seat = widget.data['seatLabel'] ?? '';
    final duration = widget.data['durationMinutes'] ?? 0;

    return Dialog(
      backgroundColor: const Color(0xFF1F2937),
      insetPadding: const EdgeInsets.all(20),
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Booking Actions',
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: Colors.white),
            ),
            const SizedBox(height: 10),
            Text('Customer: $cust', style: const TextStyle(color: Colors.white)),
            Text('Seat: $seat', style: const TextStyle(color: Colors.white70)),
            Text('Duration: $duration mins',
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            _actionBtn(
              icon: Icons.add_alarm,
              label: _extending ? 'Extending...' : 'Extend by 30 mins',
              onTap: _extending ? null : () => _extendBy(30),
            ),
            const SizedBox(height: 10),
            _actionBtn(
              icon: Icons.add_shopping_cart_outlined,
              label: 'Add Order',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (_) => AddOrderDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            _actionBtn(
              icon: Icons.chair_outlined,
              label: 'Move Seat',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (_) => BookingMoveSeatDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    currentSeatId: seatId.toString(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            _actionBtn(
              icon: Icons.payments_outlined,
              label: 'Close & Bill',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: widget.branchId,
                    sessionId: widget.sessionId,
                    data: widget.data,
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            const Text(
              'Now supports split payment, discount and tax.',
              style: TextStyle(fontSize: 11, color: Colors.white38),
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 42,
      child: ElevatedButton.icon(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF111827),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(999),
          ),
          elevation: 0,
        ),
        icon: Icon(icon, size: 18),
        label: Text(label),
      ),
    );
  }
}
