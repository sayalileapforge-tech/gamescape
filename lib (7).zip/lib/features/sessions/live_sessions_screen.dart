import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/app_shell.dart';
import '../bookings/booking_actions_dialog.dart';
import '../bookings/booking_close_bill_dialog.dart';

class LiveSessionsScreen extends StatefulWidget {
  const LiveSessionsScreen({super.key});

  @override
  State<LiveSessionsScreen> createState() => _LiveSessionsScreenState();
}

class _LiveSessionsScreenState extends State<LiveSessionsScreen> {
  bool _showMap = false;
  String? _selectedBranchId;

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header + toggle
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Live Sessions',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF1F2937),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  children: [
                    _ToggleChip(
                      label: 'List',
                      selected: !_showMap,
                      onTap: () => setState(() => _showMap = false),
                    ),
                    _ToggleChip(
                      label: 'Map',
                      selected: _showMap,
                      onTap: () => setState(() => _showMap = true),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // branch selector
          StreamBuilder<QuerySnapshot>(
            stream:
                FirebaseFirestore.instance.collection('branches').snapshots(),
            builder: (context, snap) {
              final branches = snap.data?.docs ?? [];
              if (branches.isNotEmpty && _selectedBranchId == null) {
                _selectedBranchId = branches.first.id;
              }
              return Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _selectedBranchId,
                      dropdownColor: const Color(0xFF111827),
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        labelText: 'Select branch',
                        labelStyle: TextStyle(color: Colors.white70),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white24),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                        ),
                      ),
                      items: branches
                          .map(
                            (b) => DropdownMenuItem(
                              value: b.id,
                              child: Text(
                                (b.data() as Map<String, dynamic>?)?['name'] ??
                                    b.id,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        setState(() => _selectedBranchId = v);
                      },
                    ),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 16),

          Expanded(
            child: _selectedBranchId == null
                ? const Center(
                    child: Text(
                      'No branches found.',
                      style: TextStyle(color: Colors.white70),
                    ),
                  )
                : _showMap
                    ? _LiveSessionsMapView(branchId: _selectedBranchId!)
                    : _LiveSessionsListView(branchId: _selectedBranchId!),
          ),
        ],
      ),
    );
  }
}

class _ToggleChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ToggleChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _LiveSessionsListView extends StatelessWidget {
  final String branchId;
  const _LiveSessionsListView({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .where('status', isEqualTo: 'active');

    return StreamBuilder<QuerySnapshot>(
      stream: sessionsRef.snapshots(),
      builder: (context, sessionSnap) {
        if (sessionSnap.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: Colors.white),
          );
        }

        final sessions = sessionSnap.data?.docs ?? [];
        if (sessions.isEmpty) {
          return const Center(
            child: Text(
              'No active sessions right now.',
              style: TextStyle(color: Colors.white70),
            ),
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // header row
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF1F2937),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: const [
                  Expanded(
                    flex: 2,
                    child: Text('Customer',
                        style: TextStyle(color: Colors.white70)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Console',
                        style: TextStyle(color: Colors.white70)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Time In',
                        style: TextStyle(color: Colors.white70)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Time Out',
                        style: TextStyle(color: Colors.white70)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Time Left',
                        style: TextStyle(color: Colors.white70)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Payment',
                        style: TextStyle(color: Colors.white70)),
                  ),
                  SizedBox(
                    width: 120,
                    child:
                        Text('Actions', style: TextStyle(color: Colors.white70)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.separated(
                itemCount: sessions.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final doc = sessions[index];
                  final data = doc.data() as Map<String, dynamic>? ?? {};
                  final customer =
                      data['customerName']?.toString() ?? 'Walk-in';
                  final seatLabel = data['seatLabel']?.toString() ?? 'Seat';
                  final startTime =
                      (data['startTime'] as Timestamp?)?.toDate();
                  final duration =
                      (data['durationMinutes'] as num?)?.toInt() ?? 60;
                  final endTime = startTime != null
                      ? startTime.add(Duration(minutes: duration))
                      : null;
                  final paymentType =
                      data['paymentType']?.toString() ?? 'postpaid';

                  return Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1F2937),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Text(
                            customer,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Text(
                            seatLabel,
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Text(
                            startTime != null ? _hhmm(startTime) : '—',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Text(
                            endTime != null ? _hhmm(endTime) : '—',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: endTime != null
                              ? _LiveCountdown(endTime: endTime)
                              : const Text(
                                  '—',
                                  style: TextStyle(color: Colors.white70),
                                ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Text(
                            paymentType == 'prepaid'
                                ? 'Prepaid'
                                : 'Postpaid',
                            style: TextStyle(
                              color: paymentType == 'prepaid'
                                  ? Colors.blueAccent
                                  : Colors.greenAccent,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 120,
                          child: Wrap(
                            spacing: 4,
                            runSpacing: 4,
                            children: [
                              _SmallActionBtn(
                                label: 'Extend',
                                icon: Icons.add_alarm_outlined,
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => BookingActionsDialog(
                                      branchId: branchId,
                                      sessionId: doc.id,
                                      data: data,
                                    ),
                                  );
                                },
                              ),
                              _SmallActionBtn(
                                label: 'Add F&B',
                                icon: Icons.fastfood_outlined,
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => BookingActionsDialog(
                                      branchId: branchId,
                                      sessionId: doc.id,
                                      data: data,
                                    ),
                                  );
                                },
                              ),
                              _SmallActionBtn(
                                label: 'End',
                                icon: Icons.stop_circle_outlined,
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => BookingCloseBillDialog(
                                      branchId: branchId,
                                      sessionId: doc.id,
                                      data: data,
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  static String _hhmm(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}

class _LiveCountdown extends StatefulWidget {
  final DateTime endTime;
  const _LiveCountdown({required this.endTime});

  @override
  State<_LiveCountdown> createState() => _LiveCountdownState();
}

class _LiveCountdownState extends State<_LiveCountdown> {
  late Duration _remaining;
  late final Ticker _ticker;

  @override
  void initState() {
    super.initState();
    _remaining = widget.endTime.difference(DateTime.now());
    _ticker = Ticker(_onTick)..start();
  }

  void _onTick(Duration _) {
    final diff = widget.endTime.difference(DateTime.now());
    if (mounted) {
      setState(() {
        _remaining = diff.isNegative ? Duration.zero : diff;
      });
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = _remaining;
    final m = r.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = r.inSeconds.remainder(60).toString().padLeft(2, '0');
    final isLow = r.inMinutes < 5;
    return Text(
      '00:$m:$s',
      style: TextStyle(
        color: isLow ? Colors.redAccent : Colors.greenAccent,
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
    );
  }
}

class Ticker {
  Ticker(this.onTick);
  final void Function(Duration) onTick;
  late final Stopwatch _sw = Stopwatch()..start();
  final Duration _step = const Duration(seconds: 1);
  bool _active = false;

  void start() {
    _active = true;
    _tick();
  }

  Future<void> _tick() async {
    while (_active) {
      await Future.delayed(_step);
      onTick(_sw.elapsed);
    }
  }

  void dispose() {
    _active = false;
  }
}

class _SmallActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _SmallActionBtn({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 13, color: Colors.white),
            const SizedBox(width: 3),
            Text(label,
                style: const TextStyle(color: Colors.white, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _LiveSessionsMapView extends StatelessWidget {
  final String branchId;
  const _LiveSessionsMapView({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final branchRef =
        FirebaseFirestore.instance.collection('branches').doc(branchId);
    final seatsRef = branchRef.collection('seats');
    final sessionsRef = branchRef.collection('sessions');

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: seatsRef.snapshots(),
        builder: (context, seatsSnap) {
          return StreamBuilder<QuerySnapshot>(
            stream: sessionsRef.snapshots(),
            builder: (context, sessionsSnap) {
              if (seatsSnap.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(color: Colors.white),
                );
              }

              final seats = seatsSnap.data?.docs ?? [];
              final sessions = sessionsSnap.data?.docs ?? [];
              if (seats.isEmpty) {
                return const Center(
                  child: Text(
                    'No consoles/seats in this branch.',
                    style: TextStyle(color: Colors.white70),
                  ),
                );
              }

              final now = DateTime.now();

              return GridView.builder(
                itemCount: seats.length,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 6,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.15,
                ),
                itemBuilder: (context, index) {
                  final seatDoc = seats[index];
                  final seatId = seatDoc.id;
                  final seatData =
                      seatDoc.data() as Map<String, dynamic>? ?? {};
                  final label =
                      seatData['label']?.toString() ?? 'Seat ${index + 1}';
                  final type = seatData['type']?.toString() ?? 'console';

                  String status = 'free';
                  Map<String, dynamic>? sessionData;
                  String? sessionId;

                  for (final s in sessions) {
                    final sData = s.data() as Map<String, dynamic>? ?? {};
                    if (sData['seatId'] == seatId) {
                      final sStatus = sData['status']?.toString() ?? 'active';
                      final start =
                          (sData['startTime'] as Timestamp?)?.toDate();
                      final dur =
                          (sData['durationMinutes'] as num?)?.toInt() ?? 60;
                      final end =
                          start != null ? start.add(Duration(minutes: dur)) : null;

                      if (sStatus == 'reserved') {
                        status = 'reserved';
                        sessionData = sData;
                        sessionId = s.id;
                        break;
                      }

                      if (start != null && end != null) {
                        if (now.isAfter(start) &&
                            now.isBefore(end) &&
                            sStatus == 'active') {
                          status = 'in_use';
                          sessionData = sData;
                          sessionId = s.id;
                          break;
                        } else if (now.isBefore(start)) {
                          status = 'booked';
                          sessionData = sData;
                          sessionId = s.id;
                        }
                      }
                    }
                  }

                  return _ConsoleTileCompact(
                    label: label,
                    type: type,
                    status: status,
                    onTap: (status == 'free' || sessionData == null)
                        ? null
                        : () {
                            showDialog(
                              context: context,
                              builder: (_) => BookingActionsDialog(
                                branchId: branchId,
                                sessionId: sessionId!,
                                data: sessionData!,
                              ),
                            );
                          },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class _ConsoleTileCompact extends StatelessWidget {
  final String label;
  final String type;
  final String status;
  final VoidCallback? onTap;
  const _ConsoleTileCompact({
    required this.label,
    required this.type,
    required this.status,
    this.onTap,
  });

  Color _statusColor() {
    switch (status) {
      case 'in_use':
        return Colors.greenAccent;
      case 'booked':
        return Colors.blueAccent;
      case 'reserved':
        return Colors.redAccent;
      default:
        return Colors.white24;
    }
  }

  IconData _iconForType() {
    final lower = type.toLowerCase();
    if (lower.contains('pc')) return Icons.computer;
    if (lower.contains('console')) return Icons.sports_esports;
    if (lower.contains('recliner')) return Icons.chair_alt;
    return Icons.chair;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _statusColor(), width: 2),
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_iconForType(), color: Colors.white, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 4),
            Text(
              status == 'in_use'
                  ? 'In Use'
                  : status == 'booked'
                      ? 'Booked'
                      : status == 'reserved'
                          ? 'Reserved'
                          : 'Free',
              style: const TextStyle(color: Colors.white54, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}
