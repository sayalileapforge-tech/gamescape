import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'side_nav_controller.dart';

class SideNav extends StatelessWidget {
  final String role;
  const SideNav({super.key, required this.role});

  bool get _isAdminLike =>
      role == 'admin' || role == 'manager' || role == 'superadmin';

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: sideNavController,
      builder: (context, _) {
        final width = sideNavController.isExpanded ? 200.0 : 70.0;

        return AnimatedContainer(
          width: width,
          duration: const Duration(milliseconds: 200),
          color: Colors.black,
          child: Column(
            children: [
              const SizedBox(height: 12),
              Align(
                alignment: sideNavController.isExpanded
                    ? Alignment.centerRight
                    : Alignment.center,
                child: IconButton(
                  onPressed: () => sideNavController.toggle(),
                  icon: Icon(
                    sideNavController.isExpanded
                        ? Icons.arrow_back_ios_new_rounded
                        : Icons.arrow_forward_ios_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: const Text(
                  'G',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: sideNavController.isExpanded
                        ? CrossAxisAlignment.start
                        : CrossAxisAlignment.center,
                    children: [
                      _NavTile(
                        icon: Icons.dashboard_outlined,
                        label: 'Dashboard',
                        expanded: sideNavController.isExpanded,
                        onTap: () => context.go('/dashboard'),
                      ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.home_work_outlined,
                          label: 'Branches',
                          expanded: sideNavController.isExpanded,
                          onTap: () => context.go('/branches'),
                        ),
                      _NavTile(
                        icon: Icons.chair_outlined,
                        label: 'Bookings',
                        expanded: sideNavController.isExpanded,
                        onTap: () => context.go('/bookings'),
                      ),
                      _NavTile(
                        icon: Icons.live_tv_outlined,
                        label: 'Live Sessions',
                        expanded: sideNavController.isExpanded,
                        onTap: () => context.go('/live-sessions'),
                      ),
                      _NavTile(
                        icon: Icons.person_outline,
                        label: 'Customers',
                        expanded: sideNavController.isExpanded,
                        onTap: () => context.go('/customers'),
                      ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.inventory_2_outlined,
                          label: 'Inventory',
                          expanded: sideNavController.isExpanded,
                          onTap: () => context.go('/inventory'),
                        ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.list_alt_outlined,
                          label: 'Inventory Logs',
                          expanded: sideNavController.isExpanded,
                          onTap: () => context.go('/inventory-logs'),
                        ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.group_outlined,
                          label: 'Users',
                          expanded: sideNavController.isExpanded,
                          onTap: () => context.go('/users'),
                        ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.receipt_long_outlined,
                          label: 'Reports',
                          expanded: sideNavController.isExpanded,
                          onTap: () => context.go('/reports'),
                        ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.picture_as_pdf_outlined,
                          label: 'Invoices',
                          expanded: sideNavController.isExpanded,
                          onTap: () => context.go('/invoices'),
                        ),
                    ],
                  ),
                ),
              ),
              _NavTile(
                icon: Icons.logout,
                label: 'Logout',
                expanded: sideNavController.isExpanded,
                onTap: () async {
                  await FirebaseAuth.instance.signOut();
                  if (context.mounted) context.go('/login');
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }
}

class _NavTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool expanded;

  const _NavTile({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.expanded,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
        padding: EdgeInsets.symmetric(
          vertical: 10,
          horizontal: expanded ? 10 : 0,
        ),
        child: Row(
          mainAxisAlignment:
              expanded ? MainAxisAlignment.start : MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            if (expanded) const SizedBox(width: 10),
            if (expanded)
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
