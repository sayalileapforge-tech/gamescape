import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class BookingMoveSeatDialog extends StatelessWidget {
  final String branchId;
  final String sessionId;
  final String currentSeatId;

  const BookingMoveSeatDialog({
    super.key,
    required this.branchId,
    required this.sessionId,
    required this.currentSeatId,
  });

  @override
  Widget build(BuildContext context) {
    final seatsQuery = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('seats')
        .where('active', isEqualTo: true);

    return Dialog(
      child: Container(
        width: 400,
        padding: const EdgeInsets.all(16),
        child: StreamBuilder<QuerySnapshot>(
          stream: seatsQuery.snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final docs = snapshot.data!.docs;
            String? selectedSeatId;
            String? selectedSeatLabel;

            return StatefulBuilder(
              builder: (context, setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Move to another seat',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Select new seat',
                        border: OutlineInputBorder(),
                      ),
                      items: docs.map((d) {
                        return DropdownMenuItem(
                          value: d.id,
                          child: Text(d['label'] ?? 'Seat'),
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          selectedSeatId = v;
                          final doc = docs.firstWhere((e) => e.id == v);
                          selectedSeatLabel = doc['label'] ?? '';
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: selectedSeatId == null
                            ? null
                            : () async {
                                // 1) update session seat as before
                                await FirebaseFirestore.instance
                                    .collection('branches')
                                    .doc(branchId)
                                    .collection('sessions')
                                    .doc(sessionId)
                                    .update({
                                  'seatId': selectedSeatId,
                                  'seatLabel': selectedSeatLabel,
                                  'updatedAt': FieldValue.serverTimestamp(),
                                });

                                // 2) ADDITIVE: write seat change log for billing/reports
                                final currentUser =
                                    FirebaseAuth.instance.currentUser;
                                final seatChangesCol = FirebaseFirestore.instance
                                    .collection('branches')
                                    .doc(branchId)
                                    .collection('sessions')
                                    .doc(sessionId)
                                    .collection('seat_changes');

                                await seatChangesCol.add({
                                  'fromSeatId': currentSeatId,
                                  'toSeatId': selectedSeatId,
                                  'toSeatLabel': selectedSeatLabel,
                                  'changedAt': FieldValue.serverTimestamp(),
                                  if (currentUser != null)
                                    'changedBy': currentUser.uid,
                                });

                                if (context.mounted) {
                                  Navigator.of(context).pop();
                                }
                              },
                        child: const Text('Move'),
                      ),
                    ),
                  ],
                );
              },
            );
          },
        ),
      ),
    );
  }
}
