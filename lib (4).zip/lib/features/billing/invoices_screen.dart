import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import '../../services/invoice_pdf_service.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  List<QueryDocumentSnapshot> _lastDocs = [];

  @override
  Widget build(BuildContext context) {
    final q = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'completed');

    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Invoices',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: q.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  _lastDocs = snapshot.data!.docs;
                }
                if (_lastDocs.isEmpty) {
                  return const Center(
                      child: Text('No invoices yet.',
                          style: TextStyle(color: Colors.white70)));
                }
                return ListView.separated(
                  itemCount: _lastDocs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final d = _lastDocs[index];
                    final data = d.data() as Map<String, dynamic>;
                    final cust = data['customerName'] ?? 'Guest';
                    final amount = data['billAmount'] ?? 0;
                    final closedAt = data['closedAt'] as Timestamp?;
                    final playedMinutes = data['playedMinutes'];
                    final invoiceNumber = data['invoiceNumber'];
                    final branchId = data['branchId']?.toString() ?? '';

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1F2937),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.receipt_long_outlined,
                              color: Colors.white70),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(cust,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white)),
                                if (invoiceNumber != null)
                                  Text(invoiceNumber,
                                      style: TextStyle(
                                          color: Colors.grey.shade400)),
                                Text(
                                  closedAt != null
                                      ? closedAt.toDate().toString()
                                      : '',
                                  style: TextStyle(color: Colors.grey.shade400),
                                ),
                                if (playedMinutes != null)
                                  Text(
                                    'Played: $playedMinutes minutes',
                                    style:
                                        TextStyle(color: Colors.grey.shade400),
                                  ),
                              ],
                            ),
                          ),
                          Text('₹$amount',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: Colors.white)),
                          const SizedBox(width: 10),
                          ElevatedButton.icon(
                            onPressed: branchId.isEmpty
                                ? null
                                : () async {
                                    await InvoicePdfService().generateAndPrint(
                                      branchId: branchId,
                                      sessionId: d.id,
                                    );
                                  },
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text('PDF'),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
