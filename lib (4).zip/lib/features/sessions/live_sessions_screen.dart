import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';

class LiveSessionsScreen extends StatefulWidget {
  const LiveSessionsScreen({super.key});

  @override
  State<LiveSessionsScreen> createState() => _LiveSessionsScreenState();
}

class _LiveSessionsScreenState extends State<LiveSessionsScreen> {
  bool _showMap = false;

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Live Sessions',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                ),
                // List / Map toggle
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF1F2937),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    children: [
                      _ToggleChip(
                        label: 'List',
                        selected: !_showMap,
                        onTap: () => setState(() => _showMap = false),
                      ),
                      _ToggleChip(
                        label: 'Map',
                        selected: _showMap,
                        onTap: () => setState(() => _showMap = true),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            Expanded(
              child: _showMap
                  ? const _LiveSessionsMapView()
                  : const _LiveSessionsListView(),
            ),
        ],
      ),
    );
  }
}


class _ToggleChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ToggleChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _LiveSessionsListView extends StatelessWidget {
  const _LiveSessionsListView();

  @override
  Widget build(BuildContext context) {
    final branchesRef = FirebaseFirestore.instance.collection('branches');

    return StreamBuilder<QuerySnapshot>(
      stream: branchesRef.snapshots(),
      builder: (context, branchSnap) {
        if (!branchSnap.hasData || branchSnap.data!.docs.isEmpty) {
          return const Center(
            child: Text('No branches found.', style: TextStyle(color: Colors.white70)),
          );
        }

        final firstBranch = branchSnap.data!.docs.first;
        final sessionsRef = branchesRef
            .doc(firstBranch.id)
            .collection('sessions')
            .where('status', isEqualTo: 'active');

        return StreamBuilder<QuerySnapshot>(
          stream: sessionsRef.snapshots(),
          builder: (context, sessionSnap) {
            if (sessionSnap.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.white),
              );
            }

            final sessions = sessionSnap.data?.docs ?? [];
            if (sessions.isEmpty) {
              return const Center(
                child: Text(
                  'No active sessions right now.',
                  style: TextStyle(color: Colors.white70),
                ),
              );
            }

            return ListView.separated(
              itemCount: sessions.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final doc = sessions[index];
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final customer = data['customerName']?.toString() ?? 'Walk-in';
                final seatLabel = data['seatLabel']?.toString() ?? 'Seat';
                final startTime = (data['startTime'] as Timestamp?)?.toDate();
                final duration = (data['durationMinutes'] as num?)?.toInt() ?? 60;
                final endTime =
                    startTime != null ? startTime.add(Duration(minutes: duration)) : null;
                final paymentStatus = data['paymentStatus']?.toString() ?? 'Postpaid';

                return Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF1F2937),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: Colors.black,
                        child: Icon(Icons.sports_esports, color: Colors.white),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              customer,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Console: $seatLabel',
                              style: const TextStyle(color: Colors.white60, fontSize: 12),
                            ),
                            if (startTime != null && endTime != null) ...[
                              const SizedBox(height: 2),
                              Text(
                                'Time: ${_hhmm(startTime)} → ${_hhmm(endTime)}',
                                style: const TextStyle(color: Colors.white38, fontSize: 11),
                              ),
                            ],
                            const SizedBox(height: 4),
                            Text(
                              'Payment: $paymentStatus',
                              style: const TextStyle(color: Colors.white38, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      // Actions
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          _SmallActionBtn(
                            label: 'Extend',
                            icon: Icons.add_alarm_outlined,
                            onTap: () {
                              // redirect to bookings to open extend dialog
                              Navigator.of(context).pushNamed('/bookings');
                            },
                          ),
                          _SmallActionBtn(
                            label: 'End',
                            icon: Icons.stop_circle_outlined,
                            onTap: () {
                              // redirect to bookings to open close & bill dialog
                              Navigator.of(context).pushNamed('/bookings');
                            },
                          ),
                          _SmallActionBtn(
                            label: 'Add F&B',
                            icon: Icons.fastfood_outlined,
                            onTap: () {
                              Navigator.of(context).pushNamed('/bookings');
                            },
                          ),
                          _SmallActionBtn(
                            label: 'Shift',
                            icon: Icons.swap_horiz,
                            onTap: () {
                              Navigator.of(context).pushNamed('/bookings');
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  static String _hhmm(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}

class _SmallActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _SmallActionBtn({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: Colors.white),
            const SizedBox(width: 4),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _LiveSessionsMapView extends StatelessWidget {
  const _LiveSessionsMapView();

  @override
  Widget build(BuildContext context) {
    final branchesRef = FirebaseFirestore.instance.collection('branches');

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: branchesRef.snapshots(),
        builder: (context, branchSnap) {
          if (!branchSnap.hasData || branchSnap.data!.docs.isEmpty) {
            return const Center(
              child: Text('No branches found.', style: TextStyle(color: Colors.white70)),
            );
          }

          final firstBranch = branchSnap.data!.docs.first;
          final branchId = firstBranch.id;
          final seatsRef = branchesRef.doc(branchId).collection('seats');
          final sessionsRef = branchesRef.doc(branchId).collection('sessions');

          return StreamBuilder<QuerySnapshot>(
            stream: seatsRef.snapshots(),
            builder: (context, seatsSnap) {
              return StreamBuilder<QuerySnapshot>(
                stream: sessionsRef.snapshots(),
                builder: (context, sessionsSnap) {
                  if (seatsSnap.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(color: Colors.white),
                    );
                  }

                  final seats = seatsSnap.data?.docs ?? [];
                  final sessions = sessionsSnap.data?.docs ?? [];

                  if (seats.isEmpty) {
                    return const Center(
                      child: Text(
                        'No consoles/seats in this branch.',
                        style: TextStyle(color: Colors.white70),
                      ),
                    );
                  }

                  return GridView.builder(
                    itemCount: seats.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 6,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.15,
                    ),
                    itemBuilder: (context, index) {
                      final seatDoc = seats[index];
                      final seatId = seatDoc.id;
                      final data = seatDoc.data() as Map<String, dynamic>? ?? {};
                      final label = data['label']?.toString() ?? 'Seat ${index + 1}';
                      final type = data['type']?.toString() ?? 'console';

                      // figure out status
                      final now = DateTime.now();
                      String status = 'free';
                      for (final s in sessions) {
                        final sData = s.data() as Map<String, dynamic>? ?? {};
                        if (sData['seatId'] == seatId) {
                          final start = (sData['startTime'] as Timestamp?)?.toDate();
                          final dur = (sData['durationMinutes'] as num?)?.toInt() ?? 60;
                          final end = start != null
                              ? start.add(Duration(minutes: dur))
                              : null;
                          final sStatus = sData['status']?.toString() ?? 'active';
                          if (start != null && end != null) {
                            if (now.isAfter(start) && now.isBefore(end) && sStatus == 'active') {
                              status = 'in_use';
                              break;
                            } else if (now.isBefore(start)) {
                              status = 'booked';
                            }
                          }
                        }
                      }

                      return _ConsoleTileCompact(
                        label: label,
                        type: type,
                        status: status,
                      );
                    },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class _ConsoleTileCompact extends StatelessWidget {
  final String label;
  final String type;
  final String status;
  const _ConsoleTileCompact({
    required this.label,
    required this.type,
    required this.status,
  });

  Color _statusColor() {
    switch (status) {
      case 'in_use':
        return Colors.greenAccent;
      case 'booked':
        return Colors.blueAccent;
      default:
        return Colors.white24;
    }
  }

  IconData _iconForType() {
    final lower = type.toLowerCase();
    if (lower.contains('pc')) return Icons.computer;
    if (lower.contains('console')) return Icons.sports_esports;
    if (lower.contains('recliner')) return Icons.chair_alt;
    return Icons.chair;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _statusColor(), width: 2),
      ),
      padding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(_iconForType(), color: Colors.white, size: 28),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
