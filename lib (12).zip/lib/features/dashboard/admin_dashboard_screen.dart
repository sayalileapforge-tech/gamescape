import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/app_shell.dart';
import '../bookings/add_booking_dialog.dart';
import '../bookings/booking_actions_dialog.dart';
import '../bookings/booking_close_bill_dialog.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return AppShell(
      child: user == null
          ? const Center(
              child: Text(
                'Not logged in',
                style: TextStyle(color: Colors.white),
              ),
            )
          : StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(user.uid)
                  .snapshots(),
              builder: (context, userSnap) {
                final userData =
                    userSnap.data?.data() as Map<String, dynamic>? ?? {};
                final role = (userData['role'] ?? 'staff').toString();
                final List<dynamic> branchIdsDyn =
                    (userData['branchIds'] as List<dynamic>?) ?? [];
                final allowedBranchIds =
                    branchIdsDyn.map((e) => e.toString()).toList();

                return SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Hello, ${userData['name'] ?? 'Admin'} 👋',
                        style: Theme.of(context)
                            .textTheme
                            .headlineSmall
                            ?.copyWith(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                      ),
                      const SizedBox(height: 20),

                      // top stats
                      Wrap(
                        spacing: 16,
                        runSpacing: 16,
                        children: [
                          const _BranchesStatCard(),
                          _TodayTotalBookingsStatCard(
                            role: role,
                            allowedBranchIds: allowedBranchIds,
                          ),
                          _ActiveSessionsStatCard(
                            role: role,
                            allowedBranchIds: allowedBranchIds,
                          ),
                          _TodayRevenueStatCard(
                            role: role,
                            allowedBranchIds: allowedBranchIds,
                          ),
                          _LowStockStatCard(
                            role: role,
                            allowedBranchIds: allowedBranchIds,
                          ),
                          _PendingPaymentsStatCard(
                            role: role,
                            allowedBranchIds: allowedBranchIds,
                          ),
                          // (Removed) Active Staff on Shift
                        ],
                      ),
                      const SizedBox(height: 24),

                      _QuickActionsRow(
                        role: role,
                        allowedBranchIds: allowedBranchIds,
                      ),
                      const SizedBox(height: 24),

                      Text(
                        'Console Map (Live)',
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                      ),
                      const SizedBox(height: 12),
                      _ConsoleMapCard(
                        role: role,
                        allowedBranchIds: allowedBranchIds,
                      ),
                      const SizedBox(height: 30),

                      _UpcomingSessionsCard(
                        role: role,
                        allowedBranchIds: allowedBranchIds,
                      ),
                      const SizedBox(height: 30),

                      Text(
                        'Today\'s Active Sessions',
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                      ),
                      const SizedBox(height: 12),
                      _TodayActiveSessionsCard(
                        role: role,
                        allowedBranchIds: allowedBranchIds,
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

// ----------------- generic stat card -----------------
class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  const _StatCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 22,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _BranchesStatCard extends StatelessWidget {
  const _BranchesStatCard();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('branches').snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _StatCard(title: 'Total Branches', value: '$count');
      },
    );
  }
}

/// Today total bookings = sessions starting today
class _TodayTotalBookingsStatCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _TodayTotalBookingsStatCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    Query baseQuery = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('startTime',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('startTime', isLessThan: Timestamp.fromDate(endOfDay));

    if (allowedBranchIds.isNotEmpty && allowedBranchIds.length <= 10) {
      baseQuery = baseQuery.where('branchId', whereIn: allowedBranchIds);
    }

    // Keep simple, stream count; avoids ephemeral empty states.
    return StreamBuilder<QuerySnapshot>(
      stream: baseQuery.snapshots(),
      builder: (context, snap) {
        if (snap.hasData) {
          return _StatCard(title: 'Today’s Bookings', value: '${snap.data!.docs.length}');
        }
        if (snap.hasError) {
          return const _StatCard(title: 'Today’s Bookings', value: '—');
        }
        return const _StatCard(title: 'Today’s Bookings', value: '—');
      },
    );
  }
}

/// Active sessions across all visible branches (collectionGroup)
class _ActiveSessionsStatCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _ActiveSessionsStatCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    Query q = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'active');

    if (allowedBranchIds.isNotEmpty && allowedBranchIds.length <= 10) {
      q = q.where('branchId', whereIn: allowedBranchIds);
    }

    return StreamBuilder<QuerySnapshot>(
      stream: q.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _StatCard(title: 'Active Bookings', value: '$count');
      },
    );
  }
}

/// Today Revenue = sum of billAmount of completed sessions closed today
class _TodayRevenueStatCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _TodayRevenueStatCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    Query baseQuery = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'completed')
        .where('closedAt',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('closedAt', isLessThan: Timestamp.fromDate(endOfDay));

    if (allowedBranchIds.isNotEmpty && allowedBranchIds.length <= 10) {
      baseQuery = baseQuery.where('branchId', whereIn: allowedBranchIds);
    }

    return StreamBuilder<QuerySnapshot>(
      stream: baseQuery.snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const _StatCard(title: 'Today Revenue', value: '—');
        }
        double total = 0;
        for (final d in snap.data!.docs) {
          final data = d.data() as Map<String, dynamic>? ?? {};
          final amt = (data['billAmount'] as num?)?.toDouble() ?? 0.0;
          total += amt;
        }
        return _StatCard(
          title: 'Today Revenue',
          value: '₹${total.toStringAsFixed(0)}',
        );
      },
    );
  }
}

/// Low Stock — keeps existing per-branch approach (first visible branch)
class _LowStockStatCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _LowStockStatCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    final branchesRef = FirebaseFirestore.instance.collection('branches');
    return StreamBuilder<QuerySnapshot>(
      stream: branchesRef.snapshots(),
      builder: (context, branchSnap) {
        if (!branchSnap.hasData || branchSnap.data!.docs.isEmpty) {
          return const _StatCard(title: 'Low Stock Alerts', value: '0');
        }

        final allBranches = branchSnap.data!.docs;
        final visibleBranches =
            (role == 'superadmin' || allowedBranchIds.isEmpty)
                ? allBranches
                : allBranches
                    .where((b) => allowedBranchIds.contains(b.id))
                    .toList();

        if (visibleBranches.isEmpty) {
          return const _StatCard(title: 'Low Stock Alerts', value: '0');
        }

        final firstBranchId = visibleBranches.first.id;

        return StreamBuilder<QuerySnapshot>(
          stream: branchesRef
              .doc(firstBranchId)
              .collection('inventory')
              .snapshots(),
          builder: (context, invSnap) {
            if (!invSnap.hasData) {
              return const _StatCard(title: 'Low Stock Alerts', value: '0');
            }
            int lowCount = 0;
            for (final doc in invSnap.data!.docs) {
              final data = doc.data() as Map<String, dynamic>? ?? {};
              final active = (data['active'] as bool?) ?? true;
              final stock = (data['stockQty'] as num?)?.toInt() ?? 0;
              final threshold = (data['reorderThreshold'] as num?)?.toInt() ?? 2;
              if (active && stock <= threshold) {
                lowCount++;
              }
            }
            return _StatCard(title: 'Low Stock Alerts', value: '$lowCount');
          },
        );
      },
    );
  }
}

/// Pending Payments — completed sessions with paymentStatus == 'pending'
class _PendingPaymentsStatCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _PendingPaymentsStatCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    Query q = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'completed')
        .where('paymentStatus', isEqualTo: 'pending');

    if (allowedBranchIds.isNotEmpty && allowedBranchIds.length <= 10) {
      q = q.where('branchId', whereIn: allowedBranchIds);
    }

    return StreamBuilder<QuerySnapshot>(
      stream: q.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _StatCard(title: 'Pending Payments', value: '$count');
      },
    );
  }
}

class _QuickActionsRow extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _QuickActionsRow({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        _QuickActionButton(
          icon: Icons.person_add_alt_1,
          label: 'New Walk-in',
          onTap: () {
            showDialog(
              context: context,
              builder: (_) => AddBookingDialog(
                allowedBranchIds: allowedBranchIds,
              ),
            );
          },
        ),
        _QuickActionButton(
          icon: Icons.event_note_outlined,
          label: 'View Bookings',
          onTap: () {
            context.go('/bookings');
          },
        ),
        _QuickActionButton(
          icon: Icons.fastfood_outlined,
          label: 'Add F&B Order',
          onTap: () async {
            await _openSessionPickerAndThen(
              context: context,
              allowedBranchIds: allowedBranchIds,
              onSessionSelected: (branchId, sessionId, data) {
                showDialog(
                  context: context,
                  builder: (_) => BookingActionsDialog(
                    branchId: branchId,
                    sessionId: sessionId,
                    data: data,
                  ),
                );
              },
            );
          },
        ),
        _QuickActionButton(
          icon: Icons.payments_outlined,
          label: 'Quick Checkout',
          onTap: () async {
            await _openSessionPickerAndThen(
              context: context,
              allowedBranchIds: allowedBranchIds,
              onSessionSelected: (branchId, sessionId, data) {
                showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: branchId,
                    sessionId: sessionId,
                    data: data,
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Future<void> _openSessionPickerAndThen({
    required BuildContext context,
    required List<String> allowedBranchIds,
    required void Function(
            String branchId, String sessionId, Map<String, dynamic> data)
        onSessionSelected,
  }) async {
    final branchesSnap =
        await FirebaseFirestore.instance.collection('branches').get();
    if (branchesSnap.docs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No branches found')),
      );
      return;
    }

    QueryDocumentSnapshot branchDoc = branchesSnap.docs.first;
    if (allowedBranchIds.isNotEmpty) {
      final match = branchesSnap.docs.firstWhere(
        (d) => allowedBranchIds.contains(d.id),
        orElse: () => branchesSnap.docs.first,
      );
      branchDoc = match;
    }
    final branchId = branchDoc.id;

    final sessionsSnap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .where('status', isEqualTo: 'active')
        .get();

    if (sessionsSnap.docs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No active sessions to act on')),
      );
      return;
    }

    if (sessionsSnap.docs.length == 1) {
      final s = sessionsSnap.docs.first;
      final data = (s.data() as Map<String, dynamic>?) ?? {};
      onSessionSelected(branchId, s.id, data);
      return;
    }

    showDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 400,
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Select session',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 12),
                ...sessionsSnap.docs.map((doc) {
                  final data = (doc.data() as Map<String, dynamic>?) ?? {};
                  final customer =
                      data['customerName']?.toString() ?? 'Walk-in';
                  final seat = data['seatLabel']?.toString() ?? 'Seat';
                  final ts = (data['startTime'] as Timestamp?)?.toDate();
                  final timeString = ts != null
                      ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                      : '—';
                  return ListTile(
                    title: Text(customer),
                    subtitle: Text('Console: $seat | Start: $timeString'),
                    onTap: () {
                      Navigator.of(context).pop();
                      onSessionSelected(branchId, doc.id, data);
                    },
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2937),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 32,
              width: 32,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- console map ----------------
class _ConsoleMapCard extends StatefulWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _ConsoleMapCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  State<_ConsoleMapCard> createState() => _ConsoleMapCardState();
}

class _ConsoleMapCardState extends State<_ConsoleMapCard> {
  String? _selectedBranchId;

  @override
  Widget build(BuildContext context) {
    final branchesRef = FirebaseFirestore.instance.collection('branches');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: branchesRef.snapshots(),
        builder: (context, branchSnap) {
          if (branchSnap.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(color: Colors.white),
              ),
            );
          }
          if (!branchSnap.hasData || branchSnap.data!.docs.isEmpty) {
            return const Text(
              'No branches found.',
              style: TextStyle(color: Colors.white70),
            );
          }

          final allBranches = branchSnap.data!.docs;
          final visibleBranches =
              (widget.role == 'superadmin' || widget.allowedBranchIds.isEmpty)
                  ? allBranches
                  : allBranches
                      .where((b) => widget.allowedBranchIds.contains(b.id))
                      .toList();

          if (visibleBranches.isEmpty) {
            return const Text(
              'No branches assigned to you.',
              style: TextStyle(color: Colors.white70),
            );
          }

          _selectedBranchId ??= visibleBranches.first.id;

          if (visibleBranches.length > 1) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DropdownButton<String>(
                  value: _selectedBranchId,
                  dropdownColor: const Color(0xFF111827),
                  items: visibleBranches.map((b) {
                    return DropdownMenuItem(
                      value: b.id,
                      child: Text(
                        (b.data() as Map<String, dynamic>?)?['name'] ?? b.id,
                        style: const TextStyle(color: Colors.white),
                      ),
                    );
                  }).toList(),
                  onChanged: (v) {
                    setState(() {
                      _selectedBranchId = v;
                    });
                  },
                ),
                const SizedBox(height: 16),
                _BranchConsoleGrid(branchId: _selectedBranchId!),
              ],
            );
          }

          return _BranchConsoleGrid(branchId: _selectedBranchId!);
        },
      ),
    );
  }
}

class _SeatSession {
  final String id;
  final String status;
  final String customerName;
  final DateTime? start;
  final DateTime? end;

  _SeatSession({
    required this.id,
    required this.status,
    required this.customerName,
    required this.start,
    required this.end,
  });
}

class _BranchConsoleGrid extends StatelessWidget {
  final String branchId;
  const _BranchConsoleGrid({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final seatsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('seats');
    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: seatsRef.snapshots(),
      builder: (context, seatsSnap) {
        final seats = seatsSnap.data?.docs ?? [];

        return StreamBuilder<QuerySnapshot>(
          stream: sessionsRef.snapshots(),
          builder: (context, sessionsSnap) {
            if (seatsSnap.connectionState == ConnectionState.waiting &&
                seatsSnap.data == null) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: LinearProgressIndicator(color: Colors.white),
              );
            }

            if (seats.isEmpty) {
              return const Text(
                'No consoles/seats found for this branch.',
                style: TextStyle(color: Colors.white70),
              );
            }

            final sessions = sessionsSnap.data?.docs ?? [];
            final now = DateTime.now();

            // Map seatId -> list of sessions for that seat
            final Map<String, List<_SeatSession>> sessionsBySeat = {};
            for (final s in sessions) {
              final sData = s.data() as Map<String, dynamic>? ?? {};
              final seatId = sData['seatId']?.toString();
              if (seatId == null) continue;

              final status = sData['status']?.toString() ?? 'active';
              if (status == 'cancelled') continue;

              final start = (sData['startTime'] as Timestamp?)?.toDate();
              final dur = (sData['durationMinutes'] as num?)?.toInt() ?? 60;
              final end =
                  start != null ? start.add(Duration(minutes: dur)) : null;

              sessionsBySeat.putIfAbsent(seatId, () => []).add(
                    _SeatSession(
                      id: s.id,
                      status: status,
                      customerName:
                          sData['customerName']?.toString() ?? 'Walk-in',
                      start: start,
                      end: end,
                    ),
                  );
            }

            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: seats.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 6,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.15,
              ),
              itemBuilder: (context, index) {
                final seatDoc = seats[index];
                final seatId = seatDoc.id;
                final data = seatDoc.data() as Map<String, dynamic>? ?? {};
                final label = data['label']?.toString() ?? 'Seat ${index + 1}';
                final type = data['type']?.toString() ?? 'console';
                final isActive = (data['active'] as bool?) ?? true;

                final seatSessions = (sessionsBySeat[seatId] ?? []).toList()
                  ..sort(
                    (a, b) {
                      final aStart =
                          a.start ?? DateTime.fromMillisecondsSinceEpoch(0);
                      final bStart =
                          b.start ?? DateTime.fromMillisecondsSinceEpoch(0);
                      return aStart.compareTo(bStart);
                    },
                  );

                // Determine overall status for the tile
                String status = 'free';
                bool hasActiveNow = false;
                bool hasReservedFuture = false;
                bool hasFutureAny = false;

                for (final s in seatSessions) {
                  final start = s.start;
                  final end = s.end;
                  if (start == null || end == null) continue;

                  if (s.status == 'active' &&
                      now.isAfter(start) &&
                      now.isBefore(end)) {
                    hasActiveNow = true;
                  }
                  if (s.status == 'reserved' && start.isAfter(now)) {
                    hasReservedFuture = true;
                  }
                  if (start.isAfter(now)) {
                    hasFutureAny = true;
                  }
                }

                if (hasActiveNow) {
                  status = 'in_use';
                } else if (hasReservedFuture) {
                  status = 'reserved';
                } else if (hasFutureAny) {
                  status = 'booked';
                }

                // Detect overlap among sessions for this seat
                bool hasOverlap = false;
                for (var i = 0; i < seatSessions.length; i++) {
                  final a = seatSessions[i];
                  if (a.start == null || a.end == null) continue;
                  for (var j = i + 1; j < seatSessions.length; j++) {
                    final b = seatSessions[j];
                    if (b.start == null || b.end == null) continue;
                    final overlap = a.start!.isBefore(b.end!) &&
                        b.start!.isBefore(a.end!);
                    if (overlap) {
                      hasOverlap = true;
                      break;
                    }
                  }
                  if (hasOverlap) break;
                }

                return _ConsoleTile(
                  label: label,
                  type: type,
                  isActive: isActive,
                  status: status,
                  sessions: seatSessions,
                  hasOverlap: hasOverlap,
                );
              },
            );
          },
        );
      },
    );
  }
}

class _ConsoleTile extends StatelessWidget {
  final String label;
  final String type;
  final bool isActive;
  final String status;
  final List<_SeatSession> sessions;
  final bool hasOverlap;

  const _ConsoleTile({
    required this.label,
    required this.type,
    required this.isActive,
    required this.status,
    required this.sessions,
    required this.hasOverlap,
  });

  Color _statusColor() {
    switch (status) {
      case 'in_use':
        return Colors.grey.shade300; // grey (in use)
      case 'booked':
        return Colors.amberAccent;
      case 'reserved':
        return Colors.orangeAccent;
      default: // free
        return Colors.greenAccent; // green (free)
    }
  }

  Color _statusBg() {
    switch (status) {
      case 'in_use':
        return const Color(0xFF374151); // dark grey
      case 'booked':
        return const Color(0xFF3B2F0B); // dark yellow-ish
      case 'reserved':
        return const Color(0xFF4A1F1A);
      default: // free
        return const Color(0xFF064E3B); // dark green
    }
  }

  String _statusText() {
    switch (status) {
      case 'in_use':
        return 'In use';
      case 'booked':
        return 'Booked';
      case 'reserved':
        return 'Reserved';
      default:
        return 'Free';
    }
  }

  IconData _iconForType() {
    final lower = type.toLowerCase();
    if (lower.contains('pc')) return Icons.computer;
    if (lower.contains('console')) return Icons.sports_esports;
    if (lower.contains('recliner')) return Icons.chair_alt;
    return Icons.chair;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: sessions.isEmpty
          ? null
          : () {
              showDialog(
                context: context,
                builder: (_) {
                  return Dialog(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      width: 360,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            label,
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 16),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Status: ${_statusText()}',
                            style: const TextStyle(color: Colors.white),
                          ),
                          if (!isActive)
                            const Text(
                              'Console is marked inactive',
                              style: TextStyle(
                                  color: Colors.redAccent, fontSize: 12),
                            ),
                          const SizedBox(height: 12),
                          if (hasOverlap)
                            const Padding(
                              padding: EdgeInsets.only(bottom: 8.0),
                              child: Text(
                                '⚠ Overlapping bookings detected on this console.',
                                style: TextStyle(
                                  color: Colors.redAccent,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          const Text(
                            'Bookings for this console',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                          const SizedBox(height: 8),
                          if (sessions.isEmpty)
                            const Text(
                              'No bookings found.',
                              style: TextStyle(color: Colors.white70),
                            ),
                          if (sessions.isNotEmpty)
                            ...sessions.map((s) {
                              final st = s.start;
                              final et = s.end;
                              final stStr = st != null
                                  ? '${st.hour.toString().padLeft(2, '0')}:${st.minute.toString().padLeft(2, '0')}'
                                  : '—';
                              final etStr = et != null
                                  ? '${et.hour.toString().padLeft(2, '0')}:${et.minute.toString().padLeft(2, '0')}'
                                  : '—';
                              return Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 4.0),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Colors.white10,
                                        borderRadius:
                                            BorderRadius.circular(999),
                                      ),
                                      child: Text(
                                        s.status,
                                        style: const TextStyle(
                                            fontSize: 10, color: Colors.white),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        s.customerName,
                                        style: const TextStyle(
                                            fontSize: 13, color: Colors.white),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      '$stStr–$etStr',
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: Colors.white70),
                                    ),
                                  ],
                                ),
                              );
                            }),
                          const SizedBox(height: 12),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () => Navigator.of(context).pop(),
                              child: const Text('Close'),
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                },
              );
            },
      child: Container(
        decoration: BoxDecoration(
          color: _statusBg(),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _statusColor(), width: 3),
        ),
        padding: const EdgeInsets.all(10),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(_iconForType(), color: Colors.white, size: 30),
                const SizedBox(height: 8),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  isActive ? type : '$type (inactive)',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                  ),
                ),
                if (sessions.length > 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(
                      '${sessions.length} bookings',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                      ),
                    ),
                  ),
              ],
            ),
            Positioned(
              right: 0,
              top: 0,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _statusColor().withOpacity(0.2),
                  border: Border.all(color: _statusColor()),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusText(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TodayActiveSessionsCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _TodayActiveSessionsCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    final branchesRef = FirebaseFirestore.instance.collection('branches');

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: branchesRef.snapshots(),
        builder: (context, branchSnap) {
          if (!branchSnap.hasData || branchSnap.data!.docs.isEmpty) {
            return const Text(
              'No active sessions.',
              style: TextStyle(color: Colors.white70),
            );
          }

          final allBranches = branchSnap.data!.docs;
          final visibleBranches =
              (role == 'superadmin' || allowedBranchIds.isEmpty)
                  ? allBranches
                  : allBranches
                      .where((b) => allowedBranchIds.contains(b.id))
                      .toList();

          if (visibleBranches.isEmpty) {
            return const Text(
              'No branches assigned to you.',
              style: TextStyle(color: Colors.white70),
            );
          }

          final firstBranch = visibleBranches.first;
          final sessionsRef = branchesRef
              .doc(firstBranch.id)
              .collection('sessions')
              .where('status', isEqualTo: 'active');

          return StreamBuilder<QuerySnapshot>(
            stream: sessionsRef.snapshots(),
            builder: (context, sessionSnap) {
              if (sessionSnap.connectionState == ConnectionState.waiting) {
                return const LinearProgressIndicator(color: Colors.white);
              }
              final sessions = sessionSnap.data?.docs ?? [];
              if (sessions.isEmpty) {
                return const Text(
                  'No active sessions right now.',
                  style: TextStyle(color: Colors.white70),
                );
              }

              final now = DateTime.now();
              final active = <QueryDocumentSnapshot>[];
              final overdue = <QueryDocumentSnapshot>[];

              for (final doc in sessions) {
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final start = (data['startTime'] as Timestamp?)?.toDate();
                final dur =
                    (data['durationMinutes'] as num?)?.toInt() ?? 60;
                final end =
                    start != null ? start.add(Duration(minutes: dur)) : null;

                if (end != null && now.isAfter(end)) {
                  overdue.add(doc);
                } else {
                  active.add(doc);
                }
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ...active.map((doc) {
                    final data =
                        doc.data() as Map<String, dynamic>? ?? {};
                    final customer =
                        data['customerName']?.toString() ?? 'Walk-in';
                    final seatLabel =
                        data['seatLabel']?.toString() ?? 'Seat';
                    final ts =
                        (data['startTime'] as Timestamp?)?.toDate();
                    final timeString = ts != null
                        ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                        : '—';
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const CircleAvatar(
                        backgroundColor: Colors.black,
                        child:
                            Icon(Icons.chair_outlined, color: Colors.white),
                      ),
                      title: Text(
                        customer,
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        'Console: $seatLabel | Started: $timeString',
                        style: TextStyle(color: Colors.grey.shade400),
                      ),
                      trailing: ElevatedButton(
                        onPressed: () {
                          context.go('/bookings');
                        },
                        child: const Text('View'),
                      ),
                    );
                  }).toList(),
                  if (overdue.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text(
                      'Overdue sessions',
                      style: TextStyle(
                        color: Colors.redAccent.shade100,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...overdue.map((doc) {
                      final data =
                          doc.data() as Map<String, dynamic>? ?? {};
                      final customer =
                          data['customerName']?.toString() ?? 'Walk-in';
                      final seatLabel =
                          data['seatLabel']?.toString() ?? 'Seat';
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const CircleAvatar(
                          backgroundColor: Colors.redAccent,
                          child: Icon(Icons.warning_amber,
                              color: Colors.white),
                        ),
                        title: Text(
                          customer,
                          style: const TextStyle(color: Colors.white),
                        ),
                        subtitle: const Text(
                          'Should be closed',
                          style: TextStyle(color: Colors.white70),
                        ),
                        trailing: ElevatedButton(
                          onPressed: () {
                            context.go('/bookings');
                          },
                          child: const Text('Close now'),
                        ),
                      );
                    }).toList(),
                  ]
                ],
              );
            },
          );
        },
      ),
    );
  }
}

/// Upcoming in next 60 minutes – query directly for reserved sessions in that window
class _UpcomingSessionsCard extends StatelessWidget {
  final String role;
  final List<String> allowedBranchIds;
  const _UpcomingSessionsCard({
    required this.role,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final inOneHour = now.add(const Duration(minutes: 60));

    Query q = FirebaseFirestore.instance
        .collectionGroup('sessions')
        .where('status', isEqualTo: 'reserved')
        .where(
          'startTime',
          isGreaterThanOrEqualTo: Timestamp.fromDate(now),
        )
        .where(
          'startTime',
          isLessThanOrEqualTo: Timestamp.fromDate(inOneHour),
        );

    if (allowedBranchIds.isNotEmpty && allowedBranchIds.length <= 10) {
      q = q.where('branchId', whereIn: allowedBranchIds);
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: q.snapshots(),
        builder: (context, upcomingSnap) {
          if (upcomingSnap.hasError) {
            return const Text(
              'Failed to load upcoming bookings.',
              style: TextStyle(color: Colors.redAccent),
            );
          }

          if (upcomingSnap.connectionState == ConnectionState.waiting &&
              !upcomingSnap.hasData) {
            return const Text(
              'Loading upcoming bookings...',
              style: TextStyle(color: Colors.white70),
            );
          }

          final docs = upcomingSnap.data?.docs ?? [];

          if (docs.isEmpty) {
            return const Text(
              'No upcoming bookings in the next 60 minutes.',
              style: TextStyle(color: Colors.white70),
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Upcoming in next 60 minutes',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              ...docs.map((doc) {
                final data = doc.data() as Map<String, dynamic>? ?? {};
                final customer =
                    data['customerName']?.toString() ?? 'Walk-in';
                final seat = data['seatLabel']?.toString() ?? 'Seat';
                final ts = (data['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null
                    ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                    : '—';
                final branchId = data['branchId']?.toString() ?? '';
                final branchName = data['branchName']?.toString() ?? '';

                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Colors.deepOrange,
                    child: Icon(Icons.timer, color: Colors.white),
                  ),
                  title: Text(
                    customer,
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    '$branchName • Console: $seat • Starts at: $timeString • Yet to start',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                  trailing: TextButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) {
                          return Dialog(
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              width: 320,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Upcoming booking',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14),
                                  ),
                                  const SizedBox(height: 12),
                                  ElevatedButton(
                                    onPressed: () async {
                                      await FirebaseFirestore.instance
                                          .collection('branches')
                                          .doc(branchId)
                                          .collection('sessions')
                                          .doc(doc.id)
                                          .update({
                                        'status': 'active',
                                        'startTime':
                                            Timestamp.fromDate(DateTime.now()),
                                      });
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text('Start now'),
                                  ),
                                  const SizedBox(height: 8),
                                  ElevatedButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                      context.go('/bookings');
                                    },
                                    child: const Text('Reschedule'),
                                  ),
                                  const SizedBox(height: 8),
                                  TextButton(
                                    onPressed: () async {
                                      await FirebaseFirestore.instance
                                          .collection('branches')
                                          .doc(branchId)
                                          .collection('sessions')
                                          .doc(doc.id)
                                          .update({
                                        'status': 'cancelled',
                                      });
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text(
                                      'Cancel booking',
                                      style:
                                          TextStyle(color: Colors.redAccent),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: TextButton(
                                      onPressed: () =>
                                          Navigator.of(context).pop(),
                                      child: const Text('Close'),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                    child: const Text('Manage'),
                  ),
                );
              }),
            ],
          );
        },
      ),
    );
  }
}
