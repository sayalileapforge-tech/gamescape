import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../core/widgets/app_shell.dart';
import '../../services/invoice_pdf_service.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  int _tabIndex = 0;
  List<QueryDocumentSnapshot> _lastDocs = const [];

  @override
  Widget build(BuildContext context) {
    return AppShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Invoices',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _TabChip(label: 'Pending', selected: _tabIndex == 0, onTap: () => setState(() => _tabIndex = 0)),
              const SizedBox(width: 8),
              _TabChip(label: 'Paid', selected: _tabIndex == 1, onTap: () => setState(() => _tabIndex = 1)),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _buildStream(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  _lastDocs = snapshot.data!.docs;
                }
                final docs = snapshot.data?.docs ?? _lastDocs;

                if (snapshot.connectionState == ConnectionState.waiting && docs.isEmpty) {
                  return const Center(
                    child: CircularProgressIndicator(color: Colors.white),
                  );
                }

                if (docs.isEmpty) {
                  return Center(
                    child: Text(
                      _tabIndex == 0 ? 'No pending invoices.' : 'No paid invoices.',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  );
                }

                return ListView.separated(
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final d = docs[index];
                    final data = d.data() as Map<String, dynamic>;
                    final cust = data['customerName'] ?? 'Guest';
                    final amount = (data['billAmount'] ?? 0) as num;
                    final closedAt = data['closedAt'] as Timestamp?;
                    final playedMinutes = data['playedMinutes'];
                    final invoiceNumber = data['invoiceNumber'];
                    final branchId = data['branchId']?.toString() ?? '';
                    final payments = (data['payments'] as List<dynamic>?) ?? [];
                    final totalPaid = payments.fold<num>(
                      0,
                      (prev, e) => prev + ((e as Map<String, dynamic>)['amount'] ?? 0),
                    );
                    final remaining = amount - totalPaid;

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1F2937),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.receipt_long_outlined, color: Colors.white70),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(cust,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600, color: Colors.white)),
                                if (invoiceNumber != null)
                                  Text(
                                    invoiceNumber,
                                    style: TextStyle(color: Colors.grey.shade400),
                                  ),
                                Text(
                                  closedAt != null
                                      ? closedAt.toDate().toLocal().toString()
                                      : '',
                                  style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
                                ),
                                if (playedMinutes != null)
                                  Text(
                                    'Played: $playedMinutes minutes',
                                    style: TextStyle(color: Colors.grey.shade400),
                                  ),
                                if (payments.isNotEmpty)
                                  Text(
                                    'Paid: ₹$totalPaid • Remaining: ₹${remaining < 0 ? 0 : remaining}',
                                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                                  ),
                              ],
                            ),
                          ),
                          Text(
                            '₹$amount',
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton.icon(
                            onPressed: branchId.isEmpty
                                ? null
                                : () async {
                                    await InvoicePdfService().generateAndPrint(
                                      branchId: branchId,
                                      sessionId: d.id,
                                    );
                                  },
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text('PDF'),
                          ),
                          const SizedBox(width: 8),
                          if (_tabIndex == 0)
                            OutlinedButton(
                              onPressed: () => _showRecordPaymentDialog(context, d, amount),
                              child: const Text('Record Payment'),
                            ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Stream<QuerySnapshot> _buildStream() {
    final base = FirebaseFirestore.instance.collectionGroup('sessions');
    final query = _tabIndex == 0
        ? base
            .where('status', isEqualTo: 'completed')
            .where('paymentStatus', isEqualTo: 'pending')
            .orderBy('closedAt', descending: true)
        : base
            .where('status', isEqualTo: 'completed')
            .where('paymentStatus', isEqualTo: 'paid')
            .orderBy('closedAt', descending: true);
    return query.snapshots(includeMetadataChanges: true);
  }

  Future<void> _showRecordPaymentDialog(
    BuildContext context,
    QueryDocumentSnapshot doc,
    num billAmount,
  ) async {
    String mode = 'cash';
    final data = doc.data() as Map<String, dynamic>? ?? {};
    final existingPayments = (data['payments'] as List<dynamic>?) ?? <dynamic>[];
    final totalPaid = existingPayments.fold<num>(
      0,
      (prev, e) => prev + ((e as Map<String, dynamic>)['amount'] as num? ?? 0),
    );
    final remaining = billAmount - totalPaid;
    final controller = TextEditingController(text: remaining > 0 ? remaining.toString() : '0');

    await showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1F2937),
          title: const Text('Record payment', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: mode,
                dropdownColor: const Color(0xFF111827),
                decoration: const InputDecoration(
                  labelText: 'Mode',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white24),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                  ),
                ),
                style: const TextStyle(color: Colors.white),
                items: const [
                  DropdownMenuItem(value: 'cash', child: Text('Cash')),
                  DropdownMenuItem(value: 'card', child: Text('Card')),
                  DropdownMenuItem(value: 'upi', child: Text('UPI')),
                  DropdownMenuItem(value: 'other', child: Text('Other')),
                ],
                onChanged: (v) => mode = v ?? 'cash',
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Amount',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white24),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final amt = double.tryParse(controller.text) ?? 0;
                final newPayments = [
                  ...existingPayments,
                  {'mode': mode, 'amount': amt},
                ];
                final newTotal = newPayments.fold<num>(
                  0,
                  (prev, e) => prev + ((e as Map<String, dynamic>)['amount'] ?? 0),
                );

                await doc.reference.update({
                  'payments': newPayments,
                  'paymentStatus': newTotal >= billAmount ? 'paid' : 'pending',
                });

                if (context.mounted) Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }
}

class _TabChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TabChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.white24),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
