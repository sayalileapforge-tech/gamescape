import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/app_shell.dart';
import '../bookings/add_booking_dialog.dart';
import '../bookings/booking_actions_dialog.dart';
import '../bookings/booking_close_bill_dialog.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  String? _selectedBranchId;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return AppShell(
      child: user == null
          ? const Center(
              child: Text('Not logged in', style: TextStyle(color: Colors.white)),
            )
          : StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(user.uid)
                  .snapshots(),
              builder: (context, userSnap) {
                final userData =
                    userSnap.data?.data() as Map<String, dynamic>? ?? {};
                final role = (userData['role'] ?? 'staff').toString();
                final allowedBranchIds = (userData['branchIds'] as List?)?.map((e) => e.toString()).toList() ?? [];

                final branchesRef = FirebaseFirestore.instance.collection('branches');

                return StreamBuilder<QuerySnapshot>(
                  stream: branchesRef.snapshots(),
                  builder: (context, branchSnap) {
                    final allBranches = branchSnap.data?.docs ?? [];

                    if (allBranches.isEmpty) {
                      return const Center(
                        child: Text('No branches found.', style: TextStyle(color: Colors.white70)),
                      );
                    }

                    final visibleBranches = 
                      (role == 'superadmin' || allowedBranchIds.isEmpty)
                      ? allBranches
                      : allBranches.where((b) => allowedBranchIds.contains(b.id)).toList();

                    if (visibleBranches.isEmpty) {
                      return const Center(
                        child: Text('No branches assigned to your account.', style: TextStyle(color: Colors.white70)),
                      );
                    }

                    // set selected branch automatically if not set
                    _selectedBranchId ??= visibleBranches.first.id;
                    final selectedBranchDoc = visibleBranches.firstWhere(
                      (b) => b.id == _selectedBranchId,
                      orElse: () => visibleBranches.first,
                    );
                    final selectedBranchId = selectedBranchDoc.id;

                    return SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello, ${userData['name'] ?? 'Admin'} 👋',
                            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                          ),
                          const SizedBox(height: 12),

                          // Branch selector
                          Row(
                            children: [
                              const Text('Branch:', style: TextStyle(color: Colors.white70)),
                              const SizedBox(width: 12),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF111827),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.white12),
                                ),
                                child: DropdownButton<String>(
                                  value: selectedBranchId,
                                  dropdownColor: const Color(0xFF111827),
                                  underline: const SizedBox.shrink(),
                                  style: const TextStyle(color: Colors.white),
                                  items: visibleBranches.map((b) {
                                    final data = b.data() as Map<String, dynamic>? ?? {};
                                    final name = (data['name'] ?? b.id).toString();
                                    return DropdownMenuItem(value: b.id, child: Text(name));
                                  }).toList(),
                                  onChanged: (v) {
                                    setState(() => _selectedBranchId = v);
                                  },
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 20),

                          // --- TOP STATS ---
                          Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              const _BranchesStatCard(),
                              _TodayTotalBookingsStatCard(branchId: selectedBranchId),
                              _ActiveSessionsStatCard(branchId: selectedBranchId),
                              _TodayRevenueStatCard(branchId: selectedBranchId),
                              _PendingPaymentsStatCard(branchId: selectedBranchId),
                            ],
                          ),

                          const SizedBox(height: 24),

                          _QuickActionsRow(
                            branchId: selectedBranchId,
                            allowedBranchIds: allowedBranchIds,
                          ),

                          const SizedBox(height: 24),

                          Text(
                            'Console Map (Live)',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                          ),
                          const SizedBox(height: 12),

                          _ConsoleMapCard(branchId: selectedBranchId),

                          const SizedBox(height: 30),

                          _UpcomingSessionsCard(branchId: selectedBranchId),

                          const SizedBox(height: 30),

                          Text(
                            "Today's Active Sessions",
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                          ),
                          const SizedBox(height: 12),

                          _TodayActiveSessionsCard(branchId: selectedBranchId),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

//
// -------------- PART 1 continues: STAT CARDS --------------
//

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  const _StatCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 22, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class _BranchesStatCard extends StatelessWidget {
  const _BranchesStatCard();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('branches').snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return _StatCard(title: 'Total Branches', value: '$count');
      },
    );
  }
}

class _TodayTotalBookingsStatCard extends StatelessWidget {
  final String branchId;
  const _TodayTotalBookingsStatCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('branches')
          .doc(branchId)
          .collection('sessions')
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const _StatCard(title: "Today's Bookings", value: '0');

        final now = DateTime.now();
        final startDay = DateTime(now.year, now.month, now.day);
        final endDay = startDay.add(const Duration(days: 1));

        final count = snap.data!.docs.where((d) {
          final m = d.data() as Map<String, dynamic>? ?? {};
          final ts = (m['startTime'] as Timestamp?)?.toDate();
          if (ts == null) return false;
          return ts.isAfter(startDay) && ts.isBefore(endDay);
        }).length;

        return _StatCard(title: "Today's Bookings", value: '$count');
      },
    );
  }
}

class _ActiveSessionsStatCard extends StatelessWidget {
  final String branchId;
  const _ActiveSessionsStatCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('branches')
          .doc(branchId)
          .collection('sessions')
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const _StatCard(title: "Active Sessions", value: '0');

        final now = DateTime.now();

        final active = snap.data!.docs.where((d) {
          final m = d.data() as Map<String, dynamic>? ?? {};

          final start = (m['startTime'] as Timestamp?)?.toDate();
          final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
          if (start == null) return false;

          final end = start.add(Duration(minutes: dur));

          return now.isAfter(start) && now.isBefore(end);
        }).length;

        return _StatCard(title: "Active Sessions", value: '$active');
      },
    );
  }
}

class _TodayRevenueStatCard extends StatelessWidget {
  final String branchId;
  const _TodayRevenueStatCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startDay = DateTime(now.year, now.month, now.day);
    final endDay = startDay.add(const Duration(days: 1));

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('branches')
          .doc(branchId)
          .collection('sessions')
          .where('closedAt', isGreaterThanOrEqualTo: Timestamp.fromDate(startDay))
          .where('closedAt', isLessThan: Timestamp.fromDate(endDay))
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const _StatCard(title: "Today's Revenue", value: '₹0');

        double total = 0;

        for (final d in snap.data!.docs) {
          final m = d.data() as Map<String, dynamic>? ?? {};

          final status = m['status']?.toString() ?? '';
          final pay = m['paymentStatus']?.toString() ?? '';

          if (status == 'completed' && pay == 'paid') {
            total += (m['billAmount'] as num?)?.toDouble() ?? 0;
          }
        }

        return _StatCard(title: "Today's Revenue", value: '₹${total.toStringAsFixed(0)}');
      },
    );
  }
}

class _PendingPaymentsStatCard extends StatelessWidget {
  final String branchId;
  const _PendingPaymentsStatCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('branches')
          .doc(branchId)
          .collection('sessions')
          .where('paymentStatus', isEqualTo: 'pending')
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const _StatCard(title: 'Pending Payments', value: '₹0');

        double total = 0;

        for (final d in snap.data!.docs) {
          final m = d.data() as Map<String, dynamic>? ?? {};
          total += (m['billAmount'] as num?)?.toDouble() ?? 0;
        }

        return _StatCard(title: 'Pending Payments', value: '₹${total.toStringAsFixed(0)}');
      },
    );
  }
}

//
// -------- PART 1 ends when console grid begins ------
//

// Now continue to PART 2/3
// PART 2/3 — admin_dashboard_screen.dart (continuation from Part 1)

//
// ========================= QUICK ACTIONS =========================
//

class _QuickActionsRow extends StatelessWidget {
  final String branchId;
  final List<String> allowedBranchIds;
  const _QuickActionsRow({
    required this.branchId,
    required this.allowedBranchIds,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        // New Walk-in
        _QuickActionButton(
          icon: Icons.person_add_alt_1,
          label: 'New Walk-in',
          onTap: () {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => AddBookingDialog(
                allowedBranchIds: allowedBranchIds,
                initialBranchId: branchId,
              ),
            );
          },
        ),

        // View Today's bookings
        _QuickActionButton(
          icon: Icons.event_note_outlined,
          label: 'View Bookings',
          onTap: () {
            showDialog(
              context: context,
              builder: (_) => _TodaysBookingsDialog(branchId: branchId),
            );
          },
        ),

        // Add F&B
        _QuickActionButton(
          icon: Icons.fastfood_outlined,
          label: 'Add F&B Order',
          onTap: () async {
            await _openSessionPicker(
              context: context,
              branchId: branchId,
              onSelected: (sessionId, data) {
                showDialog(
                  context: context,
                  builder: (_) => BookingActionsDialog(
                    branchId: branchId,
                    sessionId: sessionId,
                    data: data,
                  ),
                );
              },
            );
          },
        ),

        // Quick Checkout
        _QuickActionButton(
          icon: Icons.payments_outlined,
          label: 'Quick Checkout',
          onTap: () async {
            await _openSessionPicker(
              context: context,
              branchId: branchId,
              onSelected: (sessionId, data) {
                showDialog(
                  context: context,
                  builder: (_) => BookingCloseBillDialog(
                    branchId: branchId,
                    sessionId: sessionId,
                    data: data,
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  //
  // --------- SESSION PICKER (Time-window logic) ----------
  //
  Future<void> _openSessionPicker({
    required BuildContext context,
    required String branchId,
    required void Function(String sessionId, Map<String, dynamic> data) onSelected,
  }) async {
    final snap = await FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions')
        .get();

    if (snap.docs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No sessions found for this branch')),
      );
      return;
    }

    final now = DateTime.now();

    // ACTIVE (time-window)
    final active = snap.docs.where((d) {
      final m = d.data() as Map<String, dynamic>? ?? {};
      final start = (m['startTime'] as Timestamp?)?.toDate();
      final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
      if (start == null) return false;
      final end = start.add(Duration(minutes: dur));
      return now.isAfter(start) && now.isBefore(end);
    }).toList();

    if (active.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No active sessions to act on')),
      );
      return;
    }

    if (active.length == 1) {
      final doc = active.first;
      onSelected(doc.id, doc.data() as Map<String, dynamic>? ?? {});
      return;
    }

    // MULTIPLE active → let staff choose
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF111827),
        child: Container(
          width: 420,
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Select Active Session',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 12),

              ...active.map((doc) {
                final m = doc.data() as Map<String, dynamic>? ?? {};
                final customer = m['customerName'] ?? 'Walk-in';
                final seat = m['seatLabel'] ?? '-';
                final ts = (m['startTime'] as Timestamp?)?.toDate();
                final tStr = ts != null
                    ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                    : '—';

                return ListTile(
                  title: Text(customer.toString(), style: const TextStyle(color: Colors.white)),
                  subtitle: Text('Console: $seat | Started: $tStr', style: const TextStyle(color: Colors.white60)),
                  onTap: () {
                    Navigator.of(context).pop();
                    onSelected(doc.id, m);
                  },
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickActionButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2937),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.08),
              ),
              child: Icon(icon, size: 18, color: Colors.white),
            ),
            const SizedBox(width: 10),
            Text(label, style: const TextStyle(color: Colors.white)),
          ],
        ),
      ),
    );
  }
}

//
// ========================== CONSOLE MAP ===========================
//

class _ConsoleMapCard extends StatelessWidget {
  final String branchId;
  const _ConsoleMapCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: _BranchConsoleGrid(branchId: branchId),
    );
  }
}

//
// --- Console Grid (Seats + Sessions w/ time-window logic) ---
//

class _SeatSession {
  final String id;
  final String status;
  final String customer;
  final DateTime? start;
  final DateTime? end;

  _SeatSession({
    required this.id,
    required this.status,
    required this.customer,
    required this.start,
    required this.end,
  });
}

class _BranchConsoleGrid extends StatelessWidget {
  final String branchId;
  const _BranchConsoleGrid({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final seatsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('seats');

    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions');

    return StreamBuilder<QuerySnapshot>(
      stream: seatsRef.snapshots(),
      builder: (context, seatSnap) {
        final seats = seatSnap.data?.docs ?? [];

        return StreamBuilder<QuerySnapshot>(
          stream: sessionsRef.snapshots(),
          builder: (context, sesSnap) {
            final sessions = sesSnap.data?.docs ?? [];
            final now = DateTime.now();

            // seatId → sessions list
            final map = <String, List<_SeatSession>>{};
            for (final s in sessions) {
              final m = s.data() as Map<String, dynamic>? ?? {};
              final sid = m['seatId']?.toString();
              if (sid == null) continue;

              final st = (m['startTime'] as Timestamp?)?.toDate();
              final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
              final en = st != null ? st.add(Duration(minutes: dur)) : null;

              map.putIfAbsent(sid, () => []).add(
                _SeatSession(
                  id: s.id,
                  status: m['status'] ?? '',
                  customer: m['customerName'] ?? 'Walk-in',
                  start: st,
                  end: en,
                ),
              );
            }

            return GridView.builder(
              itemCount: seats.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 6,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.15,
              ),
              itemBuilder: (context, i) {
                final seatDoc = seats[i];
                final seatData = seatDoc.data() as Map<String, dynamic>? ?? {};
                final label = seatData['label'] ?? 'Seat';
                final type = seatData['type'] ?? 'console';
                final active = seatData['active'] ?? true;

                final seatSessions = (map[seatDoc.id] ?? [])..sort((a, b) {
                  final as = a.start ?? DateTime(2000);
                  final bs = b.start ?? DateTime(2000);
                  return as.compareTo(bs);
                });

                // Determine tile status (free/booked/in_use/reserved)
                final now = DateTime.now();
                bool inUse = false;
                bool booked = false;
                bool reserved = false;

                for (final s in seatSessions) {
                  if (s.start == null || s.end == null) continue;

                  if (now.isAfter(s.start!) && now.isBefore(s.end!)) {
                    inUse = true;
                  } else if (s.start!.isAfter(now)) {
                    booked = true;
                    if (s.status == 'reserved') reserved = true;
                  }
                }

                final status = inUse
                    ? 'in_use'
                    : reserved
                        ? 'reserved'
                        : booked
                            ? 'booked'
                            : 'free';

                // Detect overlaps
                bool overlap = false;
                for (var x = 0; x < seatSessions.length; x++) {
                  for (var y = x + 1; y < seatSessions.length; y++) {
                    final a = seatSessions[x];
                    final b = seatSessions[y];
                    if (a.start == null || a.end == null) continue;
                    if (b.start == null || b.end == null) continue;

                    final o = a.start!.isBefore(b.end!) && b.start!.isBefore(a.end!);
                    if (o) overlap = true;
                  }
                }

                return _ConsoleTile(
                  label: label.toString(),
                  type: type.toString(),
                  isActive: active,
                  status: status,
                  sessions: seatSessions,
                  hasOverlap: overlap,
                );
              },
            );
          },
        );
      },
    );
  }
}

//
// ======================== CONSOLE TILE POPUP =========================
//

class _ConsoleTile extends StatelessWidget {
  final String label;
  final String type;
  final bool isActive;
  final String status;
  final List<_SeatSession> sessions;
  final bool hasOverlap;

  const _ConsoleTile({
    required this.label,
    required this.type,
    required this.isActive,
    required this.status,
    required this.sessions,
    required this.hasOverlap,
  });

  Color _statusColor() {
    switch (status) {
      case 'in_use':
        return Colors.grey.shade300;
      case 'booked':
        return Colors.amberAccent;
      case 'reserved':
        return Colors.orangeAccent;
      default:
        return Colors.greenAccent;
    }
  }

  Color _statusBg() {
    switch (status) {
      case 'in_use':
        return const Color(0xFF374151);
      case 'booked':
        return const Color(0xFF3B2F0B);
      case 'reserved':
        return const Color(0xFF4A1F1A);
      default:
        return const Color(0xFF064E3B);
    }
  }

  String _statusText() {
    switch (status) {
      case 'in_use':
        return 'In use';
      case 'booked':
        return 'Booked';
      case 'reserved':
        return 'Reserved';
      default:
        return 'Free';
    }
  }

  IconData _iconForType() {
    final t = type.toLowerCase();
    if (t.contains('pc')) return Icons.computer;
    if (t.contains('console')) return Icons.sports_esports;
    if (t.contains('recliner')) return Icons.chair_alt;
    return Icons.chair;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: sessions.isEmpty
          ? null
          : () {
              showDialog(
                context: context,
                builder: (_) => Dialog(
                  backgroundColor: const Color(0xFF111827), // FIXED
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    width: 360,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(label,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            )),
                        const SizedBox(height: 8),

                        Text('Status: ${_statusText()}',
                            style: const TextStyle(color: Colors.white70)),

                        if (!isActive)
                          const Text(
                            'Console is marked inactive',
                            style: TextStyle(color: Colors.redAccent, fontSize: 12),
                          ),

                        const SizedBox(height: 12),

                        if (hasOverlap)
                          const Text(
                            '⚠ Overlapping bookings detected on this console.',
                            style: TextStyle(
                              color: Colors.redAccent,
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                        const SizedBox(height: 12),

                        const Text(
                          'Bookings for this console',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            fontSize: 13,
                          ),
                        ),

                        const SizedBox(height: 8),

                        if (sessions.isEmpty)
                          const Text('No bookings.',
                              style: TextStyle(color: Colors.white70)),

                        ...sessions.map((s) {
                          final st = s.start;
                          final en = s.end;

                          final stStr = st != null
                              ? '${st.hour.toString().padLeft(2, '0')}:${st.minute.toString().padLeft(2, '0')}'
                              : '—';
                          final enStr = en != null
                              ? '${en.hour.toString().padLeft(2, '0')}:${en.minute.toString().padLeft(2, '0')}'
                              : '—';

                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Colors.white12,
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(s.status,
                                      style: const TextStyle(color: Colors.white, fontSize: 10)),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(s.customer, style: const TextStyle(color: Colors.white)),
                                ),
                                Text('$stStr–$enStr',
                                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
                              ],
                            ),
                          );
                        }),

                        const SizedBox(height: 16),

                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: const Text('Close', style: TextStyle(color: Colors.white)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
      child: Container(
        decoration: BoxDecoration(
          color: _statusBg(),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _statusColor(), width: 3),
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_iconForType(), color: Colors.white, size: 30),
            const SizedBox(height: 8),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(type,
                style: const TextStyle(color: Colors.white60, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
// PART 3/3 — admin_dashboard_screen.dart (final continuation)

//
// ====================== TODAY'S ACTIVE SESSIONS ======================
//

class _TodayActiveSessionsCard extends StatelessWidget {
  final String branchId;
  const _TodayActiveSessionsCard({required this.branchId});

  @override
  Widget build(BuildContext context) {
    final sessionsRef = FirebaseFirestore.instance
        .collection('branches')
        .doc(branchId)
        .collection('sessions');

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: StreamBuilder<QuerySnapshot>(
        stream: sessionsRef.snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const LinearProgressIndicator(color: Colors.white);
          }

          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Text(
              'No sessions for this branch.',
              style: TextStyle(color: Colors.white70),
            );
          }

          final now = DateTime.now();
          final active = <QueryDocumentSnapshot>[];
          final overdue = <QueryDocumentSnapshot>[];

          for (final d in docs) {
            final m = d.data() as Map<String, dynamic>? ?? {};
            final start = (m['startTime'] as Timestamp?)?.toDate();
            final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
            if (start == null) continue;
            final end = start.add(Duration(minutes: dur));

            if (now.isAfter(start) && now.isBefore(end)) {
              active.add(d);
            } else if (now.isAfter(end)) {
              overdue.add(d);
            }
          }

          if (active.isEmpty && overdue.isEmpty) {
            return const Text(
              'No sessions are currently running or overdue.',
              style: TextStyle(color: Colors.white70),
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ACTIVE
              ...active.map((doc) {
                final m = doc.data() as Map<String, dynamic>? ?? {};
                final customer = (m['customerName'] ?? 'Walk-in').toString();
                final seat = (m['seatLabel'] ?? 'Seat').toString();
                final ts = (m['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null
                    ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                    : '—';

                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Colors.black,
                    child: Icon(Icons.chair_outlined, color: Colors.white),
                  ),
                  title: Text(
                    customer,
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    'Console: $seat • Started: $timeString',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                  trailing: ElevatedButton(
                    onPressed: () => context.go('/bookings'),
                    child: const Text('View'),
                  ),
                );
              }),

              if (overdue.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text(
                  'Overdue sessions',
                  style: TextStyle(
                    color: Colors.redAccent.shade100,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                ...overdue.map((doc) {
                  final m = doc.data() as Map<String, dynamic>? ?? {};
                  final customer = (m['customerName'] ?? 'Walk-in').toString();
                  final seat = (m['seatLabel'] ?? 'Seat').toString();

                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(
                      backgroundColor: Colors.redAccent,
                      child: Icon(Icons.warning_amber, color: Colors.white),
                    ),
                    title: Text(
                      customer,
                      style: const TextStyle(color: Colors.white),
                    ),
                    subtitle: Text(
                      'Console: $seat • Should be closed',
                      style: const TextStyle(color: Colors.white70),
                    ),
                    trailing: ElevatedButton(
                      onPressed: () => context.go('/bookings'),
                      child: const Text('Close now'),
                    ),
                  );
                }),
              ],
            ],
          );
        },
      ),
    );
  }
}

//
// ====================== UPCOMING SESSIONS (NEXT 60M) ======================
//

class _UpcomingSessionsCard extends StatefulWidget {
  final String branchId;
  const _UpcomingSessionsCard({required this.branchId});

  @override
  State<_UpcomingSessionsCard> createState() => _UpcomingSessionsCardState();
}

class _UpcomingSessionsCardState extends State<_UpcomingSessionsCard> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final now = DateTime.now();
      final inOneHour = now.add(const Duration(minutes: 60));

      final snap = await FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
          .where('startTime', isLessThanOrEqualTo: Timestamp.fromDate(inOneHour))
          .get();

      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] as String?) ?? '';
        // Upcoming = reserved only
        return status == 'reserved';
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ?? DateTime(2000);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ?? DateTime(2000);
          return ta.compareTo(tb);
        });

      setState(() {
        _docs = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load upcoming bookings.';
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Upcoming in next 60 minutes',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Refresh',
                onPressed: _load,
                icon: const Icon(Icons.refresh, color: Colors.white70),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_loading)
            const Text(
              'Loading upcoming bookings...',
              style: TextStyle(color: Colors.white70),
            )
          else if (_error != null)
            const Text(
              'Failed to load upcoming bookings.',
              style: TextStyle(color: Colors.redAccent),
            )
          else if (_docs.isEmpty)
            const Text(
              'No upcoming bookings in the next 60 minutes.',
              style: TextStyle(color: Colors.white70),
            )
          else
            Column(
              children: _docs.map((doc) {
                final m = doc.data() as Map<String, dynamic>? ?? {};
                final customer = (m['customerName'] ?? 'Walk-in').toString();
                final seat = (m['seatLabel'] ?? 'Seat').toString();
                final branchName = (m['branchName'] ?? '').toString();
                final ts = (m['startTime'] as Timestamp?)?.toDate();
                final timeString = ts != null
                    ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                    : '—';

                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Colors.deepOrange,
                    child: Icon(Icons.timer, color: Colors.white),
                  ),
                  title: Text(
                    customer,
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    '$branchName • Console: $seat • Starts at: $timeString • Yet to start',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                  trailing: TextButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          backgroundColor: const Color(0xFF111827),
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            width: 320,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Upcoming booking',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                ElevatedButton(
                                  onPressed: () async {
                                    await FirebaseFirestore.instance
                                        .collection('branches')
                                        .doc(widget.branchId)
                                        .collection('sessions')
                                        .doc(doc.id)
                                        .update({
                                      'status': 'active',
                                      'startTime': Timestamp.fromDate(DateTime.now()),
                                    });
                                    if (context.mounted) Navigator.of(context).pop();
                                  },
                                  child: const Text('Start now'),
                                ),
                                const SizedBox(height: 8),
                                ElevatedButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    context.go('/bookings');
                                  },
                                  child: const Text('Reschedule'),
                                ),
                                const SizedBox(height: 8),
                                TextButton(
                                  onPressed: () async {
                                    await FirebaseFirestore.instance
                                        .collection('branches')
                                        .doc(widget.branchId)
                                        .collection('sessions')
                                        .doc(doc.id)
                                        .update({'status': 'cancelled'});
                                    if (context.mounted) Navigator.of(context).pop();
                                  },
                                  child: const Text(
                                    'Cancel booking',
                                    style: TextStyle(color: Colors.redAccent),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: TextButton(
                                    onPressed: () => Navigator.of(context).pop(),
                                    child: const Text('Close', style: TextStyle(color: Colors.white)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    child: const Text('Manage'),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}

//
// ======================= TODAY'S BOOKINGS POPUP =======================
//

class _TodaysBookingsDialog extends StatefulWidget {
  final String branchId;
  const _TodaysBookingsDialog({required this.branchId});

  @override
  State<_TodaysBookingsDialog> createState() => _TodaysBookingsDialogState();
}

class _TodaysBookingsDialogState extends State<_TodaysBookingsDialog> {
  bool _loading = true;
  String? _error;
  List<QueryDocumentSnapshot> _docs = [];

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final now = DateTime.now();
      final startDay = DateTime(now.year, now.month, now.day);
      final endDay = startDay.add(const Duration(days: 1));

      final snap = await FirebaseFirestore.instance
          .collection('branches')
          .doc(widget.branchId)
          .collection('sessions')
          .where('startTime', isGreaterThanOrEqualTo: Timestamp.fromDate(startDay))
          .where('startTime', isLessThan: Timestamp.fromDate(endDay))
          .get();

      final list = snap.docs.where((d) {
        final m = d.data() as Map<String, dynamic>? ?? {};
        final status = (m['status'] as String?) ?? '';
        return status != 'cancelled';
      }).toList()
        ..sort((a, b) {
          final ma = a.data() as Map<String, dynamic>? ?? {};
          final mb = b.data() as Map<String, dynamic>? ?? {};
          final ta = (ma['startTime'] as Timestamp?)?.toDate() ?? DateTime(2000);
          final tb = (mb['startTime'] as Timestamp?)?.toDate() ?? DateTime(2000);
          return ta.compareTo(tb);
        });

      setState(() {
        _docs = list;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load bookings.';
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF111827),
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    "Today's Bookings",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Refresh',
                  onPressed: _load,
                  icon: const Icon(Icons.refresh, color: Colors.white70),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Text('Loading...', style: TextStyle(color: Colors.white70))
            else if (_error != null)
              const Text(
                'Failed to load bookings.',
                style: TextStyle(color: Colors.redAccent),
              )
            else if (_docs.isEmpty)
              const Text('No bookings today.', style: TextStyle(color: Colors.white70))
            else
              SizedBox(
                height: 380,
                child: ListView.separated(
                  itemCount: _docs.length,
                  separatorBuilder: (_, __) =>
                      const Divider(color: Colors.white12, height: 12),
                  itemBuilder: (context, i) {
                    final d = _docs[i];
                    final m = d.data() as Map<String, dynamic>? ?? {};
                    final name = (m['customerName'] ?? 'Walk-in').toString();
                    final seat = (m['seatLabel'] ?? '-').toString();
                    final branchName = (m['branchName'] ?? '').toString();
                    final ts = (m['startTime'] as Timestamp?)?.toDate();
                    final timeStr = ts != null
                        ? '${ts.hour.toString().padLeft(2, '0')}:${ts.minute.toString().padLeft(2, '0')}'
                        : '—';
                    final status = (m['status'] as String?) ?? '';

                    return ListTile(
                      leading: const Icon(Icons.event, color: Colors.white70),
                      title: Text(
                        name,
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        '$branchName • Seat $seat • $status',
                        style: const TextStyle(color: Colors.white60),
                      ),
                      trailing: Text(
                        timeStr,
                        style: const TextStyle(color: Colors.white70),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close', style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------- END OF FILE ----------------------



