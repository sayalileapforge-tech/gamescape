import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// your feature screens
import '../../features/auth/login_screen.dart';
import '../../features/auth/bootstrap_superadmin_screen.dart';
import '../../features/auth/change_password_screen.dart';
import '../../features/dashboard/admin_dashboard_screen.dart';
import '../../features/branches/branches_screen.dart';
import '../../features/bookings/bookings_screen.dart';
import '../../features/sessions/live_sessions_screen.dart';
import '../../features/customers/customers_screen.dart';
import '../../features/inventory/inventory_screen.dart';
import '../../features/inventory/inventory_logs_screen.dart';
import '../../features/inventory/inventory_unified_screen.dart'; // <-- NEW
import '../../features/reports/reports_screen.dart';
import '../../features/billing/invoices_screen.dart';
import '../../features/user/user_management_screen.dart';

/// very small in-memory cache so we do NOT read Firestore inside redirect in a blocking way
class _UserDocCache {
  _UserDocCache._();
  static final _UserDocCache instance = _UserDocCache._();

  Map<String, dynamic>? _userData;
  String? _loadedForUid;
  bool _loading = false;

  Map<String, dynamic>? get userData => _userData;

  void load(String uid) {
    if (_loading) return;
    if (_loadedForUid == uid && _userData != null) return;
    _loading = true;
    FirebaseFirestore.instance.collection('users').doc(uid).get().then((doc) {
      if (doc.exists) {
        _userData = doc.data();
        _loadedForUid = uid;
      }
    }).catchError((_) {}).whenComplete(() {
      _loading = false;
    });
  }
}

class AppRouter {
  static final _rootNavigatorKey = GlobalKey<NavigatorState>();

  static final router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/dashboard',
    routes: [
      GoRoute(path: '/login', name: 'login', builder: (c, s) => const LoginScreen()),
      GoRoute(path: '/bootstrap-admin', name: 'bootstrap-admin', builder: (c, s) => const BootstrapSuperAdminScreen()),
      GoRoute(path: '/change-password', name: 'change-password', builder: (c, s) => const ChangePasswordScreen()),
      GoRoute(path: '/dashboard', name: 'dashboard', builder: (c, s) => const AdminDashboardScreen()),
      GoRoute(path: '/branches', name: 'branches', builder: (c, s) => const BranchesScreen()),
      GoRoute(path: '/bookings', name: 'bookings', builder: (c, s) => const BookingsScreen()),
      GoRoute(path: '/live-sessions', name: 'live-sessions', builder: (c, s) => const LiveSessionsScreen()),
      GoRoute(path: '/customers', name: 'customers', builder: (c, s) => const CustomersScreen()),
      GoRoute(path: '/inventory', name: 'inventory', builder: (c, s) => const InventoryScreen()),
      GoRoute(path: '/inventory-logs', name: 'inventory-logs', builder: (c, s) => const InventoryLogsScreen()),
      GoRoute(path: '/inventory-unified', name: 'inventory-unified', builder: (c, s) => const InventoryUnifiedScreen()), // <-- NEW
      GoRoute(path: '/reports', name: 'reports', builder: (c, s) => const ReportsScreen()),
      GoRoute(path: '/invoices', name: 'invoices', builder: (c, s) => const InvoicesScreen()),
      GoRoute(path: '/users', name: 'users', builder: (c, s) => const UserManagementScreen()),
    ],
    redirect: (context, state) {
      final auth = FirebaseAuth.instance;
      final user = auth.currentUser;
      final path = state.fullPath ?? '/dashboard';

      if (user == null) {
        if (path == '/login' || path == '/bootstrap-admin') return null;
        return '/login';
      }

      final cache = _UserDocCache.instance;
      final data = cache.userData;
      if (data == null) {
        cache.load(user.uid);
        if (path == '/login') return '/dashboard';
        return null;
      }

      final mustChange = data['mustChangePassword'] == true;
      if (mustChange && path != '/change-password') return '/change-password';
      if (!mustChange && path == '/change-password') return '/dashboard';

      final role = (data['role'] ?? 'staff').toString();
      final isStaff = role == 'staff';
      const adminOnly = <String>{
        '/branches',
        '/reports',
        '/users',
        '/invoices',
        '/inventory',
        '/inventory-logs',
        '/inventory-unified', // <-- include new screen in guard
      };
      if (isStaff && adminOnly.contains(path)) return '/dashboard';

      return null;
    },
    errorBuilder: (context, state) {
      return Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        body: Center(
          child: Text('Route error: ${state.error}', style: const TextStyle(color: Colors.white)),
        ),
      );
    },
  );
}
