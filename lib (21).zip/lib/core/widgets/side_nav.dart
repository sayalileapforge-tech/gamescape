import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'side_nav_controller.dart';

class SideNav extends StatelessWidget {
  final String role;
  const SideNav({super.key, required this.role});

  // Admin-like modules (manager can still see these)
  bool get _isAdminLike =>
      role == 'admin' || role == 'manager' || role == 'superadmin';

  // NEW: Fine-grained gates
  bool get _canSeeUsers => role == 'admin' || role == 'superadmin';
  bool get _canSeeReports => role == 'admin' || role == 'superadmin';

  bool _isActive(String location, String path) {
    if (location == path) return true;
    if (location.startsWith('$path/')) return true;
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: sideNavController,
      builder: (context, _) {
        final width = sideNavController.isExpanded ? 200.0 : 70.0;

        // GoRouterState is the correct way to read the current location
        final location = GoRouterState.of(context).uri.toString();

        return AnimatedContainer(
          width: width,
          duration: const Duration(milliseconds: 200),
          color: Colors.black,
          child: Column(
            children: [
              const SizedBox(height: 12),
              Align(
                alignment: sideNavController.isExpanded
                    ? Alignment.centerRight
                    : Alignment.center,
                child: IconButton(
                  onPressed: () => sideNavController.toggle(),
                  icon: Icon(
                    sideNavController.isExpanded
                        ? Icons.arrow_back_ios_new_rounded
                        : Icons.arrow_forward_ios_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: const Text(
                  'G',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: sideNavController.isExpanded
                        ? CrossAxisAlignment.start
                        : CrossAxisAlignment.center,
                    children: [
                      _NavTile(
                        icon: Icons.dashboard_outlined,
                        label: 'Dashboard',
                        expanded: sideNavController.isExpanded,
                        selected: _isActive(location, '/dashboard'),
                        onTap: () {
                          if (!_isActive(location, '/dashboard')) {
                            context.go('/dashboard');
                          }
                        },
                      ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.home_work_outlined,
                          label: 'Branches',
                          expanded: sideNavController.isExpanded,
                          selected: _isActive(location, '/branches'),
                          onTap: () {
                            if (!_isActive(location, '/branches')) {
                              context.go('/branches');
                            }
                          },
                        ),
                      _NavTile(
                        icon: Icons.chair_outlined,
                        label: 'Bookings',
                        expanded: sideNavController.isExpanded,
                        selected: _isActive(location, '/bookings'),
                        onTap: () {
                          if (!_isActive(location, '/bookings')) {
                            context.go('/bookings');
                          }
                        },
                      ),
                      _NavTile(
                        icon: Icons.live_tv_outlined,
                        label: 'Live Sessions',
                        expanded: sideNavController.isExpanded,
                        selected: _isActive(location, '/live-sessions'),
                        onTap: () {
                          if (!_isActive(location, '/live-sessions')) {
                            context.go('/live-sessions');
                          }
                        },
                      ),
                      _NavTile(
                        icon: Icons.person_outline,
                        label: 'Customers',
                        expanded: sideNavController.isExpanded,
                        selected: _isActive(location, '/customers'),
                        onTap: () {
                          if (!_isActive(location, '/customers')) {
                            context.go('/customers');
                          }
                        },
                      ),
                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.inventory_outlined,
                          label: 'Inventory (Unified)',
                          expanded: sideNavController.isExpanded,
                          selected: _isActive(location, '/inventory-unified'),
                          onTap: () {
                            if (!_isActive(location, '/inventory-unified')) {
                              context.go('/inventory-unified');
                            }
                          },
                        ),

                      // 👇 Hidden for manager
                      if (_canSeeUsers)
                        _NavTile(
                          icon: Icons.group_outlined,
                          label: 'Users',
                          expanded: sideNavController.isExpanded,
                          selected: _isActive(location, '/users'),
                          onTap: () {
                            if (!_isActive(location, '/users')) {
                              context.go('/users');
                            }
                          },
                        ),
                      if (_canSeeReports)
                        _NavTile(
                          icon: Icons.receipt_long_outlined,
                          label: 'Reports',
                          expanded: sideNavController.isExpanded,
                          selected: _isActive(location, '/reports'),
                          onTap: () {
                            if (!_isActive(location, '/reports')) {
                              context.go('/reports');
                            }
                          },
                        ),

                      if (_isAdminLike)
                        _NavTile(
                          icon: Icons.picture_as_pdf_outlined,
                          label: 'Invoices',
                          expanded: sideNavController.isExpanded,
                          selected: _isActive(location, '/invoices'),
                          onTap: () {
                            if (!_isActive(location, '/invoices')) {
                              context.go('/invoices');
                            }
                          },
                        ),
                    ],
                  ),
                ),
              ),

              _NavTile(
                icon: Icons.logout,
                label: 'Logout',
                expanded: sideNavController.isExpanded,
                selected: false,
                onTap: () async {
                  await FirebaseAuth.instance.signOut();
                  if (context.mounted) context.go('/login');
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }
}

class _NavTile extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool expanded;
  final bool selected;

  const _NavTile({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.expanded,
    required this.selected,
  });

  @override
  State<_NavTile> createState() => _NavTileState();
}

class _NavTileState extends State<_NavTile> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final bg = widget.selected
        ? Colors.white
        : (_hover ? const Color(0xFF111827) : Colors.transparent);
    final borderColor = widget.selected ? Colors.white : Colors.white10;
    final iconColor = widget.selected ? Colors.black : Colors.white;
    final textColor = widget.selected ? Colors.black : Colors.white;

    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: InkWell(
        onTap: widget.onTap,
        borderRadius: BorderRadius.circular(12),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
          padding: EdgeInsets.symmetric(
            vertical: 10,
            horizontal: widget.expanded ? 10 : 0,
          ),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: borderColor),
            boxShadow: widget.selected
                ? [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.15),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: widget.expanded
                ? MainAxisAlignment.start
                : MainAxisAlignment.center,
            children: [
              Icon(widget.icon, color: iconColor),
              if (widget.expanded) const SizedBox(width: 10),
              if (widget.expanded)
                Expanded(
                  child: Text(
                    widget.label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
