import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

// ==== ADD: vivid, high-contrast palette ====
const kGridHour    = Color(0xFF2B344A); // brighter hour lines
const kGridQuarter = Color(0xFF223046); // brighter quarter lines
const kNowLine     = Color(0xFFFFB020); // current-time line

const kActive      = Color(0xFF38BDF8); // sky-400
const kOverdue     = Color(0xFFFFB020); // amber-500
const kCompleted   = Color(0xFF22C55E); // green-500
const kReserved    = Color(0xFFA78BFA); // violet-400
const kCancelled   = Color(0xFFF87171); // red-400

const kSeatPillBgOpacity = 0.48;


class BookingTimelineView extends StatefulWidget {
  final List<QueryDocumentSnapshot> bookings;
  final DateTime date;
  const BookingTimelineView({
    super.key,
    required this.bookings,
    required this.date,
  });

  @override
  State<BookingTimelineView> createState() => _BookingTimelineViewState();
}

class _BookingTimelineViewState extends State<BookingTimelineView> {
  // Layout tokens
  static const int _minutesInDay = 24 * 60;
  static const double _minuteWidth = 72 / 60; // 72 px per hour
  static const double _leftRailWidth = 220;
  static const double _rowHeight = 44;
  static const double _headerHeight = 28;
  static const double _seatPillHeight = 40;

  // Controllers (synced)
  final _hBody = ScrollController();
  final _hHeader = ScrollController();
  final _vRail = ScrollController();
  final _vBody = ScrollController();

  bool _syncingH = false;
  bool _syncingV = false;

  Timer? _ticker;

  // Seat metadata
  Map<String, String> _seatLabelById = {};
  Map<String, Color> _seatColorById = {};
  String? _branchLoadedFor;

  bool get _isToday {
    final d = widget.date, n = DateTime.now();
    return d.year == n.year && d.month == n.month && d.day == n.day;
  }

  @override
  void initState() {
    super.initState();

    _hBody.addListener(() {
      if (_syncingH) return;
      _syncingH = true;
      if (_hHeader.hasClients) _hHeader.jumpTo(_hBody.offset);
      _syncingH = false;
    });

    _vBody.addListener(() {
      if (_syncingV) return;
      _syncingV = true;
      if (_vRail.hasClients) _vRail.jumpTo(_vBody.offset);
      _syncingV = false;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToNow();
      _loadSeatMetaIfNeeded();
    });

    _ticker = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted && _isToday) setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant BookingTimelineView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.date != widget.date) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToNow());
    }
    _loadSeatMetaIfNeeded();
  }

  @override
  void dispose() {
    _hBody.dispose();
    _hHeader.dispose();
    _vRail.dispose();
    _vBody.dispose();
    _ticker?.cancel();
    super.dispose();
  }

  void _scrollToNow() {
    if (!_isToday) return;
    final dayStart =
        DateTime(widget.date.year, widget.date.month, widget.date.day);
    final mins =
        DateTime.now().difference(dayStart).inMinutes.clamp(0, _minutesInDay);
    final target = mins * _minuteWidth;

    void jump() {
      if (!_hBody.hasClients) return;
      final max = _hBody.position.maxScrollExtent;
      final off = target.clamp(0.0, max);
      _hBody.jumpTo(off);
      if (_hHeader.hasClients) _hHeader.jumpTo(off);
    }

    WidgetsBinding.instance.addPostFrameCallback((_) => jump());
  }

  Future<void> _loadSeatMetaIfNeeded() async {
    if (widget.bookings.isEmpty) return;
    final parent = widget.bookings.first.reference.parent.parent;
    final branchId = parent?.id;
    if (branchId == null || branchId.isEmpty) return;
    if (_branchLoadedFor == branchId) return;

    try {
      final snap = await FirebaseFirestore.instance
          .collection('branches')
          .doc(branchId)
          .collection('seats')
          .get();

      final labels = <String, String>{};
      final colors = <String, Color>{};
      for (final d in snap.docs) {
        final m = d.data();
        final raw = m['label'];
        final String lbl = raw == null ? '' : raw.toString().trim();
        labels[d.id] = lbl.isNotEmpty ? lbl : d.id;

        Color? c;
        if (m['uiColor'] is int) c = Color(m['uiColor']);
        if (c == null && m['colorHex'] is String) c = _hex(m['colorHex']);
        colors[d.id] = c ?? const Color(0xFF334155);
      }

      if (!mounted) return;
      setState(() {
        _seatLabelById = labels;
        _seatColorById = colors;
        _branchLoadedFor = branchId;
      });
    } catch (_) {
      // soft-fail
    }
  }

  @override
  Widget build(BuildContext context) {
    final dayStart =
        DateTime(widget.date.year, widget.date.month, widget.date.day);

    // Bucketize by seat
    final buckets = <_SeatBucket>[];
    final byKey = <String, _SeatBucket>{};

    for (final d in widget.bookings) {
      final m = d.data() as Map<String, dynamic>;
      final ts = m['startTime'] as Timestamp?;
      if (ts == null) continue;
      final st = ts.toDate();
      if (st.year != dayStart.year ||
          st.month != dayStart.month ||
          st.day != dayStart.day) continue;

      final seatId = (m['seatId']?.toString().trim() ?? '');
      final seatDocLabel = (m['seatLabel']?.toString().trim() ?? '');
      final label = _labelFor(seatId, seatDocLabel);
      final color = _colorFor(seatId);

      final key = '$label|$seatId';
      final bucket = byKey.putIfAbsent(key, () {
        final b = _SeatBucket(label, color);
        buckets.add(b);
        return b;
      });
      bucket.docs.add(d);
    }

    // sort by label
    buckets.sort((a, b) => a.label.compareTo(b.label));

    // compute rows per bucket and lane height
    for (final b in buckets) {
      b.rows = _rowsNeeded(b.docs, dayStart);
      b.height = (b.rows * _rowHeight).clamp(_rowHeight, 1200);
    }

    final totalWidth = _minutesInDay * _minuteWidth;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Legend(),
        const SizedBox(height: 10),
        _HeaderRow(
          headerHeight: _headerHeight,
          leftRailWidth: _leftRailWidth,
          totalWidth: totalWidth,
          minuteWidth: _minuteWidth,
          controller: _hHeader,
        ),
        const SizedBox(height: 6),
        Expanded(
          child: Row(
            children: [
              // LEFT RAIL with its own vertical scrollbar
              SizedBox(
                width: _leftRailWidth,
                child: Scrollbar(
                  controller: _vRail,
                  thumbVisibility: true,
                  thickness: 8,
                  radius: const Radius.circular(8),
                  child: ListView.builder(
                    controller: _vRail,
                    itemCount: buckets.length,
                    itemBuilder: (_, i) {
                      final b = buckets[i];
                      final status = _seatStatusNow(b.docs, dayStart);
                      return SizedBox(
                        height: b.height,
                        child: Center(
                          child: _SeatPill(
                            label: b.label,
                            seatColor: b.color,
                            status: status,
                            height: _seatPillHeight,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              // RIGHT SIDE with both horizontal & vertical scrollbars
              Expanded(
                child: Scrollbar(
                  controller: _hBody,
                  notificationPredicate: (n) =>
                      n.metrics.axis == Axis.horizontal,
                  thumbVisibility: true,
                  thickness: 8,
                  radius: const Radius.circular(8),
                  child: SingleChildScrollView(
                    controller: _hBody,
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: totalWidth,
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: Scrollbar(
                              controller: _vBody,
                              thumbVisibility: true,
                              thickness: 8,
                              radius: const Radius.circular(8),
                              child: ListView.builder(
                                controller: _vBody,
                                itemCount: buckets.length,
                                itemBuilder: (_, i) {
                                  final b = buckets[i];
                                  return SizedBox(
                                    height: b.height,
                                    child: Stack(
                                      children: [
                                        Positioned.fill(
                                          child: CustomPaint(
                                            painter: _GridPainter(
                                                minuteWidth: _minuteWidth),
                                          ),
                                        ),
                                        _LaneBlocks(
                                          docs: b.docs,
                                          dayStart: dayStart,
                                          minuteWidth: _minuteWidth,
                                          rowHeight: _rowHeight,
                                        ),
                                        const Positioned(
                                          bottom: 0,
                                          left: 0,
                                          right: 0,
                                          child: Divider(
                                              height: 1,
                                              color: Colors.white12),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          if (_isToday)
                            _NowLine(
                              dayStart: dayStart,
                              minuteWidth: _minuteWidth,
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ===== helpers =====

  String _labelFor(String seatId, String docLabel) {
    if (docLabel.isNotEmpty) return docLabel;
    if (seatId.isEmpty) return 'Unknown';
    return _seatLabelById[seatId] ?? seatId;
  }

  Color _colorFor(String seatId) =>
      _seatColorById[seatId] ?? const Color(0xFF334155);

  _SeatStatus _seatStatusNow(
      List<QueryDocumentSnapshot> docs, DateTime dayStart) {
    final now = DateTime.now();

    for (final d in docs) {
      final m = d.data() as Map<String, dynamic>;
      final ts = m['startTime'] as Timestamp?;
      if (ts == null) continue;
      final st = ts.toDate();
      final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
      final end = st.add(Duration(minutes: dur));
      final status = (m['status'] ?? 'active').toString();

      if (status == 'cancelled' || status == 'canceled' || status == 'completed') {
        continue;
      }

      final overlapsNow = !now.isBefore(st) && now.isBefore(end);
      if (overlapsNow) {
        if (status == 'active' && end.isBefore(DateTime.now())) {
          return _SeatStatus.overdue;
        }
        return _SeatStatus.occupied;
      }
    }

    final horizon = now.add(const Duration(minutes: 60));
    for (final d in docs) {
      final m = d.data() as Map<String, dynamic>;
      final ts = m['startTime'] as Timestamp?;
      if (ts == null) continue;
      final st = ts.toDate();
      final status = (m['status'] ?? '').toString().toLowerCase();
      if (status == 'reserved' && st.isAfter(now) && st.isBefore(horizon)) {
        return _SeatStatus.reserved;
      }
    }

    return _SeatStatus.free;
  }

  int _rowsNeeded(List<QueryDocumentSnapshot> docs, DateTime dayStart) {
    final ivs = <_Iv>[];
    for (final d in docs) {
      final m = d.data() as Map<String, dynamic>;
      final ts = m['startTime'] as Timestamp?;
      if (ts == null) continue;
      final st = ts.toDate();
      final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
      final s = st.difference(dayStart).inMinutes;
      if (s < 0) continue;
      ivs.add(_Iv(s, s + dur));
    }
    ivs.sort((a, b) => a.s.compareTo(b.s));

    final rows = <List<_Iv>>[];
    for (final iv in ivs) {
      var placed = false;
      for (final r in rows) {
        final last = r.last;
        final overlap = iv.s < last.e && last.s < iv.e;
        if (!overlap) {
          r.add(iv);
          placed = true;
          break;
        }
      }
      if (!placed) rows.add([iv]);
    }
    return rows.isEmpty ? 1 : rows.length;
  }

  static Color _hex(String s) {
    var h = s.trim();
    if (h.startsWith('#')) h = h.substring(1);
    if (h.length == 6) h = 'FF$h';
    return Color(int.tryParse(h, radix: 16) ?? 0xFF334155);
  }
}

// ===== UI bits =====

class _HeaderRow extends StatelessWidget {
  final double headerHeight;
  final double leftRailWidth;
  final double totalWidth;
  final double minuteWidth;
  final ScrollController controller;

  const _HeaderRow({
    required this.headerHeight,
    required this.leftRailWidth,
    required this.totalWidth,
    required this.minuteWidth,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: headerHeight,
      child: Row(
        children: [
          SizedBox(
            width: leftRailWidth,
            child: const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Seats',
                style: TextStyle(
                    color: Colors.white70, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          Expanded(
            child: Scrollbar(
              controller: controller,
              notificationPredicate: (n) =>
                  n.metrics.axis == Axis.horizontal,
              thumbVisibility: true,
              thickness: 8,
              radius: const Radius.circular(8),
              child: SingleChildScrollView(
                controller: controller,
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: totalWidth,
                  height: headerHeight,
                  child: Row(
                    children: List.generate(24, (h) {
                      return SizedBox(
                        width: 60 * minuteWidth,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            '${h.toString().padLeft(2, '0')}:00',
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 11),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Widget chip(Color c, String t) => Row(children: [
          Container(
              width: 10,
              height: 10,
              decoration:
                  BoxDecoration(color: c, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 6),
          Text(t, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(width: 14),
        ]);

    return SizedBox(
      height: 24,
      child: Row(children: [
        chip(const Color(0xFF60A5FA), 'Active'),
        chip(const Color(0xFFFFA500), 'Overdue'),
        chip(const Color(0xFF34D399), 'Completed'),
        chip(const Color(0xFF93C5FD), 'Reserved'),
        chip(const Color(0xFFFF6B6B), 'Cancelled'),
        const SizedBox(width: 22),
        chip(const Color(0xFF10B981), 'Seat Free'),
        chip(const Color(0xFF3B82F6), 'Seat Occupied'),
        chip(const Color(0xFF8B5CF6), 'Seat Reserved'),
        chip(const Color(0xFFFF8C00), 'Seat Overdue'),
      ]),
    );
  }
}

class _GridPainter extends CustomPainter {
  final double minuteWidth;
  _GridPainter({required this.minuteWidth});

  @override
  void paint(Canvas canvas, Size size) {
 final hour = Paint()..color = kGridHour;
final quarter = Paint()..color = kGridQuarter;
    for (double x = 0; x <= size.width; x += 60 * minuteWidth) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), hour);
      for (int q = 15; q < 60; q += 15) {
        final qx = x + q * minuteWidth;
        canvas.drawLine(Offset(qx, 0), Offset(qx, size.height), quarter);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) =>
      old.minuteWidth != minuteWidth;
}

class _LaneBlocks extends StatelessWidget {
  final List<QueryDocumentSnapshot> docs;
  final DateTime dayStart;
  final double minuteWidth;
  final double rowHeight;

  const _LaneBlocks({
    required this.docs,
    required this.dayStart,
    required this.minuteWidth,
    required this.rowHeight,
  });

  @override
  Widget build(BuildContext context) {
    final items = <_Block>[];
    for (final d in docs) {
      final m = d.data() as Map<String, dynamic>;
      final ts = m['startTime'] as Timestamp?;
      if (ts == null) continue;
      final st = ts.toDate();
      final dur = (m['durationMinutes'] as num?)?.toInt() ?? 60;
      final s = st.difference(dayStart).inMinutes;
      if (s < 0) continue;
      items.add(_Block(m, s, s + dur, 0));
    }
    items.sort((a, b) => a.s.compareTo(b.s));

    final rows = <List<_Block>>[];
    final laid = <_Block>[];
    for (final it in items) {
      var r = 0;
      while (true) {
        if (r >= rows.length) {
          rows.add([it]);
          laid.add(it.copyWith(r: r));
          break;
        }
        final last = rows[r].last;
        final overlap = it.s < last.e && last.s < it.e;
        if (!overlap) {
          rows[r].add(it);
          laid.add(it.copyWith(r: r));
          break;
        }
        r++;
      }
    }

    return Stack(
      children: [
        for (final b in laid)
          Positioned(
            top: b.r * rowHeight + 5,
            left: b.s * minuteWidth,
            width: (b.e - b.s) * minuteWidth,
            height: rowHeight - 10,
            child: _BlockChip(data: b.m),
          ),
      ],
    );
  }
}

class _BlockChip extends StatelessWidget {
  final Map<String, dynamic> data;
  const _BlockChip({required this.data});

  @override
  Widget build(BuildContext context) {
    final status = (data['status'] ?? 'active').toString();
    final name = (data['customerName'] ?? '').toString();
    final ts = data['startTime'] as Timestamp?;
    final start = ts?.toDate() ?? DateTime.now();
    final dur = (data['durationMinutes'] as num?)?.toInt() ?? 60;
    final end = start.add(Duration(minutes: dur));
    final overdue = status == 'active' && end.isBefore(DateTime.now());

    Color bg;
    switch (status) {
      case 'cancelled':
      case 'canceled':
        bg = const Color(0xFFFF6B6B);
        break;
      case 'completed':
        bg = const Color(0xFF34D399);
        break;
      case 'reserved':
        bg = const Color(0xFF93C5FD);
        break;
      default:
        bg = overdue ? const Color(0xFFFFA500) : const Color(0xFF60A5FA);
    }

    String hhmm(DateTime d) =>
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white24),
      ),
      child: Text(
        '${name.isEmpty ? "—" : name}  •  ${hhmm(start)}–${hhmm(end)} (${dur}m)',
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Colors.black87,
          fontSize: 10,
          height: 1.1,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _SeatPill extends StatelessWidget {
  final String label;
  final Color seatColor;
  final _SeatStatus status;
  final double height;

  const _SeatPill({
    required this.label,
    required this.seatColor,
    required this.status,
    required this.height,
  });

  Color get _statusColor => switch (status) {
        _SeatStatus.free => const Color(0xFF10B981),
        _SeatStatus.occupied => const Color(0xFF3B82F6),
        _SeatStatus.reserved => const Color(0xFF8B5CF6),
        _SeatStatus.overdue => const Color(0xFFFF8C00),
      };

  String get _statusText => switch (status) {
        _SeatStatus.free => 'Free',
        _SeatStatus.occupied => 'Occupied',
        _SeatStatus.reserved => 'Reserved',
        _SeatStatus.overdue => 'Overdue',
      };

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: '$label • $_statusText',
      child: Container(
        height: height,
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: seatColor.withOpacity(.28),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: seatColor.withOpacity(.9)),
        ),
        child: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: _statusColor,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  letterSpacing: .2,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              _statusText,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NowLine extends StatelessWidget {
  final DateTime dayStart;
  final double minuteWidth;
  const _NowLine({required this.dayStart, required this.minuteWidth});

  @override
  Widget build(BuildContext context) {
    final mins =
        DateTime.now().difference(dayStart).inMinutes.clamp(0, 24 * 60);
    final left = mins * minuteWidth;
    return Positioned(
      left: left.toDouble(),
      top: 0,
      bottom: 0,
      child: Container(width: 2, color: const Color(0xFFFFA500)),
    );
  }
}

// ===== models =====

enum _SeatStatus { free, occupied, reserved, overdue }

class _SeatBucket {
  _SeatBucket(this.label, this.color);
  final String label;
  final Color color;
  final List<QueryDocumentSnapshot> docs = [];
  int rows = 1;
  double height = 44.0;
}

class _Iv {
  final int s, e;
  _Iv(this.s, this.e);
}

class _Block {
  final Map<String, dynamic> m;
  final int s, e, r;
  _Block(this.m, this.s, this.e, this.r);
  _Block copyWith({int? r}) => _Block(m, s, e, r ?? this.r);
}
